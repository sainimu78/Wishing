//#include "Niflect/Property2/NiflectProperty.h"
//#include "Niflect/Field/NiflectField.h"
//
//namespace Niflect
//{
//	bool CProperty::SaveToRwNode(const AddrType& base, CRwNode& rw) const
//	{
//		if (m_field != NULL)
//			return m_field->SaveToRwNode(base, rw);
//		return this->DoSaveToRwNode(base, rw);
//	}
//	bool CProperty::LoadFromRwNode(const AddrType& base, const CRwNode& rw) const
//	{
//		if (m_field != NULL)
//			return m_field->LoadFromRwNode(base, rw);
//		return this->DoLoadFromRwNode(base, rw);
//	}
//}