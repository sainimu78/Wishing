#pragma once

namespace TestContainer
{
	template <typename T>
	class TMyArrayDebug
	{
	};
}