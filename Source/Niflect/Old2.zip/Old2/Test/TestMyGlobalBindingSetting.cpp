#include "Niflect/Test/TestMyGlobalBindingSetting.h"
