g++ \
-oa -std=c++14 \
-lstdc++ \
-DTEST_FOR_GCC \
-DNIFLECT_API= \
-I../ \
-I../../../../../../S3Engine \
-I../../../../../../Dependencies/include/ \
Memory/Default/DefaultMemory.cpp \
Accessor/NiflectAccessor.cpp \
Property/Property.cpp \
Test/TestModule0.cpp \
Test/TestProperty.cpp \
