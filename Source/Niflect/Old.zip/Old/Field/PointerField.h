#pragma once
#include "Niflect/Property2/FieldProperty.h"

namespace Niflect
{
	//class IPointerTempPointing
	//{
	//public:
	//	virtual AddrType2 GetPointingBaseAddr() = 0;
	//	virtual void InsertTo(AddrType2 base) const = 0;
	//};
	//using CSharedPointerTempPointing = TSharedPtr<IPointerTempPointing>;

	class IPointerAccessor
	{
	public:
		virtual AddrType2 GetPointingBaseAddr(const AddrType2& base) const = 0;
		//virtual CSharedPointerTempPointing CreatePointing() const = 0;
	};
	using CSharedPointerAccessor = TSharedPtr<IPointerAccessor>;
	
	class CPointerField : public CField
	{
	public:
		void SetAccessor(const CSharedPointerAccessor& accessor)
		{
			m_accessor = accessor;
		}

	public:
		void SetPointingField(const CSharedField& field)
		{
			m_pointingField = field;
		}

	public:
		virtual bool SaveToRwNode(const AddrType2& base, CRwNode& rw) const override
		{
			if (auto pointingBase = m_accessor->GetPointingBaseAddr(base))
			{
				m_pointingField->SaveToRwNode(pointingBase, rw);
				return true;
			}
			return false;
		}
		virtual bool LoadFromRwNode(AddrType2& base, const CRwNode& rw) const override
		{
			if (auto pointingBase = m_accessor->GetPointingBaseAddr(base))
			{
				m_pointingField->LoadFromRwNode(pointingBase, rw);
				return true;
			}
			return false;
		}

	public:
		virtual CSharedProperty2 CreatePropertyTree(const AddrType2& base) override
		{
			auto parentProp = Niflect::MakeShared<CFieldProperty>();
			parentProp->InitMeta(this->GetName(), base, false);
			parentProp->SetField(this);
			if (auto pointingBase = m_accessor->GetPointingBaseAddr(base))
			{
				auto pointingProp = m_pointingField->CreatePropertyTree(pointingBase);
				parentProp->AddChild(pointingProp);
			}
			return parentProp;
		}

	private:
		CSharedField m_pointingField;
		CSharedPointerAccessor m_accessor;
	};

	//template <typename T>
	//class TPointerTempPointingAddr : public IPointerTempPointing
	//{
	//public:
	//	virtual AddrType2 GetPointingBaseAddr() override
	//	{
	//		return &m_elem;
	//	}
	//	virtual void InsertTo(AddrType2 base) const override
	//	{
	//		auto& instance = *static_cast<T*>(base);
	//		*instance = *m_elem;
	//	}

	//private:
	//	T m_elem;
	//};

	template <typename T>
	class TPointerAccessorAddr : public IPointerAccessor
	{
	public:
		virtual AddrType2 GetPointingBaseAddr(const AddrType2& base) const override
		{
			auto& instance = *static_cast<T*>(base);
			return instance;
		}
		//virtual CSharedPointerTempPointing CreatePointing() const override
		//{
		//	return MakeShared<TPointerTempPointingAddr<T> >();
		//}
	};
	
	template <typename TType>
	struct SFieldCreator<CPointerField, TType>
	{
		static TSharedPtr<CPointerField> Create()
		{
			auto shared1 = Niflect::MakeShared<CPointerField>();
			auto field1 = shared1.Get();
			field1->SetAccessor(MakeShared<TPointerAccessorAddr<TType> >());
			return shared1;
		}
	};
}