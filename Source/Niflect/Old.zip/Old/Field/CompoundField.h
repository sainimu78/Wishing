#pragma once
#include "Niflect/Property2/FieldProperty.h"

namespace Niflect
{
	class CCompoundField : public CField
	{
	public:
		virtual bool SaveToRwNode(const AddrType2& base, CRwNode& rw) const override
		{
			auto count = this->GetChildrenCount();
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto child = this->GetChild(idx);
				ASSERT(!child->GetName().empty());

				//uint32 childIndex;
				//auto rwChild = AddRwNode(rw, child->GetName(), &childIndex);
				//child->SaveToRwNode(objBase, rwChild);

				auto rwChild = rw->CreateNode();
				auto childBase = child->GetBaseAddr(base);
				if (child->SaveToRwNode(childBase, rwChild))
					AddExistingRwNode(rw, child->GetName(), rwChild);
			}
			return true;
		}
		virtual bool LoadFromRwNode(AddrType2& base, const CRwNode& rw) const override
		{
			auto count = this->GetChildrenCount();
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto child = this->GetChild(idx);
				ASSERT(!child->GetName().empty());
				auto rwChild = FindRwNode(rw, child->GetName());
				auto childBase = child->GetBaseAddr(base);
				child->LoadFromRwNode(childBase, rwChild);
			}
			return true;
		}

	public:
		virtual CSharedProperty2 CreatePropertyTree(const AddrType2& base) override
		{
			auto parentProp = Niflect::MakeShared<Niflect::CFieldProperty>();
			parentProp->InitMeta(this->GetName(), base, false);
			parentProp->SetField(this);
			for (uint32 idx = 0; idx < this->GetChildrenCount(); ++idx)
			{
				auto childField = this->GetChild(idx);
				auto childBase = childField->GetBaseAddr(base);
				auto childProp = childField->CreatePropertyTree(childBase);
				parentProp->AddChild(childProp);
			}
			return parentProp;
		}
	};
}