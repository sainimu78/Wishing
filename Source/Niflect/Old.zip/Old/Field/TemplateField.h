#pragma once
#include "Niflect/Field/CompoundField.h"

namespace Niflect
{
	typedef CCompoundField CCompoundTemplateField;

	class CContainerField : public CField
	{
	public:
		void AddTemplateArgumentField(const CSharedField& field)
		{
			m_vecTemplateArgField.push_back(field);
		}

	protected:
		CField* GetArgumentField(uint32 idx) const
		{
			return m_vecTemplateArgField[idx].Get();
		}

	private:
		TArrayNif<CSharedField> m_vecTemplateArgField;
	};
}