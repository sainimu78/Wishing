#pragma once
#include "Niflect/Property2/NiflectProperty.h"
#include "Niflect/Accessor2/NiflectAccessor2.h"

namespace Niflect
{
	using namespace TreeReadWrite2;
	
	template <typename T>
	static CNiflectType2* StaticGetType2();

	class CNiflectType2;
	
	class CField;

	using CSharedField = TSharedPtr<CField>;

	class CField
	{
	public:
		CField()
			: m_type(NULL)
			, m_owner(NULL)
		{
		}

	public:
		void InitType(CNiflectType2* type)
		{
			m_type = type;
		}
		void InitMemberMeta(const CString& name, const AddrOffsetType2& offset, CField* owner/*����*/)
		{
			m_name = name;
			m_addrOffset.SetOffset(offset);
			//m_owner = owner;
		}
		CNiflectType2* GetType() const
		{
			return m_type;
		}
		const CString& GetName() const
		{
			return m_name;
		}
		AddrType2 GetBaseAddr(const AddrType2& base) const
		{
			return m_addrOffset.GetAddr(base);
		}
		//template <typename T>
		//inline T& GetInstanceRef(const AddrType2& base) const
		//{
		//	return *static_cast<T*>(this->GetBaseAddr(base));
		//}

	public:
		void AddChild(const CSharedField& field)
		{
			this->InsertChild(field, this->GetChildrenCount());
		}
		void InsertChild(const CSharedField& field, uint32 idx)
		{
			m_vecChild.insert(m_vecChild.begin() + idx, field);
		}
		uint32 GetChildrenCount() const
		{
			return static_cast<uint32>(m_vecChild.size());
		}
		CField* GetChild(uint32 idx) const
		{
			return m_vecChild[idx].Get();
		}

	public:
		virtual bool SaveToRwNode(const AddrType2& base, CRwNode& rw) const = 0;
		virtual bool LoadFromRwNode(AddrType2& base, const CRwNode& rw) const = 0;

	public:
		virtual CSharedProperty2 CreatePropertyTree(const AddrType2& base) = 0;

	private:
		CString m_name;
		CNiflectType2* m_type;
		TArrayNif<CSharedField> m_vecChild;
		CAddrOffset2 m_addrOffset;
		CField* m_owner;
	};

	template <typename TField, typename TType>
	struct SFieldCreator
	{
		static TSharedPtr<TField> Create()
		{
			return MakeShared<TField>();
		}
	};

	template <typename TField, typename TType>
	static TSharedPtr<TField> CreateField()
	{
		auto shared = SFieldCreator<TField, TType>::Create();
		auto field = shared.Get();
		field->InitType(StaticGetType2<TType>());
		return shared;
	}
}