#pragma once
#include "Niflect/Field/TemplateField.h"
#include "Niflect/Property2/FieldProperty.h"

namespace Niflect
{
	class IArrayAccessor
	{
	public:
		virtual AddrType2 GetElementBaseAddr(const AddrType2& base, const ArrayIndex2& idx) const = 0;
		virtual ArrayIndex2 GetElementsCount(const AddrType2& base) const = 0;
		virtual void SetElementsCount(const AddrType2& base, const ArrayIndex2& count) const = 0;
	};
	using CSharedArrayAccessor = TSharedPtr<IArrayAccessor>;

	class CArrayField : public CContainerField
	{
	public:
		void SetAccessor(const CSharedArrayAccessor& accessor)
		{
			m_accessor = accessor;
		}

	public:
		virtual bool SaveToRwNode(const AddrType2& base, CRwNode& rw) const override
		{
			auto count = m_accessor->GetElementsCount(base);
			if (count > 0)
			{
				auto& rwArray = rw->ToArray();
				for (ArrayIndex2 idx1 = 0; idx1 < count; ++idx1)
				{
					auto& rwItem = rwArray->AddItemNode();
					auto elemBase = m_accessor->GetElementBaseAddr(base, idx1);
					this->GetElementField()->SaveToRwNode(elemBase, rwItem);
				}
			}
			return true;
		}
		virtual bool LoadFromRwNode(AddrType2& base, const CRwNode& rw) const override
		{
			auto& rwArray = rw->ToArray();
			auto count = GetRwItemsCount(rwArray);
			m_accessor->SetElementsCount(base, count);
			for (ArrayIndex2 idx1 = 0; idx1 < count; ++idx1)
			{
				auto& rwItem = rwArray->GetItemNode(idx1);
				auto elemBase = m_accessor->GetElementBaseAddr(base, idx1);
				this->GetElementField()->LoadFromRwNode(elemBase, rwItem);
			}
			return true;
		}

	public:
		virtual CSharedProperty2 CreatePropertyTree(const AddrType2& base) override
		{
			auto parentProp = Niflect::MakeShared<Niflect::CFieldProperty>();
			parentProp->InitMeta(this->GetName(), base, false);
			parentProp->SetField(this);
			auto count = m_accessor->GetElementsCount(base);
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto elemBase = m_accessor->GetElementBaseAddr(base, idx);
				auto elemProp = this->GetElementField()->CreatePropertyTree(elemBase);
				parentProp->AddChild(elemProp);
			}
			return parentProp;
		}

	private:
		CField* GetElementField() const
		{
			return this->GetArgumentField(0);
		}

	public:
		static CArrayField* Cast(CField* base)
		{
			ASSERT(dynamic_cast<CArrayField*>(base) != NULL);
			return static_cast<CArrayField*>(base);
		}

	private:
		CSharedArrayAccessor m_accessor;
	};
	
	template <typename TArrayType>
	class TArrayAccessorAddr : public IArrayAccessor
	{
	public:
		virtual AddrType2 GetElementBaseAddr(const AddrType2& base, const ArrayIndex2& idx) const override
		{
			auto& array = *static_cast<TArrayType*>(base);
			return &array[idx];
		}
		virtual ArrayIndex2 GetElementsCount(const AddrType2& base) const override
		{
			auto& array = *static_cast<TArrayType*>(base);
			return static_cast<ArrayIndex2>(array.size());
		}
		virtual void SetElementsCount(const AddrType2& base, const ArrayIndex2& count) const override
		{
			auto& array = *static_cast<TArrayType*>(base);
			array.resize(count);
		}
	};
	
	template <typename TType>
	struct SFieldCreator<CArrayField, TType>
	{
		static TSharedPtr<CArrayField> Create()
		{
			auto shared1 = Niflect::MakeShared<CArrayField>();
			auto field1 = shared1.Get();
			field1->SetAccessor(MakeShared<TArrayAccessorAddr<TType> >());
			return shared1;
		}
	};
}