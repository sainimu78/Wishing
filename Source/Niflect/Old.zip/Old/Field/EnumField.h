#pragma once
#include "Niflect/Property2/FieldProperty.h"
#include "Niflect/Type/NiflectType2.h"

namespace Niflect
{
	class IUintXEnumAccessor
	{
	public:
		virtual uint32 GetUInt(const AddrType2& base) const = 0;
		virtual void SetUInt(AddrType2& base, uint32 idx) const = 0;
	};
	using CSharedUintXEnumAccessor = TSharedPtr<IUintXEnumAccessor>;

	class CEnumField : public CField
	{
		typedef CField inherited;
	public:
		void SetAccessor(const CSharedUintXEnumAccessor& accessor)
		{
			m_accessor = accessor;
		}

	public:
		virtual bool SaveToRwNode(const AddrType2& base, CRwNode& rw) const override
		{
			auto e = this->GetEnum();
			auto& rwValue = rw->ToValue();
			auto& name = e->GetName(m_accessor->GetUInt(base));
			ValueReadWrite::Save(rwValue, name);
			return true;
		}
		virtual bool LoadFromRwNode(AddrType2& base, const CRwNode& rw) const override
		{
			CString name;
			auto e = this->GetEnum();
			auto& rwValue = rw->ToValue();
			ValueReadWrite::Load(rwValue, name);
			auto idx = e->FindIndex(name);
			ASSERT(idx != INDEX_NONE);
			m_accessor->SetUInt(base, idx);
			return true;
		}

	public:
		virtual CSharedProperty2 CreatePropertyTree(const AddrType2& base) override
		{
			auto parentProp = Niflect::MakeShared<Niflect::CFieldProperty>();
			parentProp->InitMeta(this->GetName(), base, true);
			parentProp->SetField(this);
			return parentProp;
		}

	private:
		CEnum2* GetEnum() const
		{
			return Cast<CEnum2>(inherited::GetType());
		}

	private:
		CSharedUintXEnumAccessor m_accessor;
	};

	template <typename TUintXType>
	class TUintXEnumAccessorAddr : public IUintXEnumAccessor
	{
	public:
		virtual uint32 GetUInt(const AddrType2& base) const override
		{
			return *static_cast<TUintXType*>(base);
		}
		virtual void SetUInt(AddrType2& base, uint32 idx) const override
		{
			*static_cast<TUintXType*>(base) = idx;
		}
	};
	
	template <typename TEnum>
	static TSharedPtr<CEnumField> CreateEnumField()
	{
		auto shared1 = Niflect::MakeShared<CEnumField>();
		auto field1 = shared1.Get();
		field1->SetAccessor(MakeShared<TUintXEnumAccessorAddr<typename std::underlying_type<TEnum>::type> >());
		return shared1;
	}

	template <typename TType>
	struct SFieldCreator<CEnumField, TType>
	{
		static TSharedPtr<CEnumField> Create()
		{
			return CreateEnumField<TType>();
		}
	};
}