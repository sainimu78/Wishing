#pragma once
//#include "Niflect/Module/NiflectModule.h"
#include "Niflect/Property/NiflectMetaFactory.h"

namespace Niflect
{
//	class CEditorModule : public CModule
//	{
//	public:
//		static CEditorModule* Cast(CModule* base)
//		{
//			ASSERT(dynamic_cast<CEditorModule*>(base) != NULL);
//			return static_cast<CEditorModule*>(base);
//		}
//	public:
//		CMetaFactory m_factory;
//	};
}