#pragma once
#include "Niflect/Property/NiflectMeta.h"

namespace Niflect
{
	class CMetaFactory
	{
	public:
		void RegisterMetaAtIndex(const CSharedMeta& meta, uint32 idx)//����VS����, ��ʱ��My��׺
		{
			if (idx >= m_vecMeta.size())
				m_vecMeta.resize(idx + 1);
			m_vecMeta[idx] = meta;
		}
		CMeta* GetMutableMetaByIndex(uint32 idx)
		{
			return m_vecMeta[idx].Get();
		}
		const CMeta* GetMetaByIndex(uint32 idx) const
		{
			return m_vecMeta[idx].Get();
		}

	public:
		TArrayNif<CSharedMeta> m_vecMeta;
	};
}