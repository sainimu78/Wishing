#include "Niflect/Property/Property.h"
#include "Niflect/Util/DebugUtil.h"

namespace Niflect
{
	void PrintPropertyRecurs(CPropertyNode* node, uint32 level)
	{
		auto strLevel = NiflectUtil::DebugIndentToString(level);
		CString strMemberName = "Not a member";
		CString strType = "No type";
		CString strValue = "Not a value";
		if (auto accessor = node->m_accessor)
		{
			auto& strAccessorName = accessor->GetName();
			if (!strAccessorName.empty())
				strMemberName = strAccessorName;
			auto type = accessor->GetType();
			if (type != NULL)
			{
				if (accessor->GetOwner() == NULL)
					strMemberName += "(Section base)";
				strType = type->GetTypeName();
			}
			else
			{
				if (CArrayAccessor::CastChecked(accessor) != NULL)
					strType += "(Array group)";//todo: ���ǽ�CArrayAccessorҲ��Ϊ��������ע�ᵽfactory
			}
			if (auto fieldAccessor = CFieldAccessor::CastChecked(accessor))//��Ϊ�򵥲��Դ�ӡ, ����ֻ��Field��ӡ
			{
				//CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
				//CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
				////CRwJson::AllocatorStack stack;
				////CRwJson::AllocatorPool allocator(poolCapa, &stack);
				//CRwJson::AllocatorStack stack;
				//auto& allocator = stack;
				//CRwJson::Document jd(&allocator, poolCapa, &allocator, stackCapa);
				//auto& joRoot = jd.toObject();
				//CJsonRwDocument doc(jd, joRoot);
				//auto rwRoot = doc.GetRootNode();
				//fieldAccessor->Save(node->m_parentBase, rwRoot);
				//CRwJson::StringBuffer buffer(&allocator, poolCapa);
				//CRwJson::WriteToBuffer(joRoot, buffer);
				//strValue = buffer.GetString();
				DebugSaveAccessorString(fieldAccessor, node->m_parentBase, strValue);
			}
		}
		printf("%s%s, %s\n", strLevel.c_str(), strMemberName.c_str(), strValue.c_str());
		//printf("%s%s:%s, %s\n", strLevel.c_str(), strMemberName.c_str(), strValue.c_str(), strType.c_str());
		if (auto group = CPropertyGroup::CastChecked(node))
		{
			level++;
			auto count = group->m_vecChild.size();
			for (uint32 idx = 0; idx < count; ++idx)
			{
				PrintPropertyRecurs(group->m_vecChild[idx].Get(), level);
			}
		}
	}
}