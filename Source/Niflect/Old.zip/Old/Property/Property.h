#pragma once
#include "Niflect/Base/NiflectType.h"

namespace Niflect
{
	class CPropertyGroup;

	class CPropertyNode
	{
	public:
		CPropertyNode()
			: m_accessor(NULL)
			, m_parent(NULL)
			, m_parentBase(NULL)
		{
		}
		void InitMeta(CAccessor* accessor, AddrType parentBase)
		{
			m_accessor = accessor;
			m_parentBase = parentBase;
		}
		
	private:
		virtual void DebugFuncForDynamicCast() {}//��Ϊ��̬������ͱ������, ���Ѷ���ǵ����õ�virtual��������Ƴ�, ��ע: error C2683: 'dynamic_cast': 'XXX' is not a polymorphic type 

	public:
		CString m_name;
		CAccessor* m_accessor;
		CPropertyGroup* m_parent;
		AddrType m_parentBase;
	};

	using CSharedPropertyNode = TSharedPtr<CPropertyNode>;

	class CPropertyItem : public CPropertyNode
	{
	public:
		static CPropertyItem* Cast(CPropertyNode* base)
		{
			ASSERT(dynamic_cast<CPropertyItem*>(base) != NULL);
			return static_cast<CPropertyItem*>(base);
		}
		static CPropertyItem* CastChecked(CPropertyNode* base)
		{
			return dynamic_cast<CPropertyItem*>(base);
		}
	};
	class CPropertyGroup : public CPropertyNode
	{
	public:
		void AddChild(const CSharedPropertyNode& node)
		{
			this->InsertChild(node, this->GetChildrenCount());
		}
		void InsertChild(const CSharedPropertyNode& node, uint32 idx)
		{
			m_vecChild.insert(m_vecChild.begin() + idx, node);
			node->m_parent = this;
		}
		void DeleteChild(uint32 idx)
		{
			auto& node = m_vecChild[idx];
			node->m_parent = NULL;
			m_vecChild.erase(m_vecChild.begin() + idx);
		}
		uint32 GetChildrenCount() const
		{
			return static_cast<uint32>(m_vecChild.size());
		}

	public:
		static CPropertyGroup* Cast(CPropertyNode* base)
		{
			ASSERT(dynamic_cast<CPropertyGroup*>(base) != NULL);
			return static_cast<CPropertyGroup*>(base);
		}
		static CPropertyGroup* CastChecked(CPropertyNode* base)
		{
			return dynamic_cast<CPropertyGroup*>(base);
		}

		TArrayNif<CSharedPropertyNode> m_vecChild;
	};

	static void BuildPropertyNodeRecursOld(CPropertyGroup* parentGroup, CAccessor* parentAccessor, AddrType parentBase)
	{
		//todo: ��дΪ�ɶ������֧�ؽ�
		if (auto fieldAccessor = CFieldAccessor::CastChecked(parentAccessor))
		{
			auto item = CInstance::New<CPropertyItem>();
			item->InitMeta(fieldAccessor, parentBase);
			parentGroup->AddChild(MakeSharable(item));
		}
		else if (auto objectAccessor = CObjectAccessor::CastChecked(parentAccessor))
		{
			ASSERT(CInheritableType::CastChecked(objectAccessor->GetType()) != NULL);
			auto group = CInstance::New<CPropertyGroup>();
			auto objBase = objectAccessor->GetBaseAddr(parentBase);
			group->InitMeta(objectAccessor, objBase);
			auto count = objectAccessor->GetChildrenCount();
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto childAccessor = objectAccessor->GetChild(idx);
				BuildPropertyNodeRecursOld(group, childAccessor, objBase);
			}
			parentGroup->AddChild(MakeSharable(group));
		}
		else if (auto arrayAccessor = CArrayAccessor::CastChecked(parentAccessor))
		{
			ASSERT(arrayAccessor->GetType() == NULL);
			auto group = CInstance::New<CPropertyGroup>();
			auto arrayBase = arrayAccessor->GetBaseAddr(parentBase);
			group->InitMeta(arrayAccessor, arrayBase);
			auto count = arrayAccessor->GetElementsCount(arrayBase);
			auto elementAccessor = arrayAccessor->GetItemAccessor();
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto elementBase = arrayAccessor->GetItemBaseAddr(arrayBase, idx);
				BuildPropertyNodeRecursOld(group, elementAccessor, elementBase);
			}
			parentGroup->AddChild(MakeSharable(group));
		}
		else
		{
			ASSERT(false);
		}
	}
	static void CreatePropertyNodeRecurs(CPropertyGroup* parentGroup, CAccessor* parentAccessor, AddrType parentBase);
	static void BuildPropertyBranchRecurs(CPropertyGroup* parentGroup, CAccessor* parentAccessor, AddrType parentBase);
	void CreatePropertyNodeRecurs(CPropertyGroup* parentGroup, CAccessor* parentAccessor, AddrType parentBase)
	{
		//todo: ��дΪ�ɶ������֧�ؽ�
		CSharedPropertyNode node;
		if (auto fieldAccessor = CFieldAccessor::CastChecked(parentAccessor))
		{
			auto item = CInstance::New<CPropertyItem>();
			item->InitMeta(fieldAccessor, parentBase);
			node = MakeSharable(item);
		}
		else
		{
			auto group = CInstance::New<CPropertyGroup>();
			auto objBase = parentAccessor->GetBaseAddr(parentBase);
			group->InitMeta(parentAccessor, objBase);
			BuildPropertyBranchRecurs(group, parentAccessor, objBase);
			node = MakeSharable(group);
		}
		parentGroup->AddChild(node);
	}
	void BuildPropertyBranchRecurs(CPropertyGroup* parentGroup, CAccessor* parentAccessor, AddrType parentBase)
	{
		//todo: ��дΪ�ɶ������֧�ؽ�
		if (auto objectAccessor = CObjectAccessor::CastChecked(parentAccessor))
		{
			auto count = objectAccessor->GetChildrenCount();
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto childAccessor = objectAccessor->GetChild(idx);
				CreatePropertyNodeRecurs(parentGroup, childAccessor, parentBase);
			}
		}
		else if (auto arrayAccessor = CArrayAccessor::CastChecked(parentAccessor))
		{
			auto count = arrayAccessor->GetElementsCount(parentBase);
			auto elementAccessor = arrayAccessor->GetItemAccessor();
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto elementBase = arrayAccessor->GetItemBaseAddr(parentBase, idx);
				CreatePropertyNodeRecurs(parentGroup, elementAccessor, elementBase);
			}
		}
		else
		{
			ASSERT(false);
		}
	}

	//todo: ʵ�ֳ������ͽṹ����, ������ɾ��item��group, ��item��group��, �Ա��������, �Զ���������, �༭������
	//todo: �ؼ�����ɿ���ʵ�����ֶ�д����, �ֱ�ΪPropertyNode����ؼ�Node�Ķ�д����, �����пɸ������л�����.
	//	1. Ӧʵ�ֵĹ�����ؼ������������໥ͬ���޸�, ��ڵ�˳��ı��ͬ��, ͬ����Χ��С��һ��Field�����Խڵ�. ��Ҫע����ǿؼ�˳�������Ҫ����, ��Ϊ��Ҫ�����л���ʽ�еĽڵ�˳������Խڵ��ؼ��ڵ��˳����ͬ
	class CPropetyTree
	{
	public:
		void GenerateStackedTypeLayout(CInheritableType* type)
		{
			m_accessorRoot.Clear();
			auto parent = type;
			while (parent != NULL)
			{
				m_accessorRoot.InsertChild(parent->GetSharedAccessorRoot(), 0);
				parent = parent->GetParent();
			}
		}
		void Build(AddrType instanceBase)
		{
			m_root.m_vecChild.clear();
			BuildPropertyBranchRecurs(&m_root, &m_accessorRoot, instanceBase);
		}
		CPropertyGroup m_root;
		CObjectAccessor m_accessorRoot;
	};

	void PrintPropertyRecurs(CPropertyNode* node, uint32 level);
}