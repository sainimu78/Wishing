#pragma once
//#include "Niflect/Module/NiflectModule.h"
#include "Niflect/Base/NiflectTable.h"

namespace Niflect
{
	//class CRuntimeModule : public CModule
	//{
	//public:
	//	static CRuntimeModule* Cast(CModule* base)
	//	{
	//		ASSERT(dynamic_cast<CRuntimeModule*>(base) != NULL);
	//		return static_cast<CRuntimeModule*>(base);
	//	}

	//public:
	//	CNiflectTable m_factory;
	//};
}