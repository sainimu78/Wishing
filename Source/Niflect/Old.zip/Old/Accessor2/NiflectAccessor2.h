#pragma once
#include "Niflect/NiflectCommon.h"

namespace Niflect
{
	typedef void* AddrType2;
	typedef ptrdiff_t AddrOffsetType2;
	typedef uint32 ArrayIndex2;
	
	class CAddrOffset2
	{
	public:
		enum __InternalConst : ptrdiff_t { None };

	public:
		CAddrOffset2()
			: m_offsetInBytes(None)
		{
		}
		CAddrOffset2(const AddrOffsetType2& offsetInBytes)
			: m_offsetInBytes(offsetInBytes)
		{
		}
		void SetOffset(const AddrOffsetType2& offsetInBytes)
		{
			m_offsetInBytes = offsetInBytes;
		}

	public:
		inline AddrType2 GetAddr(const AddrType2& base) const
		{
			return static_cast<char*>(base) + m_offsetInBytes;
		}

	private:
		AddrOffsetType2 m_offsetInBytes;
	};

	template <typename U, typename T>
	inline static AddrOffsetType2 GetMemberVariableOffset2(U T::*member)
	{
		return (char*)&((T*)nullptr->*member) - (char*)nullptr;
	}
}