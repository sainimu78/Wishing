#pragma once
#include "Niflect/Property2/FieldProperty.h"
#include "Niflect/Test2/NiflectGenerated/MyModule/MyField2.gen.h"

namespace MyTestClassScope2
{
	using namespace TreeReadWrite2;

	class CFloatField : public Niflect::CField
	{
	public:
		virtual bool SaveToRwNode(const Niflect::AddrType2& base, CRwNode& rw) const override
		{
			auto& instance = *static_cast<float*>(base);
			auto& rwValue = rw->ToValue();
			return ValueReadWrite::Save(rwValue, instance);
		}
		virtual bool LoadFromRwNode(Niflect::AddrType2& base, const CRwNode& rw) const override
		{
			auto& instance = *static_cast<float*>(base);
			auto& rwValue = rw->ToValue();
			return ValueReadWrite::Load(rwValue, instance);
		}

	public:
		virtual Niflect::CSharedProperty2 CreatePropertyTree(const Niflect::AddrType2& base) override
		{
			auto parentProp = Niflect::MakeShared<Niflect::CFieldProperty>();
			parentProp->InitMeta(this->GetName(), base, true);
			parentProp->SetField(this);
			return parentProp;
		}
	};
	class CStringField : public Niflect::CField
	{
	public:
		virtual bool SaveToRwNode(const Niflect::AddrType2& base, CRwNode& rw) const override
		{
			auto& instance = *static_cast<Niflect::CString*>(base);
			auto& rwValue = rw->ToValue();
			return ValueReadWrite::Save(rwValue, instance);
		}
		virtual bool LoadFromRwNode(Niflect::AddrType2& base, const CRwNode& rw) const override
		{
			auto& instance = *static_cast<Niflect::CString*>(base);
			auto& rwValue = rw->ToValue();
			return ValueReadWrite::Load(rwValue, instance);
		}

	public:
		virtual Niflect::CSharedProperty2 CreatePropertyTree(const Niflect::AddrType2& base) override
		{
			auto parentProp = Niflect::MakeShared<Niflect::CFieldProperty>();
			parentProp->InitMeta(this->GetName(), base, true);
			parentProp->SetField(this);
			return parentProp;
		}
	};
	class CBoolField : public Niflect::CField
	{
	public:
		virtual bool SaveToRwNode(const Niflect::AddrType2& base, CRwNode& rw) const override
		{
			auto& instance = *static_cast<bool*>(base);
			auto& rwValue = rw->ToValue();
			return ValueReadWrite::Save(rwValue, instance);
		}
		virtual bool LoadFromRwNode(Niflect::AddrType2& base, const CRwNode& rw) const override
		{
			auto& instance = *static_cast<bool*>(base);
			auto& rwValue = rw->ToValue();
			return ValueReadWrite::Load(rwValue, instance);
		}

	public:
		virtual Niflect::CSharedProperty2 CreatePropertyTree(const Niflect::AddrType2& base) override
		{
			auto parentProp = Niflect::MakeShared<Niflect::CFieldProperty>();
			parentProp->InitMeta(this->GetName(), base, true);
			parentProp->SetField(this);
			return parentProp;
		}
	};
}