#include "Niflect/Test2/NiflectGenerated/MyModule/MyModule2_0.private.h"
//#include "NiflectGenerated/SampleTest/SampleTest.private.h"

using namespace NiflectModuleReg;
using namespace Niflect;

CNiflectRegistration2* TestCreateModuleReg2_0()
{
	CreateModuleRegistration();
	auto reg = CNiflectRegistration2::StaticGet();
	reg->InitTables();
	reg->RegisterTypes();
	reg->InitTypes();
	reg->InitMethods();
	reg->InitTypesAccessorTree();
	return reg;
}
void TestDestroyModuleReg2_0()
{
	auto reg = CNiflectRegistration2::StaticGet();
	reg->ClearTables();
	DestroyModuleRegistration();
}