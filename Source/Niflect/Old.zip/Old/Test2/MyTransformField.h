#pragma once
#include "Niflect/Test2/MyTransform.h"
#include <sstream>
#include "Niflect/Property2/FieldProperty.h"

namespace MyTestClassScope2
{
	using namespace TreeReadWrite2;

	template <typename T>
	Niflect::CString MyVectorToString(const TMyVector<T>& v)
	{
		std::basic_stringstream<Niflect::CString::value_type, Niflect::CString::traits_type, Niflect::CString::allocator_type> ss;
		ss << v.m_x << ',' << v.m_y << ',' << v.m_z;
		return ss.str();
	}
	template <typename T>
	TMyVector<T> StringToMyVector(const Niflect::CString& str)
	{
		std::basic_stringstream<Niflect::CString::value_type, Niflect::CString::traits_type, Niflect::CString::allocator_type> ss(str);
		TMyVector<T> v;
		char d;
		ss >> v.m_x >> d >> v.m_y >> d >> v.m_z;
		return v;
	}

	template <typename T>
	Niflect::CString MyQuaternionToString(const TMyQuaternion<T>& v)
	{
		std::basic_stringstream<Niflect::CString::value_type, Niflect::CString::traits_type, Niflect::CString::allocator_type> ss;
		ss << v.m_x << ',' << v.m_y << ',' << v.m_z << ',' << v.m_w;
		return ss.str();
	}
	template <typename T>
	TMyQuaternion<T> StringToMyQuaternion(const Niflect::CString& str)
	{
		std::basic_stringstream<Niflect::CString::value_type, Niflect::CString::traits_type, Niflect::CString::allocator_type> ss(str);
		TMyQuaternion<T> v;
		char d;
		ss >> v.m_x >> d >> v.m_y >> d >> v.m_z >> d >> v.m_w;
		return v;
	}
	
	template <typename T>
	class TMyTransformTranslationProperty : public Niflect::CDefaultProperty
	{
	public:
		virtual bool SaveToRwNode(const Niflect::AddrType2& base, CRwNode& rw) const override
		{
			auto& instance = *static_cast<TMyTransform<T>*>(base);
			auto& rwValue = rw->ToValue();
			rwValue->SetString(MyVectorToString<T>(instance.m_translation));
			return true;
		}
		virtual bool LoadFromRwNode(Niflect::AddrType2& base, const CRwNode& rw) const override
		{
			auto& instance = *static_cast<TMyTransform<T>*>(base);
			auto& rwValue = rw->ToValue();
			instance.m_translation = StringToMyVector<T>(rwValue->GetString());
			return true;
		}
	};

	template <typename T>
	class TMyTransformRotationProperty : public Niflect::CDefaultProperty
	{
	public:
		virtual bool SaveToRwNode(const Niflect::AddrType2& base, CRwNode& rw) const override
		{
			auto& instance = *static_cast<TMyTransform<T>*>(base);
			auto& rwValue = rw->ToValue();
			rwValue->SetString(MyQuaternionToString<T>(instance.m_rotation));
			return true;
		}
		virtual bool LoadFromRwNode(Niflect::AddrType2& base, const CRwNode& rw) const override
		{
			auto& instance = *static_cast<TMyTransform<T>*>(base);
			auto& rwValue = rw->ToValue();
			instance.m_rotation = StringToMyQuaternion<T>(rwValue->GetString());
			return true;
		}
	};

	template <typename T>
	class TMyTransformScaleProperty : public Niflect::CDefaultProperty
	{
	public:
		virtual bool SaveToRwNode(const Niflect::AddrType2& base, CRwNode& rw) const override
		{
			auto& instance = *static_cast<TMyTransform<T>*>(base);
			auto& rwValue = rw->ToValue();
			rwValue->SetString(MyVectorToString<T>(instance.m_scale));
			return true;
		}
		virtual bool LoadFromRwNode(Niflect::AddrType2& base, const CRwNode& rw) const override
		{
			auto& instance = *static_cast<TMyTransform<T>*>(base);
			auto& rwValue = rw->ToValue();
			instance.m_scale = StringToMyVector<T>(rwValue->GetString());
			return true;
		}
	};

	template <typename T>
	class TMyTransformField : public Niflect::CField
	{
	public:
		virtual bool SaveToRwNode(const Niflect::AddrType2& base, CRwNode& rw) const override
		{
			auto& instance = *static_cast<TMyTransform<T>*>(base);
			AddRwString(rw, "m_translation", MyVectorToString<T>(instance.m_translation));
			AddRwString(rw, "m_rotation", MyQuaternionToString<T>(instance.m_rotation));
			AddRwString(rw, "m_scale", MyVectorToString<T>(instance.m_scale));
			return true;
		}
		virtual bool LoadFromRwNode(Niflect::AddrType2& base, const CRwNode& rw) const override
		{
			auto& instance = *static_cast<TMyTransform<T>*>(base);
			instance.m_translation = StringToMyVector<T>(FindRwString(rw, "m_translation"));
			instance.m_rotation = StringToMyQuaternion<T>(FindRwString(rw, "m_rotation"));
			instance.m_scale = StringToMyVector<T>(FindRwString(rw, "m_scale"));
			return true;
		}

	public:
		virtual Niflect::CSharedProperty2 CreatePropertyTree(const Niflect::AddrType2& base) override
		{
			auto parentProp = Niflect::MakeShared<Niflect::CFieldProperty>();
			parentProp->InitMeta(this->GetName(), base, false);
			parentProp->SetField(this);
			{
				auto childProp = Niflect::MakeShared<TMyTransformTranslationProperty<T> >();
				childProp->InitMeta("My Translation", base, true);
				parentProp->AddChild(childProp);
			}
			{
				auto childProp = Niflect::MakeShared<TMyTransformRotationProperty<T> >();
				childProp->InitMeta("My Rotation", base, true);
				parentProp->AddChild(childProp);
			}
			{
				auto childProp = Niflect::MakeShared<TMyTransformScaleProperty<T> >();
				childProp->InitMeta("My Scale", base, true);
				parentProp->AddChild(childProp);
			}
			return parentProp;
		}
	};

	typedef TMyTransformField<float> CMyTransformFloatField;
}