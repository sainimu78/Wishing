#pragma once
#include "Niflect/Base/NiflectMacro.h"
#include "Niflect/Type/RegisteredType2.h"

namespace MyTestClassScope2
{
	template <typename T>
	class TMyTransform;

	typedef TMyTransform<float> CMyTrasformFloat;
}

namespace Niflect
{
	template <>
	CNiflectType2* StaticGetType2<MyTestClassScope2::CMyTrasformFloat>()
	{
		return TInternalRegisteredType2<MyTestClassScope2::CMyTrasformFloat>::s_type;
	}
}