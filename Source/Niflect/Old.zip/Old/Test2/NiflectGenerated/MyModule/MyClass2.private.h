#pragma once
#include "Niflect/Type/NiflectTable2.h"
#include "Niflect/Field/CompoundField.h"
#include "Niflect/Field/ArrayField.h"
#include "Niflect/Field/MapField.h"
#include "Niflect/Test2/MyClass2.h"
#include "Niflect/Test2/MyField2.h"
#include "Niflect/Test2/MyTransformField.h"
#include "Niflect/Field/PointerField.h"
#include "Niflect/Field/EnumField.h"

namespace MyTestClassScope2
{
	using namespace Niflect;

	class CInheritableTypeReg_CMyClass0
	{
	public:
		static void StaticRegisterType(CNiflectTable2& table)
		{
			table.RegisterTypeDefaultTypeHash<CClass2, CMyClass0>("CMyClass0", &StaticCreateAccessorTree);
		}
		static void StaticInitInheritance()
		{
			auto type = CClass2::Cast(StaticGetType2<CMyClass0>());
			type->InitInheritableTypeMeta(NULL);
		}
		static CSharedField StaticCreateAccessorTree()
		{
			auto shared0 = CreateField<CCompoundField, CMyClass0>();
			auto field0 = shared0.Get();
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_float_0", GetMemberVariableOffset2(&CMyClass0::m_float_0), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_float_1", GetMemberVariableOffset2(&CMyClass0::m_float_1), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticRegisterOrGetTemplateType<CPointerField, float*>("float*", typeid(float*).hash_code());
				auto shared1 = type->CreateFieldLayout();
				auto field1 = Cast<CPointerField>(shared1.Get());
				{
					auto type = StaticGetType2<CFloatField>();
					auto shared2 = type->CreateFieldLayout();
					auto field2 = shared2.Get();
					field2->InitMemberMeta("reserved_dim0", CAddrOffset2::None, field1);
					field1->SetPointingField(shared2);
				}
				field1->InitMemberMeta("m_float_pointer_2", GetMemberVariableOffset2(&CMyClass0::m_float_pointer_2), field0);
				field0->AddChild(shared1);
			}
			return shared0;
		}
	};
	class CInheritableTypeReg_CMyClassBase0
	{
	public:
		static void StaticRegisterType(CNiflectTable2& table)
		{
			table.RegisterTypeDefaultTypeHash<CClass2, CMyClassBase0>("CMyClassBase0", &StaticCreateAccessorTree);
		}
		static void StaticInitInheritance()
		{
			auto type = CClass2::Cast(StaticGetType2<CMyClassBase0>());
			type->InitInheritableTypeMeta(NULL);
		}
		static CSharedField StaticCreateAccessorTree()
		{
			auto shared0 = CreateField<CCompoundField, CMyClassBase0>();
			auto field0 = shared0.Get();
			{
				auto type = StaticGetType2<CStringField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_base_str_0", GetMemberVariableOffset2(&CMyClassBase0::m_base_str_0), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_base_float_1", GetMemberVariableOffset2(&CMyClassBase0::m_base_float_1), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_base_float_2", GetMemberVariableOffset2(&CMyClassBase0::m_base_float_2), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticRegisterOrGetTemplateType<CPointerField, float**>("float**", typeid(float**).hash_code());
				auto shared1 = type->CreateFieldLayout();
				auto field1 = Cast<CPointerField>(shared1.Get());
				{
					auto type = StaticRegisterOrGetTemplateType<CPointerField, float*>("float*", typeid(float*).hash_code());
					auto shared2 = type->CreateFieldLayout();
					auto field2 = Cast<CPointerField>(shared2.Get());
					{
						auto type = StaticGetType2<CFloatField>();
						auto shared3 = type->CreateFieldLayout();
						auto field3 = shared3.Get();
						field3->InitMemberMeta("reserved_dim1", CAddrOffset2::None, field2);
						field2->SetPointingField(shared3);
					}
					field2->InitMemberMeta("reserved_dim0", CAddrOffset2::None, field1);
					field1->SetPointingField(shared2);
				}
				field1->InitMemberMeta("m_base_float_pointer2D_3", GetMemberVariableOffset2(&CMyClassBase0::m_base_float_pointer2D_3), field0);
				field0->AddChild(shared1);
			}
			return shared0;
		}
		static void InvokeMethod_MyFunc0(AddrType2 obj, AddrType2* inputInstanceArray, AddrType2* ouputInstanceArray, const TArrayNif<CNiflectType2*>& vecInputType, const TArrayNif<CNiflectType2*>& vecOutputType)
		{
			auto& arg0 = vecInputType[0]->GetInstanceRef<float>(inputInstanceArray[0]);
			auto& arg1 = vecInputType[1]->GetInstanceRef<CMyClass0>(inputInstanceArray[1]);
			auto& arg2 = vecInputType[2]->GetInstanceRef<bool*>(inputInstanceArray[2]);
			auto& arg3 = vecInputType[3]->GetInstanceRef<CMyClass0*>(inputInstanceArray[3]);
			auto& arg4 = vecInputType[4]->GetInstanceRef<float**>(inputInstanceArray[4]);
			auto& ret0 = vecOutputType[0]->GetInstanceRef<bool>(ouputInstanceArray[0]);
			ret0 = static_cast<CMyClassBase0*>(obj)->MyFunc0(arg0, arg1, arg2, arg3, arg4);
		}
		static void StaticInitMethods()
		{
			auto type = Cast<CClass2>(StaticGetType2<CMyClassBase0>());
			CNiflectMethod2 method;
			method.m_InvokeFunc = &InvokeMethod_MyFunc0;
			method.m_vecInputType.push_back(StaticGetType2<CFloatField>());
			method.m_vecInputType.push_back(StaticGetType2<CMyClass0>());
			method.m_vecInputType.push_back(StaticRegisterOrGetTemplateType<CPointerField, bool*>("bool*", typeid(bool*).hash_code()));
			method.m_vecInputType.push_back(StaticRegisterOrGetTemplateType<CPointerField, CMyClass0*>("CMyClass0*", typeid(CMyClass0*).hash_code()));
			method.m_vecInputType.push_back(StaticRegisterOrGetTemplateType<CPointerField, float**>("float**", typeid(float**).hash_code()));
			method.m_vecOutputType.push_back(StaticGetType2<CBoolField>());
			type->m_vecMethod.push_back(method);
		}
	};
	class CEnumReg_EMyEnum_OptionStyle
	{
	public:
		static void StaticRegisterType(CNiflectTable2& table)
		{
			table.RegisterTypeDefaultTypeHash<CEnum2, EMyEnum_OptionStyle>("EMyEnum_OptionStyle", &StaticCreateFieldLayout);
		}
		static void StaticInitEnumMeta()
		{
			auto type = Cast<CEnum2>(StaticGetType2<EMyEnum_OptionStyle>());
			CEnumMeta meta;
			meta.m_vecEnumConstant.push_back("None");
			meta.m_vecEnumConstant.push_back("Option0");
			meta.m_vecEnumConstant.push_back("Option1");
			meta.m_vecEnumConstant.push_back("Option2");
			type->InitEnumMeta(meta);
		}
		static CSharedField StaticCreateFieldLayout()
		{
			auto shared0 = CreateField<CEnumField, EMyEnum_OptionStyle>();
			auto field0 = shared0.Get();
			return shared0;
		}
	};
	class CInheritableTypeReg_CMyClass1
	{
	public:
		static void StaticRegisterType(CNiflectTable2& table)
		{
			table.RegisterTypeDefaultTypeHash<CClass2, CMyClass1>("CMyClass1", &StaticCreateAccessorTree);
		}
		static void StaticInitInheritance()
		{
			auto type = CClass2::Cast(StaticGetType2<CMyClass1>());
			type->InitInheritableTypeMeta(CClass2::Cast(StaticGetType2<CMyClassBase0>()));
		}
		static CSharedField StaticCreateAccessorTree()
		{
			auto shared0 = CreateField<CCompoundField, CMyClass1>();
			auto field0 = shared0.Get();
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_float_0", GetMemberVariableOffset2(&CMyClass1::m_float_0), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CMyClass0>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_obj_1", GetMemberVariableOffset2(&CMyClass1::m_obj_1), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticRegisterOrGetTemplateTypeDefaultTypeHash<CArrayField, TArrayNif<float> >("TArrayNif<float>");
				auto shared1 = type->CreateFieldLayout();
				auto field1 = CArrayField::Cast(shared1.Get());
				{
					auto type = StaticGetType2<CFloatField>();
					auto shared2 = type->CreateFieldLayout();
					auto field2 = shared2.Get();
					field2->InitMemberMeta("reserved_dim0", CAddrOffset2::None, field1);
					field1->AddTemplateArgumentField(shared2);
				}
				field1->InitMemberMeta("m_array_2", GetMemberVariableOffset2(&CMyClass1::m_array_2), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_float_3", GetMemberVariableOffset2(&CMyClass1::m_float_3), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticRegisterOrGetTemplateTypeDefaultTypeHash<CArrayField, TArrayNif<CMyClass0> >("TArrayNif<CMyClass0>");
				auto shared1 = type->CreateFieldLayout();
				auto field1 = Cast<CArrayField>(shared1.Get());
				{
					auto type = StaticGetType2<CMyClass0>();
					auto shared2 = type->CreateFieldLayout();
					auto field2 = shared2.Get();
					field2->InitMemberMeta("reserved_dim0", CAddrOffset2::None, field1);
					field1->AddTemplateArgumentField(shared2);
				}
				field1->InitMemberMeta("m_array_4", GetMemberVariableOffset2(&CMyClass1::m_array_4), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_float_5", GetMemberVariableOffset2(&CMyClass1::m_float_5), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticRegisterOrGetTemplateTypeDefaultTypeHash<CArrayField, TArrayNif<TArrayNif<float> > >("TArrayNif<TArrayNif<float> >");
				auto shared1 = type->CreateFieldLayout();
				auto field1 = Cast<CArrayField>(shared1.Get());
				{
					auto type = StaticRegisterOrGetTemplateTypeDefaultTypeHash<CArrayField, TArrayNif<float> >("TArrayNif<float>");
					auto shared2 = type->CreateFieldLayout();
					auto field2 = CArrayField::Cast(shared2.Get());
					{
						auto type = StaticGetType2<CFloatField>();
						auto shared3 = type->CreateFieldLayout();
						auto field3 = shared3.Get();
						field3->InitMemberMeta("reserved_dim1", CAddrOffset2::None, field2);
						field2->AddTemplateArgumentField(shared3);
					}
					field2->InitMemberMeta("reserved_dim0", CAddrOffset2::None, field1);
					field1->AddTemplateArgumentField(shared2);
				}
				field1->InitMemberMeta("m_array_6", GetMemberVariableOffset2(&CMyClass1::m_array_6), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_float_7", GetMemberVariableOffset2(&CMyClass1::m_float_7), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CMyTrasformFloat>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_tm_8", GetMemberVariableOffset2(&CMyClass1::m_tm_8), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_float_9", GetMemberVariableOffset2(&CMyClass1::m_float_9), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CStringField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_str_10", GetMemberVariableOffset2(&CMyClass1::m_str_10), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_float_11", GetMemberVariableOffset2(&CMyClass1::m_float_11), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticRegisterOrGetTemplateTypeDefaultTypeHash<CMapField, TMap<Niflect::CString, float> >("TMap<Niflect::CString, float>");
				auto shared1 = type->CreateFieldLayout();
				auto field1 = Cast<CMapField>(shared1.Get());
				{
					auto type = StaticRegisterOrGetTemplateTypeDefaultTypeHash<CCompoundTemplateField, std::pair<const Niflect::CString, float> >("std::pair<Niflect::CString, float>");
					auto shared2 = type->CreateFieldLayout();
					auto field2 = shared2.Get();
					{
						auto type = StaticGetType2<CStringField>();
						auto shared3 = type->CreateFieldLayout();
						auto field3 = shared3.Get();
						field3->InitMemberMeta("key", GetMemberVariableOffset2(&std::pair<const Niflect::CString, float>::first), field2);
						field2->AddChild(shared3);
					}
					{
						auto type = StaticGetType2<CFloatField>();
						auto shared3 = type->CreateFieldLayout();
						auto field3 = shared3.Get();
						field3->InitMemberMeta("value", GetMemberVariableOffset2(&std::pair<const Niflect::CString, float>::second), field2);
						field2->AddChild(shared3);
					}
					field2->InitMemberMeta("reserved_dim0", CAddrOffset2::None, field1);
					field1->AddTemplateArgumentField(shared2);
				}
				field1->InitMemberMeta("m_map_12", GetMemberVariableOffset2(&CMyClass1::m_map_12), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_float_13", GetMemberVariableOffset2(&CMyClass1::m_float_13), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<EMyEnum_OptionStyle>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_enum_14", GetMemberVariableOffset2(&CMyClass1::m_enum_14), field0);
				field0->AddChild(shared1);
			}
			{
				auto type = StaticGetType2<CFloatField>();
				auto shared1 = type->CreateFieldLayout();
				auto field1 = shared1.Get();
				field1->InitMemberMeta("m_float_15", GetMemberVariableOffset2(&CMyClass1::m_float_15), field0);
				field0->AddChild(shared1);
			}
			return shared0;
		}
	};
}
