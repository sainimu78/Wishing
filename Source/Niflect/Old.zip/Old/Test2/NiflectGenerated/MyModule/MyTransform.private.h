#pragma once
#include "Niflect/Type/NiflectTable2.h"
#include "Niflect/Test2/MyTransformField.h"

namespace MyTestClassScope2
{
	using namespace Niflect;

	class CInheritableTypeReg_CMyTransformFloat
	{
	public:
		static void StaticRegisterType(CNiflectTable2& table)
		{
			table.RegisterTypeDefaultTypeHash<CClass2, CMyTransformFloat>("CMyTransformFloat", &StaticCreateAccessorTree);
		}
		static void StaticInitInheritance()
		{
		}
		static CSharedField StaticCreateAccessorTree()
		{
			auto shared0 = CreateField<CMyTransformFloatField, CMyTransformFloat>();
			auto field0 = shared0.Get();
			return shared0;
		}
	};
}