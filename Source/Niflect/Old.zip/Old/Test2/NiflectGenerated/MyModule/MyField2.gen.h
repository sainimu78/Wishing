#pragma once
#include "Niflect/Base/NiflectMacro.h"
#include "Niflect/Type/RegisteredType2.h"

namespace MyTestClassScope2
{
	class CFloatField;
	class CStringField;
	class CBoolField;
}

namespace Niflect
{
	template <>
	CNiflectType2* StaticGetType2<MyTestClassScope2::CFloatField>()
	{
		return TInternalRegisteredType2<MyTestClassScope2::CFloatField>::s_type;
	}
	template <>
	CNiflectType2* StaticGetType2<MyTestClassScope2::CStringField>()
	{
		return TInternalRegisteredType2<MyTestClassScope2::CStringField>::s_type;
	}
	template <>
	CNiflectType2* StaticGetType2<MyTestClassScope2::CBoolField>()
	{
		return TInternalRegisteredType2<MyTestClassScope2::CBoolField>::s_type;
	}
}