#pragma once
#include "Niflect/Base/NiflectMacro.h"
#include "Niflect/Type/RegisteredType2.h"

namespace MyTestClassScope2
{
	class CMyClass0;
	class CMyClassBase0;
	class CMyClass1;
	//template <typename T>
	//class TMyTransform;
	////using CMyTransform = TMyTransform<float>;
}

namespace Niflect
{
	template <>
	CNiflectType2* StaticGetType2<MyTestClassScope2::CMyClass0>()
	{
		return TInternalRegisteredType2<MyTestClassScope2::CMyClass0>::s_type;
	}
	template <>
	CNiflectType2* StaticGetType2<MyTestClassScope2::CMyClassBase0>()
	{
		return TInternalRegisteredType2<MyTestClassScope2::CMyClassBase0>::s_type;
	}
	//template <>
	//CNiflectType* StaticGetType<MyTestClassScope::TMyTransform<float> >()
	//{
	//	return TInternalRegisteredType<MyTestClassScope::TMyTransform<float> >::s_type;
	//}
	template <>
	CNiflectType2* StaticGetType2<MyTestClassScope2::CMyClass1>()
	{
		return TInternalRegisteredType2<MyTestClassScope2::CMyClass1>::s_type;
	}
}

#define CURRENT_FILE_ID_55_GENERATED_BODY \
	friend class CMyClass0;

#define CURRENT_FILE_ID_73_GENERATED_BODY \
	friend class CMyClassBase0;

#define CURRENT_FILE_ID_94_GENERATED_BODY \
	friend class CMyClass1;

#define BODY_MACRO_COMBINE_INNER(A,B,C,D) A##B##C##D
#define BODY_MACRO_COMBINE(A,B,C,D) BODY_MACRO_COMBINE_INNER(A,B,C,D)
#define GENERATED_BODY(...) BODY_MACRO_COMBINE(CURRENT_FILE_ID,_,__LINE__,_GENERATED_BODY)