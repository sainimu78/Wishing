#pragma once
#include "Niflect/Type/NiflectRegistration2.h"
#include "Niflect/Test2/NiflectGenerated/MyModule/MyField2.private.h"
#include "Niflect/Test2/NiflectGenerated/MyModule/MyClass2.private.h"
#include "Niflect/Test2/NiflectGenerated/MyModule/MyTransform.private.h"

namespace Niflect
{
	CSharedRegistration2 CNiflectRegistration2::s_reg;
}

namespace NiflectModuleReg
{
	using namespace Niflect;
	
	class CModuleReg_MyModule2_0 : public CNiflectRegistration2
	{
	protected:
		virtual void DoInitTables() override
		{
			{
				auto table = this->AddNewTable();
				table->Init(CString());
			}
		}
		//todo: ����ǰ�������ռ�, ʵ��Ԥ�����, #1, ..., #3, �ɲ���ִ��(�� parallel for)
		virtual void DoRegisterTypes() override
		{
			//#1, ����ģ�������� Reflector Type
			{
				auto& table = this->GetMutableTable(0);
				MyTestClassScope2::CInheritableTypeReg_CFloatField::StaticRegisterType(table);//todo: ����������Ҫ����һ��ע������, ��ģ���ֹ�ע�ᷴ��������
				MyTestClassScope2::CInheritableTypeReg_CStringField::StaticRegisterType(table);
				MyTestClassScope2::CInheritableTypeReg_CBoolField::StaticRegisterType(table);
				MyTestClassScope2::CEnumReg_EMyEnum_OptionStyle::StaticRegisterType(table);
				MyTestClassScope2::CInheritableTypeReg_CMyClass0::StaticRegisterType(table);
				MyTestClassScope2::CInheritableTypeReg_CMyClassBase0::StaticRegisterType(table);
				MyTestClassScope2::CInheritableTypeReg_CMyTransformFloat::StaticRegisterType(table);
				MyTestClassScope2::CInheritableTypeReg_CMyClass1::StaticRegisterType(table);
			}
		}
		virtual void DoInitTypes() const override
		{
			//#2, �����Ϣ
			{
				MyTestClassScope2::CInheritableTypeReg_CFloatField::StaticInitInheritance();//todo: ����������Ҫ����һ��ע������, ��ģ���ֹ�ע�ᷴ��������
				MyTestClassScope2::CInheritableTypeReg_CStringField::StaticInitInheritance();
				MyTestClassScope2::CInheritableTypeReg_CBoolField::StaticInitInheritance();
				MyTestClassScope2::CEnumReg_EMyEnum_OptionStyle::StaticInitEnumMeta();
				MyTestClassScope2::CInheritableTypeReg_CMyClass0::StaticInitInheritance();
				MyTestClassScope2::CInheritableTypeReg_CMyClassBase0::StaticInitInheritance();
				MyTestClassScope2::CInheritableTypeReg_CMyTransformFloat::StaticInitInheritance();
				MyTestClassScope2::CInheritableTypeReg_CMyClass1::StaticInitInheritance();
			}
		}
		virtual void DoInitMethods() const override
		{
			MyTestClassScope2::CInheritableTypeReg_CMyClassBase0::StaticInitMethods();
		}
		virtual void DoInitTypesAccessorTree() override
		{
			//#3, ����AccessorTree, ��Ҫ�������л�
			for (uint32 idx0 = 0; idx0 < this->GetTablesCount(); ++idx0)
			{
				auto& table = this->GetMutableTable(idx0);
				for (auto& it : table.m_vecType)
					it->InitFieldLayout();
			}
		}
	};

	static void CreateModuleRegistration()
	{
		CNiflectRegistration2::StaticCreate<CModuleReg_MyModule2_0>();
	}
	
	static void DestroyModuleRegistration()
	{
		CNiflectRegistration2::StaticDestroy();
	}
}

Niflect::CNiflectRegistration2* GetNiflectModuleRegistration2()
{
	return Niflect::CNiflectRegistration2::StaticGet();
}