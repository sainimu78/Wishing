#include "Niflect/Test2/MyField2.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"
#include "Niflect/Field/ArrayField.h"
#include "Niflect/Field/CompoundField.h"
#include "Niflect/Test2/MyClass2.h"
#include "Niflect/Util/DebugUtil.h"
#include "Niflect/Test2/TestModule2_0.h"

namespace Niflect
{
	CString DebugSavePropertyString(CProperty2* prop, const AddrType2& base);
	void DebugLoadPropertyString(CProperty2* prop, const AddrType2& base, const CString& buffer);

	CString DebugSavePropertyString(CProperty2* prop, const AddrType2&  base)
	{
		CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
		CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
		//CRwJson::AllocatorStack stack;
		//CRwJson::AllocatorPool allocator(poolCapa, &stack);
		CRwJson::AllocatorStack stack;
		auto& allocator = stack;
		CRwJson::Document jd(&allocator, poolCapa, &allocator);
		auto& joRoot = CRwJson::AsRoot(jd);
		CJsonRwDocument doc(jd, joRoot);
		auto rwRoot = doc.GetRootNode();
		prop->SaveToRwNode(base, rwRoot);
		CRwJson::StringBuffer stm(&allocator, poolCapa);
		CRwJson::WriteToBuffer(joRoot, stm);
		return stm.GetString();
	}
	void DebugLoadPropertyString(CProperty2* prop, AddrType2& base, const CString& buffer)
	{
		CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
		CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
		//CRwJson::AllocatorStack stack;
		//CRwJson::AllocatorPool allocator(poolCapa, &stack);
		CRwJson::AllocatorStack stack;
		auto& allocator = stack;
		CRwJson::Document jd(&allocator, poolCapa, &allocator);
		auto& joRoot = CRwJson::ReadFromBuffer(jd, buffer.data());
		CJsonRwDocument doc(jd, joRoot);
		auto rwRoot = doc.GetRootNode();
		prop->LoadFromRwNode(base, rwRoot);
	}

	static void PrintPropertyRecurs(CProperty2* parentProp, uint32 level = 0)
	{
		auto strLevel = NiflectUtil::DebugIndentToString(level);
		CString strValue;
		if (parentProp->GetBase() == NULL)
			strValue = "Root";
		else
			strValue = "Not a value";
		if (parentProp->GetChildrenCount() == 0)
		{
			auto base = parentProp->GetBase();
			strValue = DebugSavePropertyString(parentProp, base);
		}
		printf("%s%s, %s\n", strLevel.c_str(), parentProp->GetName().c_str(), strValue.c_str());

		level++;
		for (uint32 idx = 0; idx < parentProp->GetChildrenCount(); ++idx)
			PrintPropertyRecurs(parentProp->GetChild(idx), level);
	}
}

static void TestSimpleClass()
{
	using namespace MyTestClassScope2;
	using namespace Niflect;

	auto type = StaticGetType2<CMyClass0>();
	auto field0 = type->GetRootField();

	CMyClass0 srcData;
	srcData.m_float_0 = 1.23f;
	srcData.m_float_1 = 4.56f;

	auto rootProp = field0->CreatePropertyTree(&srcData);
	PrintPropertyRecurs(rootProp.Get());
}
static void TestDefaultArray()
{
	using namespace MyTestClassScope2;
	using namespace Niflect;
	
	auto shared0 = CreateField<CArrayField, TArrayNif<float> >();
	auto field0 = shared0.Get();
	{
		auto shared1 = Niflect::MakeShared<CFloatField>();
		auto field1 = shared1.Get();
		field1->InitMemberMeta("reserved_dim0", CAddrOffset2::None, field0);
		field0->AddTemplateArgumentField(shared1);
	}

	TArrayNif<float> srcData;
	srcData.push_back(1.0f);
	srcData.push_back(2.0f);

	auto rootProp = field0->CreatePropertyTree(&srcData);
	PrintPropertyRecurs(rootProp.Get());
}
static void TestTypicalClass()
{
	using namespace MyTestClassScope2;
	using namespace Niflect;
	
	TArrayNif<CField*> vecField;
	auto baseType = StaticGetType2<CMyClassBase0>();
	auto derivedType = StaticGetType2<CMyClass1>();
	auto baseField = baseType->GetRootField();
	auto derivedField = derivedType->GetRootField();
	vecField.push_back(baseField);
	vecField.push_back(derivedField);

	CMyClass1 srcData;
	TestInit_CMyClass1(srcData);

	auto base = &srcData;
	auto rootProp = MakeShared<CDefaultProperty>();
	for (auto& it : vecField)
	{
		auto childProp = it->CreatePropertyTree(base);
		rootProp->AddChild(childProp);
	}

	PrintPropertyRecurs(rootProp.Get());
}
static void TestCustomField()
{
	using namespace MyTestClassScope2;
	using namespace Niflect;

	auto shared0 = MakeShared<TMyTransformField<float> >();
	auto field0 = shared0.Get();

	TMyTransform<float> srcData;
	TestInit_TMyTransform(srcData);
	auto rootProp = field0->CreatePropertyTree(&srcData);
	PrintPropertyRecurs(rootProp.Get());
}

static void MyExp()
{
	auto memTest = Niflect::DebugGetMemoryStats();
	TestCreateModuleReg2_0();
	TestTypicalClass();
	TestDestroyModuleReg2_0();
	printf("");
}

#ifdef TEST_FOR_GCC
#else
#include <Windows.h>
class CStaticTest
{
public:
	CStaticTest()
	{
#ifdef WIN32
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
#endif
		MyExp();
	}
};
//CStaticTest s;
#endif

#ifdef TEST_FOR_GCC
int main()
{
	MyExp();
	return 0;
}
#else
#endif