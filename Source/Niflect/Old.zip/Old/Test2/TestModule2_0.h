#pragma once
#include "Niflect/Type/NiflectRegistration2.h"

Niflect::CNiflectRegistration2* TestCreateModuleReg2_0();
void TestDestroyModuleReg2_0();