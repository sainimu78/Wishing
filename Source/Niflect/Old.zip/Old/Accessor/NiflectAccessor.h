#pragma once
#include "Niflect/Accessor/NiflectAccessDelegate.h"

namespace Niflect
{
	class CNiflectType;

	//todo: PropertyTree�ȹ�����Ҫ�õ�CastChecked, ����ת�������ر�����, �ɿ����Ƿ�Cast��CastChecked��װר�ŵĺ���, �Է���������ش���

	class CAccessor
	{
	public:
		CAccessor()
			: m_type(NULL)
			, m_owner(NULL)
		{
		}

	public:
		NIFLECT_API void InitMeta(CNiflectType* type);
		NIFLECT_API void InitMemberMeta(const CString& name, CAccessor* owner);
		NIFLECT_API CNiflectType* GetType() const;
		NIFLECT_API const CString& GetName() const;
		CAccessor* GetOwner() const;
		void SetOffset(const AddrOffsetType& offset)
		{
			m_offsetAddr.SetOffset(offset);
		}

	public:
		inline AddrType GetBaseAddr(AddrType base) const
		{
			return m_offsetAddr.GetAddr(base);
		}
		template <typename T>
		inline T& GetInstanceRef(AddrType base) const
		{
			return *static_cast<T*>(this->GetBaseAddr(base));
		}

	public:
		NIFLECT_API virtual bool SaveToRwNode(const AddrType base, CRwNode& rw) const = 0;
		NIFLECT_API virtual bool LoadFromRwNode(AddrType base, const CRwNode& rw) const = 0;

	private:
		CString m_name;
		CNiflectType* m_type;
		CAccessor* m_owner;//���ݶ�����Ϊowner, ��parent����������, ��֮ͬ������parent��children��Ӧ, ��owner��һ������"children", ��˳���owner, ��ֻ���򸸼��������, ������ھ���children��CObjectAccessor��owner�ɵ���parent
		CAddrOffset m_offsetAddr;
	};
	
	using CSharedAccessor = TSharedPtr<CAccessor>;

	typedef CSharedAccessor (*InvokeCreateAccessorTreeFunc)(AddrOffsetType offset);
	
	//��ʵ��ֻ֧�ֻ��ڳ�Ա��ַƫ�Ƶ�Accessor, ����ʹ��Delegate���, ��ΪԤ��֧��������ʽ����ڳ�Ա�����ķ�ʽ���ʳ�Ա����

	class CFieldAccessor : public CAccessor
	{
	public:
		void SetDelegateSave(const CDelegateSave& save)
		{
			m_save = save;
		}
		void SetDelegateLoad(const CDelegateLoad& load)
		{
			m_load = load;
		}

	public:
		NIFLECT_API virtual bool SaveToRwNode(const AddrType base, CRwNode& rw) const override;
		NIFLECT_API virtual bool LoadFromRwNode(AddrType base, const CRwNode& rw) const override;

	public:
		static CFieldAccessor* DebugCast(CAccessor* base)
		{
			ASSERT(dynamic_cast<CFieldAccessor*>(base) != NULL);
			return static_cast<CFieldAccessor*>(base);
		}
		static CFieldAccessor* CastChecked(CAccessor* base)
		{
			return dynamic_cast<CFieldAccessor*>(base);
		}

	private:
		CDelegateSave m_save;
		CDelegateLoad m_load;
	};

	using CSharedFieldAccessor = TSharedPtr<CFieldAccessor>;

	class CObjectAccessor : public CAccessor
	{
	public:
		NIFLECT_API virtual bool SaveToRwNode(const AddrType base, CRwNode& rw) const override;
		NIFLECT_API virtual bool LoadFromRwNode(AddrType base, const CRwNode& rw) const override;

	public:
		NIFLECT_API void AddChild(const CSharedAccessor& node);
		NIFLECT_API void InsertChild(const CSharedAccessor& node, uint32 idx);
		NIFLECT_API uint32 GetChildrenCount() const;
		NIFLECT_API CAccessor* GetChild(uint32 idx) const;
		void Clear();

	public:
		static CObjectAccessor* Cast(CAccessor* base)
		{
			ASSERT(dynamic_cast<CObjectAccessor*>(base) != NULL);
			return static_cast<CObjectAccessor*>(base);
		}
		static CObjectAccessor* CastChecked(CAccessor* base)
		{
			return dynamic_cast<CObjectAccessor*>(base);
		}

	private:
		TArrayNif<CSharedAccessor> m_vecChild;
	};

	using CSharedObjectAccessor = TSharedPtr<CObjectAccessor>;

	class CArrayAccessor : public CAccessor
	{
	public:
		void SetDelegateGetItemBaseAddr(const CDelegateArrayItem& getItemBaseAddr)
		{
			m_getItemBaseAddr = getItemBaseAddr;
		}
		void SetDelegateGetItemsCount(const CDelegateArrayGetItemsCount& getItemsCount)
		{
			m_getItemsCount = getItemsCount;
		}
		void SetDelegateSetItemsCount(const CDelegateArraySetItemsCount& setItemsCount)
		{
			m_setItemsCount = setItemsCount;
		}

	public:
		void SetItemAccessor(const CSharedAccessor& accessor);
		CAccessor* GetItemAccessor() const;

	public:
		AddrType GetItemBaseAddr(AddrType base, ArrayIndex idx) const;
		ArrayIndex GetElementsCount(AddrType base) const;
		void SetElementsCount(AddrType base, ArrayIndex count) const;

	public:
		virtual bool SaveToRwNode(const AddrType base, CRwNode& rw) const override;
		virtual bool LoadFromRwNode(AddrType base, const CRwNode& rw) const override;

	public:
		bool SaveItemToRwNode(const AddrType base, ArrayIndex idx, CRwNode& rw) const;
		bool LoadItemFromRwNode(AddrType base, ArrayIndex idx, const CRwNode& rw) const;
		
	public:
		static CArrayAccessor* Cast(CAccessor* base)
		{
			ASSERT(dynamic_cast<CArrayAccessor*>(base) != NULL);
			return static_cast<CArrayAccessor*>(base);
		}
		static CArrayAccessor* CastChecked(CAccessor* base)
		{
			return dynamic_cast<CArrayAccessor*>(base);
		}

	private:
		CSharedAccessor m_itemAccessor;//todo: ����Ϊelement, ͳһ����, ����array��element������
		CDelegateArrayItem m_getItemBaseAddr;
		CDelegateArrayGetItemsCount m_getItemsCount;
		CDelegateArraySetItemsCount m_setItemsCount;
	};

	using CSharedArrayAccessor = TSharedPtr<CArrayAccessor>;

	class CMapAccessor : public CAccessor
	{
	public:
		virtual bool SaveToRwNode(const AddrType base, CRwNode& rw) const override;
		virtual bool LoadFromRwNode(AddrType base, const CRwNode& rw) const override;

	public:
		CSharedAccessor m_keyAccessor;
		CSharedAccessor m_valueAccessor;
		CDelegateMapGetBeginIterator m_getBeginIterator;
		CDelegateMapIterator m_iterator;
	};

	using CSharedMapAccessor = TSharedPtr<CMapAccessor>;

	template <typename T>
	static T& AccessInstance_Deprecated(const CAccessor* accessor, void* parentBase, T** instanceAddr)
	{
		auto addr = accessor->GetBaseAddr(parentBase);
		auto instance = static_cast<T*>(addr);
		if (instanceAddr != NULL)
			*instanceAddr = instance;
		return *instance;
	}
	//template <typename T>
	//inline static T& AccessInstance2(const CAccessor* accessor, void* parentBase)
	//{
	//	return *static_cast<T*>(accessor->GetBaseAddr(parentBase));
	//}

	//todo: ������ʽ������Accessor, Map, Set, Multi map, Multi set ��

	//todo: ʵ�ʵ�ʵ����2������ӦΪ�麯��, bufferΪͨ��Ŀ�ĵ��ֽ���, ��������������\0, ��˿��ܻ�ʵ��һ�ֶ����ʽ�Ķ���, ����accessor��buffer, ��д��Ӧ��ʽ
	NIFLECT_API void DebugSaveAccessorString(CAccessor* accessor, void* base, CString& buffer);
	NIFLECT_API void DebugLoadAccessorString(CAccessor* accessor, void* base, const CString& buffer);
}