#pragma once
#include "Niflect/Accessor/NiflectAccessDelegateAddr.h"
#include "Niflect/Accessor/NiflectAccessor.h"

namespace Niflect
{
	template <typename T>
	static void InitFieldAccessDelegateAddr(CFieldAccessor* accessor, AddrOffsetType offset)
	{
		accessor->SetOffset(offset);
		accessor->SetDelegateSave(MakeShared<TAccessFieldDelegateSaveAddr<T> >());
		accessor->SetDelegateLoad(MakeShared<TAccessFieldDelegateLoadAddr<T> >());
	}
	template <typename T>
	static CSharedFieldAccessor CreateFieldAccessorAddr(AddrOffsetType offset)
	{
		auto shared = MakeShared<CFieldAccessor>();
		auto accessor = shared.Get();
		InitFieldAccessDelegateAddr<T>(accessor, offset);
		return shared;
	}
	//template <typename TAccessor, typename T>
	//static CSharedFieldAccessor CreateFieldAccessorAddr2(AddrOffsetType offset)
	//{
	//	auto shared = MakeShared<TAccessor>();
	//	auto accessor = shared.Get();
	//	accessor->SetOffset(offset);
	//	accessor->SetDelegateSave(MakeShared<TAccessFieldDelegateSaveAddr<T> >());
	//	accessor->SetDelegateLoad(MakeShared<TAccessFieldDelegateLoadAddr<T> >());
	//	return shared;
	//}
	template <typename TMemberType, typename TMemberOwner>
	static CSharedFieldAccessor CreateFieldAccessorMemberAddr(TMemberType TMemberOwner::*member)
	{
		return CreateFieldAccessorAddr<TMemberType>(GetMemberVariableOffset<TMemberType, TMemberOwner>(member));
	}
	//template <typename TMemberType, typename TMemberOwner>
	//static CSharedFieldAccessor CreateFieldAccessorMemberAddr2(TMemberType TMemberOwner::*member)
	//{
	//	return CreateFieldAccessorAddr2<CFieldAccessor, TMemberType>(GetMemberVariableOffset<TMemberType, TMemberOwner>(member));
	//}
	static CSharedObjectAccessor CreateObjectAccessorAddr(AddrOffsetType offset)
	{
		auto shared = MakeShared<CObjectAccessor>();
		auto accessor = shared.Get();
		accessor->SetOffset(offset);
		return shared;
	}
	template <typename TMemberType, typename TMemberOwner>
	static CSharedObjectAccessor CreateObjectAccessorMemberAddr(TMemberType TMemberOwner::*member)
	{
		return CreateObjectAccessorAddr(GetMemberVariableOffset<TMemberType, TMemberOwner>(member));
	}
	template <typename TArrayType>
	static CSharedArrayAccessor CreateArrayAccessorAddr(AddrOffsetType offset)
	{
		auto shared = MakeShared<CArrayAccessor>();
		auto accessor = shared.Get();
		accessor->SetOffset(offset);
		accessor->SetDelegateGetItemBaseAddr(MakeShared<TAccessDelegateArrayItemAddr<TArrayType> >());
		accessor->SetDelegateGetItemsCount(MakeShared<TAccessDelegateArrayGetItemsCount<TArrayType> >());
		accessor->SetDelegateSetItemsCount(MakeShared<TAccessDelegateArraySetItemsCount<TArrayType> >());
		return shared;
	}
	template <typename TMemberType, typename TMemberOwner>
	static CSharedArrayAccessor CreateArrayAccessorMemberAddr(TMemberType TMemberOwner::*member)
	{
		return CreateArrayAccessorAddr<TMemberType>(GetMemberVariableOffset<TMemberType, TMemberOwner>(member));
	}

	//typedef void (*StaticBuildObjectAccessorTreeFunc)(CObjectAccessor* parent);
	//static CSharedObjectAccessor CreateObjectAccessorAddr2(AddrOffsetType offset, const StaticBuildObjectAccessorTreeFunc& Func)
	//{
	//	auto accessor = MakeSharable(CClassMemory::New<CObjectAccessor>());
	//	accessor->SetDelegateGetObjectAddr(MakeSharable(CClassMemory::New<CAccessObjectDelegateGetAddr>(offset)));
	//	if (!Func)
	//		Func(accessor.Get());
	//	return accessor;
	//}
	//template <typename TMemberType, typename TMemberOwner>
	//static CSharedObjectAccessor CreateObjectAccessorMemberAddr2(TMemberType TMemberOwner::*member, const StaticBuildObjectAccessorTreeFunc& Func)
	//{
	//	return CreateObjectAccessorAddr2(GetMemberVariableOffset<TMemberType, TMemberOwner>(member), Func);
	//}
}