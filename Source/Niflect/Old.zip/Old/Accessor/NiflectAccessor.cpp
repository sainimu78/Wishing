#include "Niflect/Accessor/NiflectAccessor.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"//���Խ׶�δʵ��Ԥ������л����, ���㽫Accessor���浽�ڴ���

namespace Niflect
{
	void CAccessor::InitMeta(CNiflectType* type)
	{
		m_type = type;
	}
	CNiflectType* CAccessor::GetType() const
	{
		return m_type;
	}
	void CAccessor::InitMemberMeta(const CString& name, CAccessor* owner)
	{
		m_name = name;
		m_owner = owner;
	}
	const CString& CAccessor::GetName() const
	{
		return m_name;
	}
	CAccessor* CAccessor::GetOwner() const
	{
		return m_owner;
	}

	bool CFieldAccessor::SaveToRwNode(const AddrType base, CRwNode& rw) const
	{
		if (auto objBase = this->GetBaseAddr(base))
		{
			if (auto save = m_save.Get())
				return save->Save(objBase, rw->ToValue());
		}
		return false;
	}
	bool CFieldAccessor::LoadFromRwNode(AddrType base, const CRwNode& rw) const
	{
		if (auto objBase = this->GetBaseAddr(base))
		{
			if (auto load = m_load.Get())
				return load->Load(objBase, rw->ToValue());
		}
		return false;
	}

	void CObjectAccessor::AddChild(const CSharedAccessor& node)
	{
		this->InsertChild(node, this->GetChildrenCount());
	}
	void CObjectAccessor::InsertChild(const CSharedAccessor& node, uint32 idx)
	{
		m_vecChild.insert(m_vecChild.begin() + idx, node);
	}
	uint32 CObjectAccessor::GetChildrenCount() const
	{
		return static_cast<uint32>(m_vecChild.size());
	}
	CAccessor* CObjectAccessor::GetChild(uint32 idx) const
	{
		return m_vecChild[idx].Get();
	}
	void CObjectAccessor::Clear()
	{
		m_vecChild.clear();
	}
	bool CObjectAccessor::SaveToRwNode(const AddrType base, CRwNode& rw) const
	{
		if (auto objBase = this->GetBaseAddr(base))
		{
			auto count = this->GetChildrenCount();
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto child = this->GetChild(idx);
				ASSERT(!child->GetName().empty());

				//uint32 childIndex;
				//auto rwChild = AddRwNode(rw, child->GetName(), &childIndex);
				//child->SaveToRwNode(objBase, rwChild);

				auto rwChild = rw->CreateNode();
				if (child->SaveToRwNode(objBase, rwChild))
					AddExistingRwNode(rw, child->GetName(), rwChild);
			}
			return true;
		}
		return false;
	}
	bool CObjectAccessor::LoadFromRwNode(AddrType base, const CRwNode& rw) const
	{
		if (auto objBase = this->GetBaseAddr(base))
		{
			auto count = this->GetChildrenCount();
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto child = this->GetChild(idx);
				ASSERT(!child->GetName().empty());
				auto rwChild = FindRwNode(rw, child->GetName());
				child->LoadFromRwNode(objBase, rwChild);
			}
			return true;
		}
		return false;
	}
	
	void CArrayAccessor::SetItemAccessor(const CSharedAccessor& accessor)
	{
		m_itemAccessor = accessor;
	}
	CAccessor* CArrayAccessor::GetItemAccessor() const
	{
		return m_itemAccessor.Get();
	}
	AddrType CArrayAccessor::GetItemBaseAddr(AddrType base, ArrayIndex idx) const
	{
		if (auto getItemBaseAddr = m_getItemBaseAddr.Get())
		{
			auto itemBase = getItemBaseAddr->GetItemBaseAddr(base, idx);
			return itemBase;
		}
		return NULL;
	}
	ArrayIndex CArrayAccessor::GetElementsCount(AddrType base) const
	{
		if (auto getItemsCount = m_getItemsCount.Get())
			return getItemsCount->GetItemsCount(base);
		return 0;
	}
	void CArrayAccessor::SetElementsCount(AddrType base, ArrayIndex count) const
	{
		if (auto setItemsCount = m_setItemsCount.Get())
			setItemsCount->SetItemsCount(base, count);
	}
	bool CArrayAccessor::SaveToRwNode(const AddrType base, CRwNode& rw) const
	{
		if (auto objBase = this->GetBaseAddr(base))
		{
			auto count = this->GetElementsCount(objBase);
			if (count > 0)
			{
				auto& rwArray = rw->ToArray();
				for (ArrayIndex idx1 = 0; idx1 < count; ++idx1)
				{
					auto& rwItem = rwArray->AddItemNode();
					this->SaveItemToRwNode(objBase, idx1, rwItem);
				}
				return true;
			}
		}
		return false;
	}
	bool CArrayAccessor::LoadFromRwNode(AddrType base, const CRwNode& rw) const
	{
		auto& rwArray = rw->ToArray();
		auto count = GetRwItemsCount(rwArray);
		if (auto objBase = this->GetBaseAddr(base))
		{
			this->SetElementsCount(objBase, count);
			for (ArrayIndex idx1 = 0; idx1 < count; ++idx1)
			{
				auto& rwItem = rwArray->GetItemNode(idx1);
				this->LoadItemFromRwNode(objBase, idx1, rwItem);
			}
			return true;
		}
		return false;
	}
	bool CArrayAccessor::SaveItemToRwNode(const AddrType base, ArrayIndex idx, CRwNode& rw) const
	{
		if (auto itemAccessor = m_itemAccessor.Get())
		{
			if (auto itemBase = this->GetItemBaseAddr(base, idx))
				return itemAccessor->SaveToRwNode(itemBase, rw);
		}
		return false;
	}
	bool CArrayAccessor::LoadItemFromRwNode(AddrType base, ArrayIndex idx, const CRwNode& rw) const
	{
		if (auto itemAccessor = m_itemAccessor.Get())
		{
			if (auto itemBase = this->GetItemBaseAddr(base, idx))
				itemAccessor->LoadFromRwNode(itemBase, rw);
		}
		return false;
	}

	bool CMapAccessor::SaveToRwNode(const AddrType base, CRwNode& rw) const
	{
		if (auto objBase = this->GetBaseAddr(base))
		{
			auto accessorBeginIt = m_getBeginIterator->GetBeginIterator(objBase);
			if (auto accessorIt = accessorBeginIt.Get())
			{
				auto& rwArray = rw->ToArray();
				auto count = m_getBeginIterator->GetElementsCount(objBase);
				if (count > 0)
				{
					for (uint32 idx = 0; idx < count; ++idx)
					{
						auto rwElement = rwArray->AddItemNode();
						auto rwKey = AddRwNode(rwElement, "Key");
						auto rwValue = AddRwNode(rwElement, "Value");
						m_iterator->SaveToRwNode(accessorIt, m_keyAccessor.Get(), m_valueAccessor.Get(), rwKey, rwValue);
						m_getBeginIterator->Iterate(objBase, accessorIt);
					}
					return true;
				}
			}
		}
		return false;
	}
	bool CMapAccessor::LoadFromRwNode(AddrType base, const CRwNode& rw) const
	{
		auto& rwArray = rw->ToArray();
		auto count = GetRwItemsCount(rwArray);
		//todo: ��clear
		if (auto objBase = this->GetBaseAddr(base))
		{
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto rwElement = rwArray->GetItemNode(idx);
				auto rwKey = FindRwNode(rwElement, "Key");
				auto rwValue = FindRwNode(rwElement, "Value");
				m_iterator->LoadFromRwNode(objBase, m_keyAccessor.Get(), m_valueAccessor.Get(), rwKey, rwValue);
			}
		}
		return false;
	}

	void DebugSaveAccessorString(CAccessor* accessor, void* base, CString& buffer)
	{
		CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
		CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
		//CRwJson::AllocatorStack stack;
		//CRwJson::AllocatorPool allocator(poolCapa, &stack);
		CRwJson::AllocatorStack stack;
		auto& allocator = stack;
		CRwJson::Document jd(&allocator, poolCapa, &allocator);
		auto& joRoot = CRwJson::AsRoot(jd);
		CJsonRwDocument doc(jd, joRoot);
		auto rwRoot = doc.GetRootNode();
		accessor->SaveToRwNode(base, rwRoot);
		CRwJson::StringBuffer stm(&allocator, poolCapa);
		CRwJson::WriteToBuffer(joRoot, stm);
		buffer = stm.GetString();
	}
	void DebugLoadAccessorString(CAccessor* accessor, void* base, const CString& buffer)
	{
		CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
		CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
		//CRwJson::AllocatorStack stack;
		//CRwJson::AllocatorPool allocator(poolCapa, &stack);
		CRwJson::AllocatorStack stack;
		auto& allocator = stack;
		CRwJson::Document jd(&allocator, poolCapa, &allocator);
		auto& joRoot = CRwJson::ReadFromBuffer(jd, buffer.data());
		CJsonRwDocument doc(jd, joRoot);
		auto rwRoot = doc.GetRootNode();
		accessor->LoadFromRwNode(base, rwRoot);
	}
}