#pragma once
#include "Niflect/Serialization/Tree/TreeReadWrite2.h"

namespace Niflect
{
	typedef void* AddrType;
	typedef ptrdiff_t AddrOffsetType;
	typedef uint32 ArrayIndex;
	
	class CAccessor;//todo: ��ϣ���ڴ�ָ��������, �ֽ�ΪMapAccessorָ��, ԭ����δʵ��Map��д�Գ�ʵ��, Loadʱ����ͨ��ģ��������ܴ���element, ������Ϊ���ܹ������, ��������ȱ��, δ�����Ƴ�����Ӧ����MapAccessor

	class CAddrOffset
	{
	public:
		static const AddrOffsetType None = 0;

	public:
		CAddrOffset()
			: m_offsetInBytes(None)
		{
		}
		CAddrOffset(const AddrOffsetType& offsetInBytes)
			: m_offsetInBytes(offsetInBytes)
		{
		}
		void SetOffset(const AddrOffsetType& offsetInBytes)
		{
			m_offsetInBytes = offsetInBytes;
		}

	public:
		inline AddrType GetAddr(const AddrType& base) const
		{
			return static_cast<char*>(base) + m_offsetInBytes;
		}

	private:
		AddrOffsetType m_offsetInBytes;
	};

	//template <typename T>
	//inline static T& CastFromAddrOffset(const CAddrOffset& helper, AddrType base)
	//{
	//	auto& value = *static_cast<T*>(helper.GetAddr(base));
	//	return value;
	//}

	template <typename U, typename T>
	inline static AddrOffsetType GetMemberVariableOffset(U T::*member)
	{
		return (char*)&((T*)nullptr->*member) - (char*)nullptr;
	}

	//template <typename T>
	//inline static void* GetArrayItemOffsetAddr(const CAddrOffset& helper, void* base, const ArrayIndex& idx)
	//{
	//	auto& array = CastFromAddrOffset<T>(helper, base);
	//	return &array[idx];
	//}

	using namespace TreeReadWrite2;

	class IAccessFieldDelegateSave
	{
	public:
		virtual bool Save(AddrType base, CRwValue& rwValue) const = 0;
	};
	using CDelegateSave = TSharedPtr<IAccessFieldDelegateSave>;

	class IAccessFieldDelegateLoad
	{
	public:
		virtual bool Load(AddrType base, const CRwValue& rwValue) const = 0;
	};
	using CDelegateLoad = TSharedPtr<IAccessFieldDelegateLoad>;
	
	//class CAccessDelegateGetBaseAddr
	//{
	//public:
	//	CAccessDelegateGetBaseAddr(AddrOffsetType offset)
	//		: m_offsetAddr(offset)
	//	{

	//	}
	//	void* Get(void* base) const
	//	{
	//		return m_offsetAddr.GetAddr(base);
	//	}

	//private:
	//	CAddrOffset m_offsetAddr;
	//};
	//using CDelegateGetBaseAddr = TSharedPtr<CAccessDelegateGetBaseAddr>;
	
	//class IAccessArrayDelegateGetItemsCount
	//{
	//public:
	//	virtual ArrayIndex GetItemsCount(void* base) const = 0;
	//};
	//using CDelegateGetItemsCount = TSharedPtr<IAccessArrayDelegateGetItemsCount>;

	//class IAccessArrayDelegateSetItemsCount
	//{
	//public:
	//	virtual void SetItemsCount(void* base, const ArrayIndex& count) const = 0;
	//};
	//using CDelegateSetItemsCount = TSharedPtr<IAccessArrayDelegateSetItemsCount>;

	//class IAccessArrayDelegateSaveItem
	//{
	//public:
	//	virtual bool Save(void* base, const ArrayIndex& idx, const CAccessor* itemAccessor, CRwNode& rw) const = 0;
	//};
	//using CDelegateSaveItem = TSharedPtr<IAccessArrayDelegateSaveItem>;

	//class IAccessArrayDelegateLoadItem
	//{
	//public:
	//	virtual bool Load(void* base, const ArrayIndex& idx, const CAccessor* itemAccessor, const CRwNode& rw) const = 0;
	//};
	//using CDelegateLoadItem = TSharedPtr<IAccessArrayDelegateLoadItem>;
	
	class IAccessDelegateArrayItem
	{
	public:
		virtual void* GetItemBaseAddr(AddrType base, const ArrayIndex& idx) const = 0;
	};
	using CDelegateArrayItem = TSharedPtr<IAccessDelegateArrayItem>;

	class IAccessDelegateArrayGetItemsCount
	{
	public:
		virtual ArrayIndex GetItemsCount(AddrType base) const = 0;
	};
	using CDelegateArrayGetItemsCount = TSharedPtr<IAccessDelegateArrayGetItemsCount>;

	class IAccessDelegateArraySetItemsCount
	{
	public:
		virtual void SetItemsCount(AddrType base, const ArrayIndex& count) const = 0;
	};
	using CDelegateArraySetItemsCount = TSharedPtr<IAccessDelegateArraySetItemsCount>;


	using CEnumData = TArrayNif<CString>;

	class CMapIterator
	{
	public:
		void* m_key;
	};
	
	class CMapAccessorIterator
	{
	public:

	};

	using CSharedMapAccessorIterator = TSharedPtr<CMapAccessorIterator>;

	class IAccessDelegateMapGetBeginIterator
	{
	public:
		virtual CSharedMapAccessorIterator GetBeginIterator(AddrType base) const = 0;
		virtual bool Iterate(AddrType base, CMapAccessorIterator* accessorIt) const = 0;
		virtual ArrayIndex GetElementsCount(AddrType base) const = 0;
	};
	using CDelegateMapGetBeginIterator = TSharedPtr<IAccessDelegateMapGetBeginIterator>;

	class IAccessDelegateMapIterator
	{
	public:
		virtual bool SaveToRwNode(CMapAccessorIterator* accessorIt, CAccessor* keyAccessor, CAccessor* valueAccessor, CRwNode& rwKey, CRwNode& rwValue) const = 0;
		virtual bool LoadFromRwNode(AddrType base, CAccessor* keyAccessor, CAccessor* valueAccessor, const CRwNode& rwKey, const CRwNode& rwValue) const = 0;
	};
	using CDelegateMapIterator = TSharedPtr<IAccessDelegateMapIterator>;
}