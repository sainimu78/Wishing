#pragma once
#include "Niflect/Accessor/NiflectAccessDelegate.h"
#include "Niflect/Accessor/NiflectAccessor.h"

namespace Niflect
{
	template <typename TValue>
	class TAccessFieldDelegateSaveAddr : public IAccessFieldDelegateSave
	{
	public:
		virtual bool Save(AddrType base, CRwValue& rwValue) const override
		{
			auto& value = *static_cast<TValue*>(base);
			ValueReadWrite::Save(rwValue, value);
			return true;
		}
	};

	template <typename TValue>
	class TAccessFieldDelegateLoadAddr : public IAccessFieldDelegateLoad
	{
	public:
		virtual bool Load(AddrType base, const CRwValue& rwValue) const override
		{
			auto& value = *static_cast<TValue*>(base);
			ValueReadWrite::Load(rwValue, value);
			return true;
		}
	};
	
	template <typename TUIntX>
	class TAccessUIntXEnumDelegateSaveAddr : public IAccessFieldDelegateSave
	{
	public:
		TAccessUIntXEnumDelegateSaveAddr(const CEnumData& vecName)
			: m_vecName(vecName)
		{
		}
	public:
		virtual bool Save(AddrType base, CRwValue& rwValue) const override
		{
			auto& value = *static_cast<TUIntX*>(base);
			ValueReadWrite::Save(rwValue, m_vecName[value]);
			return true;
		}

	private:
		const CEnumData& m_vecName;
	};

	template <typename TUIntX>
	class TAccessUIntXEnumDelegateLoadAddr : public IAccessFieldDelegateLoad
	{
	public:
		TAccessUIntXEnumDelegateLoadAddr(const CEnumData& vecName)
			: m_vecName(vecName)
		{
		}

	public:
		virtual bool Load(AddrType base, const CRwValue& rwValue) const override
		{
			CString str;
			ValueReadWrite::Load(rwValue, str);
			for (TUIntX idx = 0; idx < m_vecName.size(); ++idx)
			{
				if (m_vecName[idx] == str)
				{
					auto& value = *static_cast<TUIntX*>(base);
					value = idx;
					return true;
				}
			}
			return false;
		}

	private:
		const CEnumData& m_vecName;
	};

	template <typename TArray>
	class TAccessDelegateArrayItemAddr : public IAccessDelegateArrayItem
	{
	public:
		virtual void* GetItemBaseAddr(AddrType base, const ArrayIndex& idx) const override
		{
			auto& array = *static_cast<TArray*>(base);
			return &array[idx];
		}
	};
	
	template <typename TArray>
	class TAccessDelegateArrayGetItemsCount : public IAccessDelegateArrayGetItemsCount
	{
	public:
		virtual ArrayIndex GetItemsCount(AddrType base) const override
		{
			auto& array = *static_cast<TArray*>(base);
			return static_cast<ArrayIndex>(array.size());
		}
	};
	
	template <typename TArray>
	class TAccessDelegateArraySetItemsCount : public IAccessDelegateArraySetItemsCount
	{
	public:
		virtual void SetItemsCount(AddrType base, const ArrayIndex& count) const override
		{
			auto& array = *static_cast<TArray*>(base);
			array.resize(count);
		}
	};
	
	template <typename TMap>
	class TMapAccessorIteratorAddr : public CMapAccessorIterator
	{
	public:
		typename TMap::iterator m_it;
	};

	template <typename TMap>
	class TAccessDelegateMapGetBeginIterator : public IAccessDelegateMapGetBeginIterator
	{
	public:
		virtual CSharedMapAccessorIterator GetBeginIterator(AddrType base) const override
		{
			auto& map = *static_cast<TMap*>(base);
			if (map.size() > 0)
			{
				auto accessorIt = CInstance::New<TMapAccessorIteratorAddr<TMap> >();
				accessorIt->m_it = map.begin();
				return MakeSharable(accessorIt);
			}
			return NULL;
		}
		virtual bool Iterate(AddrType base, CMapAccessorIterator* accessorIt) const override
		{
			auto& map = *static_cast<TMap*>(base);
			auto casted = static_cast<TMapAccessorIteratorAddr<TMap>*>(accessorIt);
			auto& it = casted->m_it;
			it++;
			return it != map.end();
		}
		virtual ArrayIndex GetElementsCount(AddrType base) const override
		{
			auto& map = *static_cast<TMap*>(base);
			return static_cast<ArrayIndex>(map.size());
		}
	};

	template <typename TMap>
	class TAccessDelegateMapIterator : public IAccessDelegateMapIterator
	{
	public:
		virtual bool SaveToRwNode(CMapAccessorIterator* accessorIt, CAccessor* keyAccessor, CAccessor* valueAccessor, CRwNode& rwKey, CRwNode& rwValue) const override
		{
			auto casted = static_cast<TMapAccessorIteratorAddr<TMap>*>(accessorIt);
			auto& it = casted->m_it;
			if (keyAccessor->SaveToRwNode((AddrType)&it->first, rwKey))
			{
				if (valueAccessor->SaveToRwNode(&it->second, rwValue))
				{
					return true;
				}
			}
			return false;
		}
		virtual bool LoadFromRwNode(AddrType base, CAccessor* keyAccessor, CAccessor* valueAccessor, const CRwNode& rwKey, const CRwNode& rwValue) const override
		{
			auto& map = *static_cast<TMap*>(base);
			typename TMap::key_type key;
			if (keyAccessor->LoadFromRwNode(&key, rwKey))
			{
				typename TMap::mapped_type value;
				if (valueAccessor->LoadFromRwNode(&value, rwValue))
				{
					map.insert({key, value});
					return true;
				}
			}
			return false;
		}
	};
}