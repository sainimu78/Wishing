#pragma once
#include "Niflect/NiflectCommon.h"
#include <string>//for rapidjson macro RAPIDJSON_HAS_STDSTRING, eg: std::vector<std::basic_string<Ch> > keys() const
#include <vector>//for rapidjson macro RAPIDJSON_HAS_STDSTRING, eg: std::vector<std::basic_string<Ch> > keys() const
#include "Niflect/Serialization/Format/Json/rapidjson/document.h"
#include "Niflect/Serialization/Format/Json/rapidjson/stringbuffer.h"
#include "Niflect/Serialization/Format/Json/rapidjson/filewritestream.h"
//todo: writer�ɶ���ƽ̨�Ż�, �ɽ���ӵ�cmake��, RAPIDJSON_SSE2, RAPIDJSON_NEON
#include "Niflect/Serialization/Format/Json/rapidjson/writer.h"
#include "Niflect/Serialization/Format/Json/rapidjson/prettywriter.h"

namespace Niflect
{
	//todo: �ƻ�ʵ���̶߳��ڴ�allocator����, ����runtime����json
	template <typename TMemory>
	class CJson
	{
	private:
		class MyRapidjsonCrtAllocator {
		//�����rapidjson/allocators.h�е�CrtAllocator���ƴ�����޸Ķ���
		public:
			MyRapidjsonCrtAllocator(size_t reserved = 0)
			{
			}
			static const bool kNeedFree = true;
			void* Malloc(size_t size) { 
				if (size) //  behavior of malloc(0) is implementation defined.
					return TMemory::Alloc(size);
				else
					return NULL; // standardize to returning NULL.
			}
			void* Realloc(void* originalPtr, size_t originalSize, size_t newSize) {
				(void)originalSize;
				if (newSize == 0) {
					TMemory::Free(originalPtr);
					return NULL;
				}
				return TMemory::Realloc(originalPtr, newSize);
			}
			static void Free(void *ptr)
			{
				TMemory::Free(ptr);
			}
		};

	public:
		typedef MyRapidjsonCrtAllocator AllocatorStack;//���ͷ��ڴ�
		typedef rapidjson::MemoryPoolAllocator<MyRapidjsonCrtAllocator> AllocatorPool;//���ͷ��ڴ�
		typedef AllocatorStack Allocator;
		typedef rapidjson::SizeType SizeType;
		//typedef rapidjson::CDocumentOption COption;
		typedef rapidjson::GenericValue<rapidjson::UTF8<>, Allocator> Object;
		typedef rapidjson::GenericDocument<rapidjson::UTF8<>, Allocator, Allocator> Document;
		typedef rapidjson::GenericStringBuffer<rapidjson::UTF8<>, Allocator> StringBuffer;
		typedef rapidjson::Writer<rapidjson::UTF8<>, rapidjson::UTF8<>, Allocator> Writer;
		typedef rapidjson::PrettyWriter<StringBuffer, rapidjson::UTF8<>, rapidjson::UTF8<>, Allocator> PrettyWriter;

	public:
		template <typename T>
		static Object& ReadFromBuffer(Document& jd, const T psz)
		{
			//const auto parseOption = rapidjson::kParseStopWhenDoneFlag | rapidjson::kParseTrailingCommasFlag;
			jd.Parse(reinterpret_cast<const char*>(psz));
			if (jd.HasParseError())
			{
				auto error = jd.GetParseError();
				if(error != rapidjson::kParseErrorDocumentEmpty)
					LogError("Failed to parse json, error code: %d", error);//����ֹ��༭��, һ�����﷨����, �����ٶ���, ����"]", "}"�����Ķ��Ż�ĳ����ĩ�Ƿ���ȷ
			}
			return jd;
		}
		static Object& AsRoot(Document& jd)
		{
			if (jd.IsNull())
				jd.SetObject();
			return jd;
		}
		static void WriteToBuffer(const Object& joPar, StringBuffer& buffer)
		{
			PrettyWriter writer(buffer, &buffer.stack_.GetAllocator());
			joPar.Accept(writer);
		}
		static void WriteToBufferCompact(const Object& joPar, StringBuffer& buffer)
		{
			Writer writer(buffer, &buffer.stack_.GetAllocator());
			joPar.Accept(writer);
		}
	};
}

////begin, ��(�ѷ�����ʾ��)
//auto ms = GetArchiveMananger()->Open("shaderex/shader_editor/test.sea");
//S3Util::Json::Document jd;
//S3Util::Json::Object joPar = S3Util::Json::ReadFromBuffer(jd, ms->GetPtr());
//S3Util::Json::Object::Array jaConn = joPar["Connections"].toArray();
//for (auto& it : jaConn)
//{
//	auto joConn = it.toObject();
//	printf("nodeFrom: %s\n", joConn["nodeFrom"].toString().c_str());
//	printf("nodeTo: %s\n", joConn["nodeTo"].toString().c_str());
//	printf("portIdxFrom: %d\n", joConn["portIdxFrom"].toInt());
//	printf("portIdxTo: %d\n", joConn["portIdxTo"].toInt());
//}
//S3Util::Json::StringBuffer buffer;
//S3Util::Json::WriteToBuffer(jd, buffer);
//std::cout << buffer.GetString() << std::endl;
////end

//begin, д, ��
//{
//	using Json = CJson<CMemoryDefault>;
//		
//	size_t poolCapa = 0;//����ֵ 65536
//	size_t stackCapa = 0;//����ֵ 1024
//	Json::AllocatorStack stack;
//	Json::AllocatorPool allocator(poolCapa, &stack);
//	//Json::AllocatorStack allocator;
//
//	const char* json = "{\"project\":\"rapidjson\",\"stars\":10}";
//	Json::Document jd(&allocator, poolCapa, &allocator, stackCapa);
//	auto& joPar = Json::ReadFromBuffer(jd, json);
//
//	{
//		joPar["zeta"] = false;
//		joPar["gama"] = "test string";
//		joPar["delta"] = 123;
//
//		Json::Object v(jd);
//		v["nihao"] = 999;
//		Json::Object arr(jd);
//		arr.push_back(345);
//		arr.push_back(6789);
//		v["arr"] = arr;
//		joPar["alpha"] = v;
//
//		const auto& refPar = joPar;
//		auto itFound = refPar.find("stars");
//		if (itFound != refPar.end())
//			printf("starts found\n");
//		else
//			printf("starts not found\n");
//
//		// 2. Modify it by DOM.
//		auto s = joPar["stars"];
//		if (!s.isEmpty())
//		{
//			joPar["stars"] = s.GetInt() + 1;
//		}
//
//		s = joPar["project"];
//		if (!s.isEmpty())
//		{
//			joPar["project"] = s.toString() + " is a shit";
//		}
//	}
//		
//	{
//		Json::StringBuffer buffer(&allocator, poolCapa);
//		Json::WriteToBuffer(joPar, buffer);
//	
//		printf("%s\n", buffer.GetString());
//	}
//
//	{
//		auto itFound = joPar.find("stars");
//		if (itFound != joPar.end())
//			joPar.erase(itFound);
//
//		Json::StringBuffer buffer(&allocator, poolCapa);
//		Json::WriteToBuffer(joPar, buffer);
//	
//		printf("%s\n", buffer.GetString());
//	}
//}
//end