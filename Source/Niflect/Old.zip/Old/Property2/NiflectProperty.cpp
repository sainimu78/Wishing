//#include "Niflect/Property2/NiflectProperty.h"
//#include "Niflect/Field/NiflectField.h"
//
//namespace Niflect
//{
//	bool CProperty2::SaveToRwNode(const AddrType2& base, CRwNode& rw) const
//	{
//		if (m_field != NULL)
//			return m_field->SaveToRwNode(base, rw);
//		return this->DoSaveToRwNode(base, rw);
//	}
//	bool CProperty2::LoadFromRwNode(const AddrType2& base, const CRwNode& rw) const
//	{
//		if (m_field != NULL)
//			return m_field->LoadFromRwNode(base, rw);
//		return this->DoLoadFromRwNode(base, rw);
//	}
//}