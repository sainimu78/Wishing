#pragma once
#include "Niflect/Serialization/Tree/TreeReadWrite2.h"
#include "Niflect/Accessor2/NiflectAccessor2.h"

namespace Niflect
{
	using namespace TreeReadWrite2;

	//class CField;
	class CNiflectType2;

	class CProperty2;

	using CSharedProperty2 = TSharedPtr<CProperty2>;

	class CProperty2
	{
	public:
		CProperty2()
			: m_base(NULL)
			, m_type(NULL)
			, m_isValueProperty(false)
			//, m_field(NULL)
		{
		}

	public:
		void InitMeta(const CString& name, const AddrType2& base, bool isValueProperty)
		{
			m_name = name;
			//m_type = type;
			m_base = base;
			//m_isValueProperty = isValueProperty;
		}
		//void SetField(CField* field)
		//{
		//	m_field = field;
		//}
		//bool IsValueProperty() const
		//{
		//	return m_isValueProperty;
		//}
		const CString& GetName() const
		{
			return m_name;
		}
		const AddrType2& GetBase() const
		{
			return m_base;
		}

	public:
		void AddChild(const CSharedProperty2& prop)
		{
			this->InsertChild(prop, this->GetChildrenCount());
		}
		void InsertChild(const CSharedProperty2& prop, uint32 idx)
		{
			m_vecChild.insert(m_vecChild.begin() + idx, prop);
		}
		uint32 GetChildrenCount() const
		{
			return static_cast<uint32>(m_vecChild.size());
		}
		CProperty2* GetChild(uint32 idx) const
		{
			return m_vecChild[idx].Get();
		}

	public:
		virtual bool SaveToRwNode(const AddrType2& base, CRwNode& rw) const = 0;
		virtual bool LoadFromRwNode(AddrType2& base, const CRwNode& rw) const = 0;

	private:
		CString m_name;
		CNiflectType2* m_type;
		TArrayNif<CSharedProperty2> m_vecChild;
		AddrType2 m_base;
		//CField* m_field;
		bool m_isValueProperty;
	};

	class CDefaultProperty : public CProperty2
	{
	public:
		virtual bool SaveToRwNode(const AddrType2& base, CRwNode& rw) const override
		{
			return false;
		}
		virtual bool LoadFromRwNode(AddrType2& base, const CRwNode& rw) const override
		{
			return false;
		}
	};
}