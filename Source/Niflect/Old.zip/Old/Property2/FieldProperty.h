#pragma once
#include "Niflect/Property2/NiflectProperty.h"
#include "Niflect/Field/NiflectField.h"

namespace Niflect
{
	class CFieldProperty : public CProperty2
	{
	public:
		CFieldProperty()
			: m_field(NULL)
		{
		}

	public:
		void SetField(CField* field)
		{
			m_field = field;
		}

	public:
		virtual bool SaveToRwNode(const AddrType2& base, CRwNode& rw) const override
		{
			return m_field->SaveToRwNode(base, rw);
		}
		virtual bool LoadFromRwNode(AddrType2& base, const CRwNode& rw) const override
		{
			return m_field->LoadFromRwNode(base, rw);
		}

	private:
		CField* m_field;
	};
}