#include <stdio.h>
#include "Niflect/Base/NiflectRegisteredType.h"
#include "Niflect/Memory/Stats/NiflectMemoryStats.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"
#include "Niflect/Module/RuntimeModule.h"
#include "Niflect/Property/EditorModule.h"
#include "Niflect/Test/TestType/MyClass.h"
#include "Niflect/Util/DebugUtil.h"
#include "Niflect/Util/StringUtil.h"
#include "Niflect/Property/Property.h"
#include "Niflect/Test/TestModule0.h"
static int cnt = 0;
template <typename T>
static void PrintT()
{
	printf("default, %d\n", cnt++);
}
template <>
static void PrintT<float>()
{
	printf("float, %d\n", cnt++);
}

typedef float MyFloat;
typedef MyFloat MyFloat2;

using MyFloat3 = float;
using MyFloat4 = MyFloat3;
typedef MyFloat3 MyFloat5;
using MyFloat6 = MyFloat5;

static void MyExp()
{
	PrintT<bool>();
	PrintT<float>();
	PrintT<MyFloat>();
	PrintT<MyFloat2>();
	PrintT<MyFloat3>();
	PrintT<MyFloat4>();
	PrintT<MyFloat5>();
	PrintT<MyFloat6>();

	using namespace Niflect;

	auto memTest = DebugGetMemoryStats();
	TestCreateModuleReg0();

	{
		using namespace MyTestClassScope;
		
		CPropetyTree tree;
		auto typeToBuild = StaticGetType<CMyClass1>();
		tree.GenerateStackedTypeLayout(CInheritableType::Cast(typeToBuild));
		CMyClass1 obj;
		SetupTestInstance_CMyClass1(obj);
		tree.Build(&obj);
		printf("");

		auto root = &tree.m_root;
		PrintPropertyRecurs(root, 0);
	}

	TestDestroyModuleReg0();

	printf("Runtime bytes on finalization: %zu\n", memTest->m_bytesRuntime);
}

#ifdef TEST_FOR_GCC
#else
#include <Windows.h>
class CStaticTest
{
public:
	CStaticTest()
	{
#ifdef WIN32
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
#endif
		MyExp();
	}
};
//CStaticTest s;
#endif

#ifdef TEST_FOR_GCC
int main()
{
	MyExp();
	return 0;
}
#else
#endif