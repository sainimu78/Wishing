#pragma once
#include "Niflect/Base/NiflectRegistration.h"

Niflect::CNiflectRegistration* TestCreateModuleReg0();
void TestDestroyModuleReg0();