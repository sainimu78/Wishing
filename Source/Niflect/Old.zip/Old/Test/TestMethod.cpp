#include <stdio.h>
#include "Niflect/Base/NiflectRegisteredType.h"
#include "Niflect/Memory/Stats/NiflectMemoryStats.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"
#include "Niflect/Module/RuntimeModule.h"
#include "Niflect/Property/EditorModule.h"
#include "Niflect/Test/TestType/MyClass.h"
#include "Niflect/Util/DebugUtil.h"
#include "Niflect/Util/StringUtil.h"
#include "Niflect/Property/Property.h"
#include "Niflect/Test/TestModule0.h"

static void MyExp()
{
	using namespace Niflect;

	auto memTest = DebugGetMemoryStats();
	TestCreateModuleReg0();

	{
		using namespace MyTestClassScope;
		
		auto type = CClass::Cast(StaticGetType<CMyClassBase1>());
		CMyClassBase1 obj;

		float a = 1.0f;
		CMyClass0 b;
		bool temp0 = true;
		bool* c = &temp0;
		CMyClass0 temp1;
		temp1.m_myFloat1 = 2.0f;
		CMyClass0* d = &temp1;
		float temp2_0[] = {3.0f, 4.0f, 5.0f, 6.0f};
		float temp2_1[] = {7.0f, 8.0f, 9.0f, 10.0f};
		float temp2_2[] = {11.0f, 12.0f, 13.0f, 14.0f};
		float* temp2[3] = {temp2_0, temp2_1, temp2_2};
		//ʵ��ʱ�������, �������ֶ���Ϊ�����ڴ�, ������ͨ��float*, ������float**
		//float temp2[3][4] = {{3.0f, 4.0f, 5.0f, 6.0f}, {7.0f, 8.0f, 9.0f, 10.0f}, {11.0f, 12.0f, 13.0f, 14.0f}};
		auto e = &temp2;
		void* inputInstanceArray[] = {&a, &b, &c, &d, &e};
		bool ret = false;
		void* outputInstanceArray[] = {&ret};
		type->m_vecMethod[0].Invoke(&obj, inputInstanceArray, outputInstanceArray);
		ASSERT(ret);
		printf("");
	}

	TestDestroyModuleReg0();
		
	printf("");
}

#ifdef TEST_FOR_GCC
#else
#include <Windows.h>
class CStaticTest
{
public:
	CStaticTest()
	{
#ifdef WIN32
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
#endif
		MyExp();
	}
};
//CStaticTest s;
#endif

#ifdef TEST_FOR_GCC
int main()
{
	MyExp();
	return 0;
}
#else
#endif