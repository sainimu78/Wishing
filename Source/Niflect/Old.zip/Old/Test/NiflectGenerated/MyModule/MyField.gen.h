#pragma once
#include "Niflect/Base/NiflectMacro.h"
#include "Niflect/Base/NiflectRegisteredType.h"

namespace MyTestClassScope
{
	class CFieldFloat;
	class CFieldBool;
}

namespace Niflect
{
	template <>
	CNiflectType* StaticGetType<MyTestClassScope::CFieldFloat>()
	{
		return TInternalRegisteredType<MyTestClassScope::CFieldFloat>::s_type;
	}
	template <>
	CNiflectType* StaticGetType<MyTestClassScope::CFieldBool>()
	{
		return TInternalRegisteredType<MyTestClassScope::CFieldBool>::s_type;
	}
}