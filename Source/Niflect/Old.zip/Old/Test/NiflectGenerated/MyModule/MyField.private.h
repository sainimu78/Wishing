#pragma once
#include "Niflect/Base/NiflectTable.h"
#include "Niflect/Accessor/NiflectAccessorAddr.h"
#include "Niflect/Test/TestType/MyField.h"

namespace MyTestClassScope
{
	using namespace Niflect;

	class CInheritableTypeReg_CFieldFloat
	{
	public:
		static void StaticRegisterType(CNiflectTable* table)
		{
			CNiflectTypeInvokations typeFuncs;
			typeFuncs.m_InvokeConstructorFunc = &GenericInstanceInvokeConstructor<CFieldFloat>;
			typeFuncs.m_InvokeDestructorFunc = &GenericInstanceInvokeDestructor<CFieldFloat>;
			typeFuncs.m_InvokeCreateAccessorTreeFunc = &StaticCreateAccessorTree;

			auto type = CInstance::New<CClass>();
			auto idx = table->RegisterType(MakeSharable(type));
			ASSERT(!TInternalRegisteredType<CFieldFloat>::IsValid());
			type->InitStaticType<CFieldFloat>();
			type->InitTypeMeta(sizeof(CFieldFloat), "CFieldFloat", idx, typeFuncs);
		}
		static void StaticInitInheritance()
		{
		}
		static CSharedAccessor StaticCreateAccessorTree(AddrOffsetType offset)
		{
			auto node0 = CInstance::New<CFieldFloat>();
			InitFieldAccessDelegateAddr<float>(node0, offset);//todo: ���ɹ��߱�����ӦTypeBinding�б���ʵ�����ɰ����͵Ĵ���
			node0->InitMeta(StaticGetType<CFieldFloat>());
			return MakeSharable(node0);
		}
	};
	
	class CInheritableTypeReg_CFieldBool
	{
	public:
		static void StaticRegisterType(CNiflectTable* table)
		{
			CNiflectTypeInvokations typeFuncs;
			typeFuncs.m_InvokeConstructorFunc = &GenericInstanceInvokeConstructor<CFieldBool>;
			typeFuncs.m_InvokeDestructorFunc = &GenericInstanceInvokeDestructor<CFieldBool>;
			typeFuncs.m_InvokeCreateAccessorTreeFunc = &StaticCreateAccessorTree;

			auto type = CInstance::New<CClass>();
			auto idx = table->RegisterType(MakeSharable(type));
			ASSERT(!TInternalRegisteredType<CFieldBool>::IsValid());
			type->InitStaticType<CFieldBool>();
			type->InitTypeMeta(sizeof(CFieldBool), "CFieldBool", idx, typeFuncs);
		}
		static void StaticInitInheritance()
		{
		}
		static CSharedAccessor StaticCreateAccessorTree(AddrOffsetType offset)
		{
			auto node0 = CInstance::New<CFieldBool>();
			InitFieldAccessDelegateAddr<bool>(node0, offset);//todo: ���ɹ��߱�����ӦTypeBinding�б���ʵ�����ɰ����͵Ĵ���
			node0->InitMeta(StaticGetType<CFieldBool>());
			return MakeSharable(node0);
		}
	};
}