#pragma once
#include "Niflect/Property/Property.h"
#include "Niflect/Property/NiflectMetaFactory.h"
#include "Niflect/Base/NiflectRegisteredType.h"
#include "Niflect/Test/TestType/MyClass.h"
#include "Niflect/Test/TestType/MyBaseProperty.h"

//todo: 2024.01.20, ���´������, �ƻ�����һ�ֺ���, ��ͨ��type��ȡ, �������Ի�ȡmeta����, �������̺�Accessor����AccessorTree����������, ����AccessorTree�ṹ��ͬ, ��Щmeta������ΪĬ������, ������Script, ����meta��Ϣ�ǿ����õ�

namespace MyTestClassScope
{
	////deprecated, ��qt���嵽��Ӧ��ĳ�Ա��, �ƻ��ú�+ǿ��includeͷ�ļ��ķ�ʽ����
	//todo: �ƻ��ֹ�include�붨�����ɵ�handle���Ա, �粻ʹ����ͨ������·���ȷ�ʽ�������Լ���
	//class CGeneratedPropertyTree_CMyClass0
	//{
	//public:
	//	CPropertyItem* m_myFloat0;
	//};

	////todo: ��Ҫʵ��ű��󶨲��ܾ���PropertyNode�Ƿ�����ڱ༭��, PropertyNode����MetaData, Ҳ���ų����ֽű���Ҫ��Ϣ�鵽Accessor�İ취
	//class CReflectorEditorRegger_CMyClass0
	//{
	//public:
	//	static void StaticRegisterMeta(CMetaFactory& factory)
	//	{
	//		auto& idx = TTypeIndexedName<CMyClass0>::GetIndex();
	//		auto meta = CClassMemory::New<CMeta>();
	//		factory.RegisterMetaAtIndex(MakeSharable(meta), idx);
	//	}
	//	static void StaticFillMetaInfo(CMetaFactory& factory)
	//	{
	//		auto& idx = TTypeIndexedName<CMyClass0>::GetIndex();
	//		auto meta = factory.GetMutableMetaByIndex(idx);
	//		meta->m_InvokeBuildPropertyNodeFunc = &StaticBuildPropertyNode;
	//	}
	//	static CSharedPropertyNode StaticBuildPropertyNode(const CMetaFactory& factory, CPropertyTree* tree, CAccessor* accessor)
	//	{
	//		//todo: Ĭ�ϵ�PropertyTree����һ����Ҫ���ɴ��봴��, ������ʵ���Ե���������accessorͬ����PropertyX, meta����, �����ݿ���ͨ������·���ķ�ʽʵ��
	//		auto group = CClassMemory::New<CPropertyGroup>();
	//		group->InitMeta(tree, "My Class 0", TTypeIndexedName<CMyClass0>::GetType(), accessor);
	//		auto objectAccessor = CObjectAccessor::Cast(accessor);
	//		{
	//			auto& idx = TTypeIndexedName<CAccessorFloat>::GetIndex();
	//			auto meta = factory.GetMetaByIndex(idx);
	//			auto item = meta->m_InvokeBuildPropertyNodeFunc(factory, tree, objectAccessor->GetChild(0));
	//			group->AddChild(item);
	//		}
	//		{
	//			auto& idx = TTypeIndexedName<CAccessorFloat>::GetIndex();
	//			auto meta = factory.GetMetaByIndex(idx);
	//			auto item = meta->m_InvokeBuildPropertyNodeFunc(factory, tree, objectAccessor->GetChild(1));
	//			group->AddChild(item);
	//		}
	//		return MakeSharable(group);
	//	}
	//};
	//class CReflectorEditorRegger_CMyClassBase1
	//{
	//public:
	//	static void StaticRegisterMeta(CMetaFactory& factory)
	//	{
	//		auto& idx = TTypeIndexedName<CMyClassBase1>::GetIndex();
	//		auto meta = CClassMemory::New<CMeta>();
	//		factory.RegisterMetaAtIndex(MakeSharable(meta), idx);
	//	}
	//	static void StaticFillMetaInfo(CMetaFactory& factory)
	//	{
	//		auto& idx = TTypeIndexedName<CMyClassBase1>::GetIndex();
	//		auto meta = factory.GetMutableMetaByIndex(idx);
	//		meta->m_InvokeBuildPropertyNodeFunc = &StaticBuildPropertyNode;
	//	}
	//	static CSharedPropertyNode StaticBuildPropertyNode(const CMetaFactory& factory, CPropertyTree* tree, CAccessor* accessor)
	//	{
	//		auto group = CClassMemory::New<CPropertyGroup>();
	//		group->InitMeta(tree, "My Class Base 1", TTypeIndexedName<CMyClassBase1>::GetType(), accessor);
	//		auto objectAccessor = CObjectAccessor::Cast(accessor);
	//		{
	//			auto& idx = TTypeIndexedName<CAccessorFloat>::GetIndex();
	//			auto meta = factory.GetMetaByIndex(idx);
	//			auto item = meta->m_InvokeBuildPropertyNodeFunc(factory, tree, objectAccessor->GetChild(0));
	//			group->AddChild(item);
	//		}
	//		{
	//			auto& idx = TTypeIndexedName<CAccessorFloat>::GetIndex();
	//			auto meta = factory.GetMetaByIndex(idx);
	//			auto item = meta->m_InvokeBuildPropertyNodeFunc(factory, tree, objectAccessor->GetChild(1));
	//			group->AddChild(item);
	//		}
	//		return MakeSharable(group);
	//	}
	//};
	//class CReflectorEditorRegger_CMyClass1
	//{
	//public:
	//	static void StaticRegisterMeta(CMetaFactory& factory)
	//	{
	//		auto& idx = TTypeIndexedName<CMyClass1>::GetIndex();
	//		auto meta = CClassMemory::New<CMeta>();
	//		factory.RegisterMetaAtIndex(MakeSharable(meta), idx);
	//	}
	//	static void StaticFillMetaInfo(CMetaFactory& factory)
	//	{
	//		auto& idx = TTypeIndexedName<CMyClass1>::GetIndex();
	//		auto meta = factory.GetMutableMetaByIndex(idx);
	//		meta->m_InvokeBuildPropertyNodeFunc = &StaticBuildPropertyNode;
	//	}
	//	static CSharedPropertyNode StaticBuildPropertyNode(const CMetaFactory& factory, CPropertyTree* tree, CAccessor* accessor)
	//	{
	//		auto group = CClassMemory::New<CPropertyGroup>();
	//		group->InitMeta(tree, "My Class 1", TTypeIndexedName<CMyClass1>::GetType(), accessor);
	//		auto objectAccessor = CObjectAccessor::Cast(accessor);
	//		{
	//			auto& idx = TTypeIndexedName<CAccessorFloat>::GetIndex();
	//			auto meta = factory.GetMetaByIndex(idx);
	//			auto item = meta->m_InvokeBuildPropertyNodeFunc(factory, tree, objectAccessor->GetChild(0));
	//			group->AddChild(item);
	//		}
	//		{
	//			auto& idx = TTypeIndexedName<CMyClass0>::GetIndex();
	//			auto meta = factory.GetMetaByIndex(idx);
	//			auto item = meta->m_InvokeBuildPropertyNodeFunc(factory, tree, objectAccessor->GetChild(1));
	//			group->AddChild(item);
	//		}
	//		{
	//			auto& idx = TTypeIndexedName<CAccessorFloat>::GetIndex();
	//			auto meta = factory.GetMetaByIndex(idx);
	//			auto item = meta->m_InvokeBuildPropertyNodeFunc(factory, tree, objectAccessor->GetChild(2));
	//			group->AddChild(item);
	//		}
	//		return MakeSharable(group);
	//	}
	//};
}
