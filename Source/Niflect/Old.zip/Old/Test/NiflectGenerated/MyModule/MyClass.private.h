#pragma once
#include "Niflect/Base/NiflectTable.h"
#include "Niflect/Accessor/NiflectAccessorAddr.h"
#include "Niflect/Test/TestType/MyClass.h"
#include "Niflect/Test/TestType/MyField.h"

namespace MyTestClassScope
{
	using namespace Niflect;

	class CInheritableTypeReg_CMyClass0
	{
	public:
		static void StaticRegisterType(CNiflectTable* table)
		{
			CNiflectTypeInvokations typeFuncs;
			typeFuncs.m_InvokeConstructorFunc = &GenericInstanceInvokeConstructor<CMyClass0>;
			typeFuncs.m_InvokeDestructorFunc = &GenericInstanceInvokeDestructor<CMyClass0>;
			typeFuncs.m_InvokeCreateAccessorTreeFunc = &StaticCreateAccessorTree;

			auto type = CInstance::New<CClass>();//todo: ��ֱ����new, �Լ��ڴ����
			auto idx = table->RegisterType(MakeSharable(type));
			ASSERT(!TInternalRegisteredType<CMyClass0>::IsValid());
			type->InitStaticType<CMyClass0>();
			type->InitTypeMeta(sizeof(CMyClass0), "CMyClass0", idx, typeFuncs);
		}
		static void StaticInitInheritance()
		{
			auto type = CClass::Cast(StaticGetType<CMyClass0>());
			type->InitInheritableTypeMeta(NULL);
		}
		static CSharedAccessor StaticCreateAccessorTree(AddrOffsetType offset)
		{
			auto node0 = CreateObjectAccessorAddr(offset);
			node0->InitMeta(StaticGetType<CMyClass0>());
			{
				auto type = StaticGetType<CFieldFloat>();
				auto node1 = type->CreateAccessorTree(GetMemberVariableOffset(&CMyClass0::m_myFloat0));
				node1->InitMemberMeta("m_myFloat0", node0.Get());
				node0->AddChild(node1);
			}
			{
				auto type = StaticGetType<CFieldFloat>();
				auto node1 = type->CreateAccessorTree(GetMemberVariableOffset(&CMyClass0::m_myFloat1));
				node1->InitMemberMeta("m_myFloat1", node0.Get());
				node0->AddChild(node1);
			}
			return node0;
		}
	};
	class CInheritableTypeReg_CMyClassBase1
	{
	public:
		static void StaticRegisterType(CNiflectTable* table)
		{
			CNiflectTypeInvokations typeFuncs;
			typeFuncs.m_InvokeConstructorFunc = &GenericInstanceInvokeConstructor<CMyClassBase1>;
			typeFuncs.m_InvokeDestructorFunc = &GenericInstanceInvokeDestructor<CMyClassBase1>;
			typeFuncs.m_InvokeCreateAccessorTreeFunc = &StaticCreateAccessorTree;

			auto type = CInstance::New<CClass>();//todo: ��ֱ����new, �Լ��ڴ����
			auto idx = table->RegisterType(MakeSharable(type));
			ASSERT(!TInternalRegisteredType<CMyClassBase1>::IsValid());
			type->InitStaticType<CMyClassBase1>();
			type->InitTypeMeta(sizeof(CMyClassBase1), "CMyClassBase1", idx, typeFuncs);
		}
		static void StaticInitInheritance()
		{
			auto type = CClass::Cast(StaticGetType<CMyClassBase1>());
			type->InitInheritableTypeMeta(NULL);
		}
		static CSharedAccessor StaticCreateAccessorTree(AddrOffsetType offset)
		{
			auto node0 = CreateObjectAccessorAddr(offset);
			node0->InitMeta(StaticGetType<CMyClassBase1>());
			{
				auto type = StaticGetType<CFieldFloat>();
				auto node1 = type->CreateAccessorTree(GetMemberVariableOffset(&CMyClassBase1::m_myFloatBase2));
				node1->InitMemberMeta("m_myFloatBase2", node0.Get());
				node0->AddChild(node1);
			}
			{
				auto type = StaticGetMiscType_ContainerArray<TArrayNif<float> >("TArrayNif<float>");
				auto node1 = type->CreateAccessorTree(GetMemberVariableOffset(&CMyClassBase1::m_myStdFloatArrayBase0));
				auto node1Array0 = CArrayAccessor::Cast(node1.Get());
				node1Array0->InitMemberMeta("m_myStdFloatArrayBase0", node0.Get());
				{
					auto type = StaticGetType<CFieldFloat>();
					auto node2 = type->CreateAccessorTree(CAddrOffset::None);
					node2->InitMemberMeta("reserved_dim0", node1Array0);
					node1Array0->SetItemAccessor(node2);
				}
				node0->AddChild(node1);
			}
			{
				auto type = StaticGetType<CFieldFloat>();
				auto node1 = type->CreateAccessorTree(GetMemberVariableOffset(&CMyClassBase1::m_myFloatBase3));
				node1->InitMemberMeta("m_myFloatBase3", node0.Get());
				node0->AddChild(node1);
			}
			return node0;
		}
		template <typename TType>
		static CSharedAccessor SSSSSSSSSSSSSSSSSS(AddrOffsetType offset)
		{
			auto node0 = CInstance::New<TType>();
			//CreateFieldAccessDelegateAddr<TOriginal*>(node0, offset);//todo: ���ɹ��߱�����ӦTypeBinding�б���ʵ�����ɰ����͵Ĵ���
			node0->InitMeta(StaticGetType<TType>());
			return MakeSharable(node0);
		}
		template <typename TType>
		static CNiflectType* RRRRRRRRRR(const CString& typeName)
		{
			TryRegisterMiscType<TType>(typeName, &SSSSSSSSSSSSSSSSSS<TType>);
			return StaticGetType<TType>();
		}
		static void InvokeMethod_MyFunc0(void* obj, void** inputInstanceArray, void** ouputInstanceArray, const TArrayNif<CNiflectType*>& vecInputType, const TArrayNif<CNiflectType*>& vecOutputType)
		{
			auto& arg0 = vecInputType[0]->GetInstanceRef<float>(inputInstanceArray[0]);
			auto& arg1 = vecInputType[1]->GetInstanceRef<CMyClass0>(inputInstanceArray[1]);
			auto& arg2 = vecInputType[2]->GetInstanceRef<bool*>(inputInstanceArray[2]);
			auto& arg3 = vecInputType[3]->GetInstanceRef<CMyClass0*>(inputInstanceArray[3]);
			auto& arg4 = vecInputType[4]->GetInstanceRef<float**>(inputInstanceArray[4]);
			auto& ret0 = vecOutputType[0]->GetInstanceRef<bool>(ouputInstanceArray[0]);
			ret0 = static_cast<CMyClassBase1*>(obj)->MyFunc0(arg0, arg1, arg2, arg3, arg4);
		}
		static void StaticInitMethods()
		{
			auto type = CClass::Cast(StaticGetType<CMyClassBase1>());
			CNiflectMethod method;
			method.m_InvokeFunc = &InvokeMethod_MyFunc0;
			method.m_vecInputType.push_back(StaticGetType<CFieldFloat>());
			method.m_vecInputType.push_back(StaticGetType<CMyClass0>());
			method.m_vecInputType.push_back(RRRRRRRRRR<TFieldPointer<bool> >("bool*"));
			method.m_vecInputType.push_back(RRRRRRRRRR<TFieldPointer<CMyClass0> >("CMyClass0*"));
			method.m_vecInputType.push_back(RRRRRRRRRR<TFieldPointer<TFieldPointer<float> > >("float**"));
			method.m_vecOutputType.push_back(StaticGetType<CFieldBool>());
			type->m_vecMethod.push_back(method);
		}
	};
	class CInheritableTypeReg_CMyTransform
	{
	public:
		static void StaticRegisterType(CNiflectTable* table)
		{
			CNiflectTypeInvokations typeFuncs;
			typeFuncs.m_InvokeConstructorFunc = &GenericInstanceInvokeConstructor<CMyTransform>;
			typeFuncs.m_InvokeDestructorFunc = &GenericInstanceInvokeDestructor<CMyTransform>;
			typeFuncs.m_InvokeCreateAccessorTreeFunc = &StaticCreateAccessorTree;

			auto type = CInstance::New<CClass>();//todo: ��ֱ����new, �Լ��ڴ����
			auto idx = table->RegisterType(MakeSharable(type));
			ASSERT(!TInternalRegisteredType<CMyTransform>::IsValid());
			type->InitStaticType<CMyTransform>();
			type->InitTypeMeta(sizeof(CMyTransform), "CMyTransform", idx, typeFuncs);
		}
		static void StaticInitInheritance()
		{
		}
		static CSharedAccessor StaticCreateAccessorTree(AddrOffsetType offset)
		{
			auto shared0 = MakeShared<CMyTransformAccessor>();
			auto node0 = shared0.Get();
			node0->SetOffset(offset);
			node0->InitMeta(StaticGetType<CMyTransform>());
			node0->MyCreateAccessorTree();
			return shared0;
		}
	};
	class CInheritableTypeReg_CMyClass1
	{
	public:
		static void StaticRegisterType(CNiflectTable* table)
		{
			CNiflectTypeInvokations typeFuncs;
			typeFuncs.m_InvokeConstructorFunc = &GenericInstanceInvokeConstructor<CMyClass1>;
			typeFuncs.m_InvokeDestructorFunc = &GenericInstanceInvokeDestructor<CMyClass1>;
			typeFuncs.m_InvokeCreateAccessorTreeFunc = &StaticCreateAccessorTree;

			auto type = CInstance::New<CClass>();//todo: ��ֱ����new, �Լ��ڴ����
			auto idx = table->RegisterType(MakeSharable(type));
			ASSERT(!TInternalRegisteredType<CMyClass1>::IsValid());
			type->InitStaticType<CMyClass1>();
			type->InitTypeMeta(sizeof(CMyClass1), "CMyClass1", idx, typeFuncs);
		}
		static void StaticInitInheritance()
		{
			auto type = CClass::Cast(StaticGetType<CMyClass1>());
			type->InitInheritableTypeMeta(CClass::Cast(StaticGetType<CMyClassBase1>()));
		}
		static CSharedAccessor StaticCreateAccessorTree(AddrOffsetType offset)
		{
			auto node0 = CreateObjectAccessorAddr(offset);
			node0->InitMeta(StaticGetType<CMyClass1>());
			{
				auto type = StaticGetType<CFieldFloat>();
				auto node1 = type->CreateAccessorTree(GetMemberVariableOffset(&CMyClass1::m_myFloat4));
				node1->InitMemberMeta("m_myFloat4", node0.Get());
				node0->AddChild(node1);
			}
			{
				auto type = StaticGetMiscType_ContainerArray<TArrayNif<float> >("TArrayNif<float>");
				auto node1 = type->CreateAccessorTree(GetMemberVariableOffset(&CMyClass1::m_myStdFloatArray1));
				auto memberArray = CArrayAccessor::Cast(node1.Get());
				memberArray->InitMemberMeta("m_myStdFloatArray1", node0.Get());
				{
					auto type = StaticGetType<CFieldFloat>();
					auto node2 = type->CreateAccessorTree(CAddrOffset::None);
					node2->InitMemberMeta("reserved_dim0", memberArray);
					memberArray->SetItemAccessor(node2);
				}
				node0->AddChild(node1);
			}
			{
				auto type = StaticGetType<CMyClass0>();
				auto node1 = type->CreateAccessorTree(GetMemberVariableOffset(&CMyClass1::m_sub0));
				node1->InitMemberMeta("m_sub0", node0.Get());
				node0->AddChild(node1);
			}
			{
				auto type = StaticGetMiscType_ContainerArray<TArrayNif<TArrayNif<float> > >("TArrayNif<TArrayNif<float> >");
				auto node1 = type->CreateAccessorTree(GetMemberVariableOffset(&CMyClass1::m_myStdFloatArrayArray2));
				auto node1Array0 = CArrayAccessor::Cast(node1.Get());
				node1Array0->InitMemberMeta("m_myStdFloatArrayArray2", node0.Get());
				{
					auto type = StaticGetMiscType_ContainerArray<TArrayNif<float> >("TArrayNif<float>");
					auto node2 = type->CreateAccessorTree(CAddrOffset::None);
					auto node2Array1 = CArrayAccessor::Cast(node2.Get());
					node2Array1->InitMemberMeta("reserved_dim0", node1Array0);
					{
						auto type = StaticGetType<CFieldFloat>();
						auto member = type->CreateAccessorTree(CAddrOffset::None);
						member->InitMemberMeta("reserved_dim1", node2Array1);
						node2Array1->SetItemAccessor(member);
					}
					node1Array0->SetItemAccessor(node2);
				}
				node0->AddChild(node1);
			}
			{
				auto type = StaticGetType<CFieldFloat>();
				auto node1 = type->CreateAccessorTree(GetMemberVariableOffset(&CMyClass1::m_myFloat5));
				node1->InitMemberMeta("m_myFloat5", node0.Get());
				node0->AddChild(node1);
			}
			{
				auto type = StaticGetType<CMyTransform>();
				auto node1 = type->CreateAccessorTree(GetMemberVariableOffset(&CMyClass1::m_tm));
				node1->InitMemberMeta("m_tm", node0.Get());
				node0->AddChild(node1);
			}
			return node0;
		}
	};
}
