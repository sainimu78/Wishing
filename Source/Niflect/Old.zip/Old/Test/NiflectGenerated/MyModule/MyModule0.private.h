#pragma once
#include "Niflect/Base/NiflectRegistration.h"
#include "Niflect/Test/NiflectGenerated/MyModule/MyField.private.h"
#include "Niflect/Test/NiflectGenerated/MyModule/MyClass.private.h"
#include "Niflect/Test/NiflectGenerated/MyModule/MyEnum.private.h"

namespace Niflect
{
	CSharedNiflectRegistration CNiflectRegistration::s_reg = NULL;
}

namespace NiflectModuleReg
{
	using namespace Niflect;
	
	class CModuleReg_MyModule0 : public CNiflectRegistration
	{
	protected:
		virtual void DoInitTables() override
		{
			{
				auto table = this->AddNewTable();
				table->Init(CString());
			}
		}
		//todo: ����ǰ�������ռ�, ʵ��Ԥ�����, #1, ..., #3, �ɲ���ִ��(�� parallel for)
		virtual void DoRegisterTypes() const override
		{
			//#1, ����ģ�������� Reflector Type
			if (auto table = this->GetTable(0))
			{
				MyTestClassScope::CInheritableTypeReg_CFieldFloat::StaticRegisterType(table);//todo: ����������Ҫ����һ��ע������, ��ģ���ֹ�ע�ᷴ��������
				MyTestClassScope::CInheritableTypeReg_CFieldBool::StaticRegisterType(table);
				//MyTestClassScope::CInheritableTypeReg_EMyEnumOption::StaticRegisterType(m_factory);
				MyTestClassScope::CInheritableTypeReg_CMyClass0::StaticRegisterType(table);
				MyTestClassScope::CInheritableTypeReg_CMyClassBase1::StaticRegisterType(table);
				MyTestClassScope::CInheritableTypeReg_CMyTransform::StaticRegisterType(table);
				MyTestClassScope::CInheritableTypeReg_CMyClass1::StaticRegisterType(table);
			}
		}
		virtual void DoInitTypes() const override
		{
			//#2, �����Ϣ
			{
				MyTestClassScope::CInheritableTypeReg_CFieldFloat::StaticInitInheritance();//todo: ����������Ҫ����һ��ע������, ��ģ���ֹ�ע�ᷴ��������
				MyTestClassScope::CInheritableTypeReg_CFieldBool::StaticInitInheritance();
				//MyTestClassScope::CInheritableTypeReg_EMyEnumOption::StaticFillTypeInfo(m_factory);
				MyTestClassScope::CInheritableTypeReg_CMyClass0::StaticInitInheritance();
				MyTestClassScope::CInheritableTypeReg_CMyClassBase1::StaticInitInheritance();
				MyTestClassScope::CInheritableTypeReg_CMyTransform::StaticInitInheritance();
				MyTestClassScope::CInheritableTypeReg_CMyClass1::StaticInitInheritance();
			}
		}
		virtual void DoInitMethods() const override
		{
			MyTestClassScope::CInheritableTypeReg_CMyClassBase1::StaticInitMethods();
		}
		virtual void DoInitTypesAccessorTree() const override
		{
			//#3, ����AccessorTree, ��Ҫ�������л�
			for (uint32 idx0 = 0; idx0 < this->GetTablesCount(); ++idx0)
			{
				auto table = this->GetTable(idx0);
				for (auto& it : table->m_vecType)
					it->InitAccessorTree();
			}
		}
	};

	static void CreateModuleRegistration()
	{
		CNiflectRegistration::StaticCreate<CModuleReg_MyModule0>();
	}
	
	static void DestroyModuleRegistration()
	{
		CNiflectRegistration::StaticDestroy();
	}
}

Niflect::CNiflectRegistration* GetNiflectModuleRegistration()
{
	return Niflect::CNiflectRegistration::StaticGet();
}