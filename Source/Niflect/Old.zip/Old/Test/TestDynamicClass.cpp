#include <stdio.h>
#include "Niflect/Base/NiflectRegisteredType.h"
#include "Niflect/Base/NiflectTable.h"
#include "Niflect/Accessor/NiflectAccessorAddr.h"
#include "Niflect/Test/TestType/MyClass.h"
#include "Niflect/Memory/Stats/NiflectMemoryStats.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"
#include "Niflect/Module/RuntimeModule.h"
#include "Niflect/Util/DebugUtil.h"
#include "Niflect/Test/TestModule0.h"
#include "Niflect/Test/TestType/MyField.h"

using namespace Niflect;

class CMemberAddingContext
{
public:
	CMemberAddingContext()
		: m_offset(CAddrOffset::None)
		, m_sizeof(CAddrOffset::None)
	{
	}
	template <typename T>
	const AddrOffsetType& Offset()
	{
		return this->OffsetInternal(sizeof(T), alignof(T));
	}
	const AddrOffsetType& End()
	{
		return this->OffsetInternal(0, alignof(void*));
	}

private:
	const AddrOffsetType& OffsetInternal(const AddrOffsetType& sz, const AddrOffsetType& al)
	{
		m_offset = AlignTo(m_offset + m_sizeof, al);
		m_sizeof = sz;
		return m_offset;
	}

public:
	static constexpr size_t AlignTo(size_t n, size_t align)
	{
		return (n + align - 1) & ~(align - 1);
	}

public:
	AddrOffsetType m_offset;

private:
	AddrOffsetType m_sizeof;
};

class CA
{
public:
	float m_a;
	bool m_b;
	float m_c;
};

static void MyExp()
{
	using namespace Niflect;

	auto memTest = DebugGetMemoryStats();
	{
		TestCreateModuleReg0();

		using namespace MyTestClassScope;
		{
			auto a = GetMemberVariableOffset(&CA::m_a);
			auto b = GetMemberVariableOffset(&CA::m_b);
			auto c = GetMemberVariableOffset(&CA::m_c);
			printf("");
		}
		{
			constexpr size_t offsetOf_m_a = 0;
			constexpr size_t offsetOf_m_b = CMemberAddingContext::AlignTo(offsetOf_m_a + sizeof(float), alignof(bool));
			constexpr size_t offsetOf_m_c = CMemberAddingContext::AlignTo(offsetOf_m_b + sizeof(bool), alignof(float));
			CMemberAddingContext context;
			auto a = context.Offset<float>();
			auto b = context.Offset<bool>();
			auto c = context.Offset<float>();
			printf("");
		}

		TSharedPtr<CObjectAccessor> accessorRootMy;
		CArrayAccessor* member_m_myStdFloatArrayBase0 = NULL;
		CFieldFloat* member_m_myFloatBase2 = NULL;
		CFieldFloat* member_m_myFloatBase3 = NULL;
		CMemberAddingContext context;
		{
			auto accessor = CreateObjectAccessorAddr(context.m_offset);
			{
				using TType = float;
				auto member = CInstance::New<CFieldFloat>();
				member->SetOffset(context.Offset<TType>());
				accessor->AddChild(MakeSharable(member));
				member_m_myFloatBase2 = member;
				auto a = GetMemberVariableOffset(&CMyClassBase1::m_myFloatBase2);
				ASSERT(a == context.m_offset);
			}
			{
				using TType = TArrayNif<float>;
				auto member = CInstance::New<CArrayAccessor>();
				member->SetOffset(context.Offset<TType>());
				accessor->AddChild(MakeSharable(member));
				{
					CMemberAddingContext context;
					using TElemType = TType::value_type;
					//todo: ����ģ�庯��ƥ�䵽elem
					auto elemAccessor = CInstance::New<CFieldFloat>();
					elemAccessor->SetOffset(context.Offset<TElemType>());
					member->SetItemAccessor(MakeSharable(elemAccessor));
				}
				member_m_myStdFloatArrayBase0 = member;
				auto a = GetMemberVariableOffset(&CMyClassBase1::m_myStdFloatArrayBase0);
				ASSERT(a == context.m_offset);
			}
			{
				using TType = float;
				auto member = CInstance::New<CFieldFloat>();
				member->SetOffset(context.Offset<TType>());
				accessor->AddChild(MakeSharable(member));
				member_m_myFloatBase3 = member;
				auto a = GetMemberVariableOffset(&CMyClassBase1::m_myFloatBase3);
				ASSERT(a == context.m_offset);
			}
			accessorRootMy = accessor;
		}
		auto classType = StaticGetType<CMyClassBase1>();
		context.End();
		ASSERT(context.m_offset == classType->GetNiflectTypeSize());
		auto heap = CMemory::Alloc(context.m_offset);
		auto& instance = *static_cast<CMyClassBase1*>(heap);
		void* parentBase = heap;
		parentBase = accessorRootMy->GetBaseAddr(parentBase);
		member_m_myFloatBase2->SetValue(parentBase, 123.0f);
		member_m_myFloatBase3->SetValue(parentBase, 456.0f);
		auto v0 = member_m_myFloatBase2->GetValue(parentBase);
		auto v1 = member_m_myFloatBase3->GetValue(parentBase);
		float* memberAddr0;
		float* memberAddr1;
		auto& member0 = AccessInstance_Deprecated(member_m_myFloatBase2, parentBase, &memberAddr0);
		auto& member1 = AccessInstance_Deprecated(member_m_myFloatBase3, parentBase, &memberAddr1);
		member0 = 321.0f;
		member1 = 654.0f;

		auto arrayBase = member_m_myStdFloatArrayBase0->GetBaseAddr(parentBase);
		TArrayNif<float>* myArrayAddr;
		auto& myArray = AccessInstance_Deprecated(member_m_myStdFloatArrayBase0, parentBase, &myArrayAddr);
		GenericInstanceInvokeConstructor<TArrayNif<float> >(arrayBase);
		instance.m_myStdFloatArrayBase0.push_back(1);
		myArray.resize(3);
		myArray[0] = 12.0f;
		myArray[1] = 34.0f;
		myArray[2] = 56.0f;
		GenericInstanceInvokeDestructor<TArrayNif<float> >(arrayBase);
		//SetupTestInstance_CMyClass1(instance);

		CMemory::Free(heap);

		TestDestroyModuleReg0();
	}
	printf("");
}

#ifdef TEST_FOR_GCC
#else
#include <Windows.h>
class CStaticTest
{
public:
	CStaticTest()
	{
#ifdef WIN32
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
#endif
		MyExp();
	}
};
//CStaticTest s;
#endif

#ifdef TEST_FOR_GCC
int main()
{
	MyExp();
	return 0;
}
#else
#endif