#include <stdio.h>
#include "Niflect/Accessor/NiflectAccessorAddr.h"
#include <sstream>
#include "Niflect/Memory/Stats/NiflectMemoryStats.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"
#include "Niflect/Util/DebugUtil.h"

#include <fstream>//��rw
#include <iostream>//����rw

class CMySimpleObject
{
public:
	float m_floatValue;
};

class CMySimpleEmbeddedObject
{
public:
	CMySimpleObject m_sub;
	float m_floatValue;
};

class CMyObjectWithArray
{
public:
	template <typename T>
	class TMyCustomArray
	{
	public:
		TMyCustomArray()
			: m_count(0)
		{
		}
		std::size_t size() const
		{
			return m_count;
		}
		void resize(std::size_t count)
		{
			m_count = count;
		}
		T& operator[](std::size_t idx)
		{
			return m_items[idx];
		}
		const T& operator[](std::size_t idx) const
		{
			return m_items[idx];
		}

	private:
		std::size_t m_count;
		T m_items[128];
	};

public:
	float m_floatValue;
	std::vector<float> m_vecFloatValue;
	std::vector<std::vector<float> > m_vecVecFloatValue;
	std::vector<CMySimpleObject> m_vecObj;
	TMyCustomArray<float> m_arrFloatValue;
};

class CMyObjectWithMap
{
public:
	float m_floatValue0;
	std::map<float, float> m_mapFloatToFloat;
	float m_floatValue1;
};

enum class EMyEnumOption_DefaultInt
{
	Opt0,
	Opt1,
};

enum class EMyEnumOption_uint8 : uint8
{
	Opt0,
	Opt1,
};

static void TestSingleBuiltinType()
{
	using namespace Niflect;

	auto accessorRoot = CreateFieldAccessorAddr<float>(CAddrOffset::None);

	float srcData = 123.45f;

	{
		CAccessor* accessor = accessorRoot.Get();
		void* base = &srcData;

		CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
		CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
		//CRwJson::AllocatorStack stack;
		//CRwJson::AllocatorPool allocator(poolCapa, &stack);
		CRwJson::AllocatorStack stack;
		auto& allocator = stack;
		CRwJson::Document jd(&allocator, poolCapa, &allocator);
		auto& joRoot = CRwJson::AsRoot(jd);
		CJsonRwDocument doc(jd, joRoot);
		auto rwRoot = doc.GetRootNode();
		accessor->SaveToRwNode(base, rwRoot);
		CRwJson::StringBuffer buffer(&allocator, poolCapa);
		CRwJson::WriteToBuffer(joRoot, buffer);
		printf("%s\n", buffer.GetString());
	}
}

static void TestSimpleObject()
{
	using namespace Niflect;

	auto accessorRoot = CreateObjectAccessorAddr(CAddrOffset::None);
	auto member_m_floatValue = CreateFieldAccessorMemberAddr(&CMySimpleObject::m_floatValue);
	member_m_floatValue->InitMemberMeta("m_floatValue", NULL);
	accessorRoot->AddChild(member_m_floatValue);

	CMySimpleObject obj;
	obj.m_floatValue = 123.45f;

	{
		CAccessor* accessor = accessorRoot.Get();
		void* base = &obj;

		CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
		CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
		//CRwJson::AllocatorStack stack;
		//CRwJson::AllocatorPool allocator(poolCapa, &stack);
		CRwJson::AllocatorStack stack;
		auto& allocator = stack;
		CRwJson::Document jd(&allocator, poolCapa, &allocator);
		auto& joRoot = CRwJson::AsRoot(jd);
		CJsonRwDocument doc(jd, joRoot);
		auto rwRoot = doc.GetRootNode();
		accessor->SaveToRwNode(base, rwRoot);
		CRwJson::StringBuffer buffer(&allocator, poolCapa);
		CRwJson::WriteToBuffer(joRoot, buffer);
		printf("%s\n", buffer.GetString());
	}
}

static void TestSimpleEmbeddedObject()
{
	using namespace Niflect;

	auto accessorRoot = CreateObjectAccessorAddr(CAddrOffset::None);
	auto member_m_sub = CreateObjectAccessorMemberAddr(&CMySimpleEmbeddedObject::m_sub);
	member_m_sub->InitMemberMeta("m_sub", NULL);
	{
		auto member_m_floatValue = CreateFieldAccessorMemberAddr(&CMySimpleObject::m_floatValue);
		member_m_floatValue->InitMemberMeta("m_floatValue", NULL);

		member_m_sub->AddChild(member_m_floatValue);
	}
	accessorRoot->AddChild(member_m_sub);
	auto member_m_floatValue = CreateFieldAccessorMemberAddr(&CMySimpleEmbeddedObject::m_floatValue);
	member_m_floatValue->InitMemberMeta("m_floatValue", NULL);
	accessorRoot->AddChild(member_m_floatValue);

	CMySimpleEmbeddedObject obj;
	obj.m_floatValue = 123.45f;
	obj.m_sub.m_floatValue = 67.89f;

	{
		CAccessor* accessor = accessorRoot.Get();
		void* base = &obj;

		CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
		CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
		//CRwJson::AllocatorStack stack;
		//CRwJson::AllocatorPool allocator(poolCapa, &stack);
		CRwJson::AllocatorStack stack;
		auto& allocator = stack;
		CRwJson::Document jd(&allocator, poolCapa, &allocator);
		auto& joRoot = CRwJson::AsRoot(jd);
		CJsonRwDocument doc(jd, joRoot);
		auto rwRoot = doc.GetRootNode();
		accessor->SaveToRwNode(base, rwRoot);
		CRwJson::StringBuffer buffer(&allocator, poolCapa);
		CRwJson::WriteToBuffer(joRoot, buffer);
		printf("%s\n", buffer.GetString());
	}
}

namespace Niflect
{
	template <typename TMapType>
	static CSharedMapAccessor CreateMapAccessorAddr(AddrOffsetType offset)
	{
		auto accessor = CInstance::New<CMapAccessor>();
		accessor->SetOffset(offset);
		accessor->m_getBeginIterator = MakeSharable(CInstance::New<TAccessDelegateMapGetBeginIterator<TMapType> >());
		accessor->m_iterator = MakeSharable(CInstance::New<TAccessDelegateMapIterator<TMapType> >());
		return MakeSharable(accessor);
	}
}

//��Map�����Ϊʵ��汾, �ܴ�ʵ������, ��Ϊ��Ҫ�����Ƿ�ͳһ���ж�����InvokeConstructorͳһ����, ��map��pair����, array����element�������elementʹ��InvokeConstructor����, ������������Ҫ��ͬ�������ܹ�ʵ�ָ��̶߳ȵĽ���ʵ��, ������ͨ��Accessor��ȡ�ص�ִ��, ������Ҫ����Delegate
static void TestObjectWithMap()
{
	using namespace Niflect;

	auto accessorRoot = CreateObjectAccessorAddr(CAddrOffset::None);
	auto member_m_floatValue0 = CreateFieldAccessorMemberAddr(&CMyObjectWithMap::m_floatValue0);
	member_m_floatValue0->InitMemberMeta("m_floatValue0", NULL);
	accessorRoot->AddChild(member_m_floatValue0);

	auto member_m_mapFloatToFloat = CreateMapAccessorAddr<std::map<float, float> >(GetMemberVariableOffset(&CMyObjectWithMap::m_mapFloatToFloat));
	member_m_mapFloatToFloat->InitMemberMeta("m_mapFloatToFloat", NULL);
	{
		{
			auto accessor = CreateFieldAccessorAddr<float>(CAddrOffset::None);
			accessor->InitMemberMeta("level0_key", NULL);
			member_m_mapFloatToFloat->m_keyAccessor = accessor;
		}
		{
			auto accessor = CreateFieldAccessorAddr<float>(CAddrOffset::None);
			accessor->InitMemberMeta("level0_value", NULL);
			member_m_mapFloatToFloat->m_valueAccessor = accessor;
		}
	}
	accessorRoot->AddChild(member_m_mapFloatToFloat);

	auto member_m_floatValue1 = CreateFieldAccessorMemberAddr(&CMyObjectWithMap::m_floatValue1);
	member_m_floatValue1->InitMemberMeta("m_floatValue1", NULL);
	accessorRoot->AddChild(member_m_floatValue1);

	CMyObjectWithMap obj;
	obj.m_floatValue0 = 123.45f;
	obj.m_mapFloatToFloat[1.0f] = 2.0f;
	obj.m_mapFloatToFloat[1.1f] = 2.1f;
	obj.m_floatValue1 = 456.78f;

	{
		CAccessor* accessor = accessorRoot.Get();
		void* base = &obj;

		CString data;
		{
			CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
			CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
			//CRwJson::AllocatorStack stack;
			//CRwJson::AllocatorPool allocator(poolCapa, &stack);
			CRwJson::AllocatorStack stack;
			auto& allocator = stack;
			CRwJson::Document jd(&allocator, poolCapa, &allocator);
			auto& joRoot = CRwJson::AsRoot(jd);
			CJsonRwDocument doc(jd, joRoot);
			auto rwRoot = doc.GetRootNode();
			accessor->SaveToRwNode(base, rwRoot);
			CRwJson::StringBuffer buffer(&allocator, poolCapa);
			CRwJson::WriteToBuffer(joRoot, buffer);
			data = buffer.GetString();
			printf("%s\n", buffer.GetString());
		}
		{
			CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
			CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
			//CRwJson::AllocatorStack stack;
			//CRwJson::AllocatorPool allocator(poolCapa, &stack);
			CRwJson::AllocatorStack stack;
			auto& allocator = stack;
			CRwJson::Document jd(&allocator, poolCapa, &allocator);
			auto& joRoot = CRwJson::ReadFromBuffer(jd, data.c_str());
			CJsonRwDocument doc(jd, joRoot);
			auto rwRoot = doc.GetRootNode();
			CMyObjectWithMap obj2;
			accessor->LoadFromRwNode(&obj2, rwRoot);
			ASSERT(obj.m_floatValue0 == obj2.m_floatValue0);
			ASSERT(obj.m_mapFloatToFloat == obj2.m_mapFloatToFloat);
			ASSERT(obj.m_floatValue1 == obj2.m_floatValue1);
		}
	}
}

static void TestObjectWithArray()
{
	using namespace Niflect;

	auto accessorRoot = CreateObjectAccessorAddr(CAddrOffset::None);
	auto member_m_floatValue = CreateFieldAccessorMemberAddr(&CMyObjectWithArray::m_floatValue);
	member_m_floatValue->InitMemberMeta("m_floatValue", NULL);
	accessorRoot->AddChild(member_m_floatValue);
	auto member_m_vecFloatValue = CreateArrayAccessorMemberAddr(&CMyObjectWithArray::m_vecFloatValue);
	member_m_vecFloatValue->InitMemberMeta("m_vecFloatValue", NULL);
	{
		auto itemAccessor = CreateFieldAccessorAddr<float>(CAddrOffset::None);
		member_m_vecFloatValue->SetItemAccessor(itemAccessor);
	}
	accessorRoot->AddChild(member_m_vecFloatValue);
	auto member_m_vecVecFloatValue = CreateArrayAccessorMemberAddr(&CMyObjectWithArray::m_vecVecFloatValue);
	member_m_vecVecFloatValue->InitMemberMeta("m_vecVecFloatValue", NULL);
	{
		auto itemAccessor = CreateArrayAccessorAddr<std::vector<float> >(CAddrOffset::None);
		itemAccessor->InitMemberMeta("level0", NULL);
		{
			auto itemItemAccessor = CreateFieldAccessorAddr<float>(CAddrOffset::None);
			itemItemAccessor->InitMemberMeta("level1", NULL);
			itemAccessor->SetItemAccessor(itemItemAccessor);
		}
		member_m_vecVecFloatValue->SetItemAccessor(itemAccessor);
	}
	accessorRoot->AddChild(member_m_vecVecFloatValue);
	auto member_m_vecObj = CreateArrayAccessorMemberAddr(&CMyObjectWithArray::m_vecObj);
	member_m_vecObj->InitMemberMeta("m_vecObj", NULL);
	{
		auto itemAccessor = CreateObjectAccessorAddr(CAddrOffset::None);
		itemAccessor->InitMemberMeta("level0", NULL);
		{
			auto member_m_floatValue = CreateFieldAccessorMemberAddr(&CMySimpleObject::m_floatValue);
			member_m_floatValue->InitMemberMeta("m_floatValue", NULL);
			itemAccessor->AddChild(member_m_floatValue);
		}
		member_m_vecObj->SetItemAccessor(itemAccessor);
	}
	accessorRoot->AddChild(member_m_vecObj);
	auto member_m_arrFloatValue = CreateArrayAccessorMemberAddr(&CMyObjectWithArray::m_arrFloatValue);
	member_m_arrFloatValue->InitMemberMeta("m_arrFloatValue", NULL);
	{
		auto itemAccessor = CreateFieldAccessorAddr<float>(CAddrOffset::None);
		member_m_arrFloatValue->SetItemAccessor(itemAccessor);
	}
	accessorRoot->AddChild(member_m_arrFloatValue);

	//todo: ȷ����ȷ��������"�ƻ�"�Ƿ�ʵ��, ˵������:
	//���������item�Ա����rwNode, ������Ͽɿ���ֵΪnull��json�ڵ�, ����Ϊ����Ҫ��ObjectAccessor���л�ʱ���Ӽ���Ƿ�ɱ������Ч�Լ��
	//�ƻ�����ʹ�� Property, Ԥ����Property����Ĭ��ֵ�ȸ���ѡ����ȷ���Ƿ���Ҫ����, Ȼ��ͨ���󶨵�Accessorִ�б���
	//�����ObjectAccessor����Ҫ��������ϸ��, ��Ϊ����ʵ����ʹ�õ���PropertyTree, ������AccessorTree
	CMyObjectWithArray obj;
	obj.m_floatValue = 123.45f;
	obj.m_vecFloatValue.push_back(1.2f);
	obj.m_vecFloatValue.push_back(3.4f);
	obj.m_vecFloatValue.push_back(5.6f);
	obj.m_vecVecFloatValue.resize(2);
	obj.m_vecVecFloatValue[0].push_back(0.1f);
	obj.m_vecVecFloatValue[0].push_back(0.2f);
	obj.m_vecVecFloatValue[1].push_back(1.1f);
	obj.m_vecVecFloatValue[1].push_back(1.2f);
	obj.m_vecVecFloatValue[1].push_back(1.3f);
	obj.m_vecVecFloatValue[1].push_back(1.4f);
	obj.m_vecObj.resize(5);
	obj.m_vecObj[0].m_floatValue = 1.1f;
	obj.m_vecObj[1].m_floatValue = 2.2f;
	obj.m_vecObj[2].m_floatValue = 3.3f;
	obj.m_vecObj[3].m_floatValue = 4.4f;
	obj.m_vecObj[4].m_floatValue = 5.5f;
	obj.m_arrFloatValue.resize(2);
	obj.m_arrFloatValue[0] = 6.6f;
	obj.m_arrFloatValue[1] = 7.7f;

	{
		CAccessor* accessor = accessorRoot.Get();
		void* base = &obj;

		CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
		CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
		//CRwJson::AllocatorStack stack;
		//CRwJson::AllocatorPool allocator(poolCapa, &stack);
		CRwJson::AllocatorStack stack;
		auto& allocator = stack;
		CRwJson::Document jd(&allocator, poolCapa, &allocator);
		auto& joRoot = CRwJson::AsRoot(jd);
		CJsonRwDocument doc(jd, joRoot);
		auto rwRoot = doc.GetRootNode();
		accessor->SaveToRwNode(base, rwRoot);
		CRwJson::StringBuffer buffer(&allocator, poolCapa);
		CRwJson::WriteToBuffer(joRoot, buffer);
		printf("%s\n", buffer.GetString());

		{
			//auto m_floatValue = joRoot["m_floatValue"].toFloat();
			auto count = rwRoot->GetNodesCount();
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto rwNode = rwRoot->GetNode(idx);
				printf("%s\n", rwNode.m_name.c_str());
			}
			//todo: ��������RwNode��ȱ��, ���JsonTreeReadWrite.h��ͷע��
			auto m_floatValue = FindRwFloat(rwRoot, "m_floatValue");
			ASSERT(m_floatValue == 123.45f);
			printf("");
		}
	}
}
namespace Niflect
{
	template <typename TUIntX>
	static CSharedFieldAccessor CreateUIntXEnumAccessorAddr(const CEnumData& enumData, AddrOffsetType offset)
	{
		auto shared = MakeShared<CFieldAccessor>();
		auto accessor = shared.Get();
		accessor->SetOffset(offset);
		accessor->SetDelegateSave(MakeShared<TAccessUIntXEnumDelegateSaveAddr<TUIntX> >(enumData));
		accessor->SetDelegateLoad(MakeShared<TAccessUIntXEnumDelegateLoadAddr<TUIntX> >(enumData));
		return shared;
	}
	template <typename T>
	static CSharedFieldAccessor CreateEnumAccessorAddr(AddrOffsetType offset)
	{
		static const CEnumData enumData;ASSERT(false);//todo: ͨ��StaticGetEnum<T>��ȡ
		return CreateUIntXEnumAccessorAddr<std::underlying_type<T>::type>(enumData, offset);
	}
}
static void TestEnum()
{
	using namespace Niflect;

	CEnumData enumData;
	enumData.push_back("Opt0");
	enumData.push_back("Opt1");
	
	auto accessorRoot = CreateUIntXEnumAccessorAddr<std::underlying_type<EMyEnumOption_DefaultInt>::type>(enumData, CAddrOffset::None);

	EMyEnumOption_DefaultInt srcData = EMyEnumOption_DefaultInt::Opt1;

	{
		CAccessor* accessor = accessorRoot.Get();
		void* base = &srcData;

		CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
		CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
		//CRwJson::AllocatorStack stack;
		//CRwJson::AllocatorPool allocator(poolCapa, &stack);
		CRwJson::AllocatorStack stack;
		auto& allocator = stack;
		CRwJson::Document jd(&allocator, poolCapa, &allocator);
		auto& joRoot = CRwJson::AsRoot(jd);
		CJsonRwDocument doc(jd, joRoot);
		auto rwRoot = doc.GetRootNode();
		accessor->SaveToRwNode(base, rwRoot);
		CRwJson::StringBuffer buffer(&allocator, poolCapa);
		CRwJson::WriteToBuffer(joRoot, buffer);
		printf("%s\n", buffer.GetString());
	}
}

static void MyExp()
{
	using namespace Niflect;

	auto memTest = DebugGetMemoryStats();
	TestEnum();
	printf("");
}

#ifdef TEST_FOR_GCC
#else
#include <Windows.h>
class CStaticTest
{
public:
	CStaticTest()
	{
#ifdef WIN32
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
#endif
		MyExp();
	}
};
//CStaticTest s;
#endif

#ifdef TEST_FOR_GCC
int main()
{
	MyExp();
	return 0;
}
#else
#endif