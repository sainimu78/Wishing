#include "Niflect/Test/TestEditor/TestPropertyResetter.h"
#include "Niflect/Test/TestEditor/TestPropertyEditorNode.h"
#include "Niflect/Test/TestEditor/TestPropertyTreeEditor.h"
#include "Niflect/Accessor/NiflectAccessor.h"

namespace TestWidgetBinding
{
	using namespace Niflect;

	void CFieldPropertyResetter::LLLL(CPropertyEditorNode* propertyEditorNode) const
	{
		auto& propertyNode = propertyEditorNode->m_propertyNode;
		DebugLoadAccessorString(propertyNode->m_accessor, propertyNode->m_parentBase, m_default);
	}
	void CFieldPropertyResetter::SaveRecurs(CPropertyEditorNode* propertyEditorNode)
	{
		auto& propertyNode = propertyEditorNode->m_propertyNode;
		DebugSaveAccessorString(propertyNode->m_accessor, propertyNode->m_parentBase, m_default);
	}
	bool CFieldPropertyResetter::IsEqualToDefault(CPropertyEditorNode* propertyEditorNode) const
	{
		auto& propertyNode = propertyEditorNode->m_propertyNode;
		CString data;
		DebugSaveAccessorString(propertyNode->m_accessor, propertyNode->m_parentBase, data);
		return data == m_default;
	}
	
	CPropertyResetter* CObjectPropertyResetter::GetChildPropertyResetter(uint32 idx) const
	{
		return m_vecChild[idx].Get();
	}
	void CObjectPropertyResetter::LLLL(CPropertyEditorNode* propertyEditorNode) const
	{
		for(uint32 idx = 0; idx < m_vecChild.size(); ++idx)
		{
			auto childEditorNode = propertyEditorNode->m_vecChild[idx].Get();
			auto childResetter = m_vecChild[idx].Get();
			childResetter->LLLL(childEditorNode);
		}
	}
	void CObjectPropertyResetter::SaveRecurs(CPropertyEditorNode* propertyEditorNode)
	{
		ASSERT(propertyEditorNode->m_vecChild.size() == m_vecChild.size());
		for(uint32 idx = 0; idx < m_vecChild.size(); ++idx)
		{
			m_vecChild[idx]->SaveRecurs(propertyEditorNode->m_vecChild[idx].Get());
		}
	}
	bool CObjectPropertyResetter::IsEqualToDefault(CPropertyEditorNode* propertyEditorNode) const
	{
		ASSERT(propertyEditorNode->m_vecChild.size() == m_vecChild.size());
		bool allEqual = true;
		for(uint32 idx = 0; idx < m_vecChild.size(); ++idx)
		{
			if (!m_vecChild[idx]->IsEqualToDefault(propertyEditorNode->m_vecChild[idx].Get()))
			{
				allEqual = false;
				break;
			}
		}
		return allEqual;
	}
	
	static void CountChildrenRowsRecurs(CPropertyEditorNode* parent, uint32& rowsCount)
	{
		for (auto& it : parent->m_vecChild)
		{
			if (auto child = it.Get())
			{
				rowsCount++;
				CountChildrenRowsRecurs(child, rowsCount);
			}
		}
	}
	
	CArrayPropertyResetter::CArrayPropertyResetter()
		: m_defaultsCount(9999)
	{
	}
	CPropertyResetter* CArrayPropertyResetter::GetChildPropertyResetter(uint32 idx) const
	{
		return m_elementResetter.Get();
	}
	void CArrayPropertyResetter::LLLL(CPropertyEditorNode* propertyEditorNode) const
	{
		auto group = CPropertyGroup::Cast(propertyEditorNode->m_propertyNode);
		auto arrayAccessor = CArrayAccessor::Cast(group->m_accessor);
		auto& parentBase = group->m_parentBase;
		
		ArrayAccessorBasedGroupHelper_SetElementsCount(group, arrayAccessor, m_defaultsCount);
		
		//todo: ����ֻΪ�������, �ƻ�ʵ��Visit+Iteration�ķ��ʵ�����еݹ��ؽ�����
		auto& treeEditor = propertyEditorNode->m_owner;

		uint32 childrenRowsCount = 0;
		CountChildrenRowsRecurs(propertyEditorNode, childrenRowsCount);
		propertyEditorNode->Clear();
				
		auto rowIdx = treeEditor->FindRowIndex(propertyEditorNode->m_widgetRow);
		while (childrenRowsCount--)
			treeEditor->DeleteRow(rowIdx + 1);
		ASSERT(propertyEditorNode->m_resetter == this);
		treeEditor->BuildBranchRecurs2(group, propertyEditorNode, propertyEditorNode->m_resetter, rowIdx);
		//end

		for (uint32 idx = 0; idx < propertyEditorNode->m_vecChild.size(); ++idx)
		{
			m_elementResetter->LLLL(propertyEditorNode->m_vecChild[idx].Get());
		}
	}
	void CArrayPropertyResetter::SaveRecurs(CPropertyEditorNode* propertyEditorNode)
	{
		auto group = CPropertyGroup::Cast(propertyEditorNode->m_propertyNode);
		auto arrayAccessor = CArrayAccessor::Cast(group->m_accessor);
		auto& parentBase = group->m_parentBase;
		m_defaultsCount = arrayAccessor->GetElementsCount(parentBase);
		
		if (propertyEditorNode->m_vecChild.size() > 0)
			m_elementResetter->SaveRecurs(propertyEditorNode->m_vecChild[0].Get());
	}
	bool CArrayPropertyResetter::IsEqualToDefault(CPropertyEditorNode* propertyEditorNode) const
	{
		auto group = CPropertyGroup::Cast(propertyEditorNode->m_propertyNode);
		auto arrayAccessor = CArrayAccessor::Cast(group->m_accessor);
		auto& parentBase = group->m_parentBase;
		auto count = arrayAccessor->GetElementsCount(parentBase);
		bool allEqual = true;
		if (count == m_defaultsCount)
		{
			for (auto& it : propertyEditorNode->m_vecChild)
			{
				if (!m_elementResetter->IsEqualToDefault(it.Get()))
				{
					allEqual = false;
					break;
				}
			}
		}
		else
		{
			allEqual = false;
		}
		return allEqual;
	}

	//todo: δʵ��accessor������Ϣ, �����ʱ����factory���
	class CPropertyResetterFactory
	{
	public:
		static CSharedPropertyResetter CreateResetter(CAccessor* accessor)//todo: ��Ϊ��֤�ָ�Ĭ�����Կ�����, ʵ�ʵ�ʵ��Ӧ���޲���
		{
			if (CFieldAccessor::CastChecked(accessor) != NULL)
				return MakeSharable(CInstance::New<CFieldPropertyResetter>());
			else if (CObjectAccessor::CastChecked(accessor) != NULL)
				return MakeSharable(CInstance::New<CObjectPropertyResetter>());
			else if (CArrayAccessor::CastChecked(accessor) != NULL)
				return MakeSharable(CInstance::New<CArrayPropertyResetter>());
			ASSERT(false);
			return NULL;
		}
	};

	static void BuildAccessorResetterRecurs3(CObjectAccessor* parentAccessor, CObjectPropertyResetter* parentRessetter)
	{
		for (uint32 idx = 0; idx < parentAccessor->GetChildrenCount(); ++idx)
		{
			auto childAccessor = parentAccessor->GetChild(idx);
			auto childResetter = CPropertyResetterFactory::CreateResetter(childAccessor);
			BuildAccessorResetterRecurs2(childAccessor, childResetter.Get());
			parentRessetter->m_vecChild.push_back(childResetter);
		}
	}
	static void BuildAccessorResetterRecurs4(CArrayAccessor* parentAccessor, CArrayPropertyResetter* parentRessetter)
	{
		auto elementAccessor = parentAccessor->GetItemAccessor();
		auto elementResetter = CPropertyResetterFactory::CreateResetter(elementAccessor);
		BuildAccessorResetterRecurs2(elementAccessor, elementResetter.Get());
		parentRessetter->m_elementResetter = elementResetter;
	}
	void BuildAccessorResetterRecurs2(CAccessor* parentAccessor, CPropertyResetter* parentRessetter)
	{
		if (auto objectAccessor = CObjectAccessor::CastChecked(parentAccessor))
		{
			auto objectResetter = CObjectPropertyResetter::Cast(parentRessetter);
			BuildAccessorResetterRecurs3(objectAccessor, objectResetter);
		}
		else if (auto arrayAccessor = CArrayAccessor::CastChecked(parentAccessor))
		{
			auto arrayResetter = CArrayPropertyResetter::Cast(parentRessetter);
			BuildAccessorResetterRecurs4(arrayAccessor, arrayResetter);
		}
	}
}