#pragma once
#include "Niflect/Accessor/NiflectAccessor.h"

namespace TestWidgetBinding
{
	class CPropertyResetter;
	class CPropertyEditorNode;
	
	using CSharedPropertyResetter = Niflect::TSharedPtr<CPropertyResetter>;
//
	class CPropertyResetter
	{
	public:
		virtual CPropertyResetter* GetChildPropertyResetter(uint32 idx) const = 0;
		virtual void LLLL(CPropertyEditorNode* propertyEditorNode) const = 0;
		virtual void SaveRecurs(CPropertyEditorNode* propertyEditorNode) = 0;
		virtual bool IsEqualToDefault(CPropertyEditorNode* propertyEditorNode) const = 0;//�ú�������ʵ��, ʵ��ʹ���м���Ƿ�ΪĬ���Ƕ��������������, ��Ϊ�����ӽڵ�ı仯�����и��ڵ㶼���ܱ仯, �����Ҫ��ȡ�������޸ķ�֧, �����ϵݹ����Ƿ�ΪĬ��, ������Ҳ���ܱ�֤ԭ���Ƿ�ΪĬ��, ��˼����, ��Root��ʼȫ������һ�鼴��
		//bool m_isContainerResetter2;
	};
	
	class CFieldPropertyResetter : public CPropertyResetter
	{
	public:
		virtual CPropertyResetter* GetChildPropertyResetter(uint32 idx) const override
		{
			ASSERT(false);
			return NULL;
		}
		virtual void LLLL(CPropertyEditorNode* propertyEditorNode) const override;
		virtual void SaveRecurs(CPropertyEditorNode* propertyEditorNode) override;
		virtual bool IsEqualToDefault(CPropertyEditorNode* propertyEditorNode) const override;
		static CFieldPropertyResetter* Cast(CPropertyResetter* base)
		{
			ASSERT(dynamic_cast<CFieldPropertyResetter*>(base) != NULL);
			return static_cast<CFieldPropertyResetter*>(base);
		}
		Niflect::CString m_default;
	};

	class CObjectPropertyResetter : public CPropertyResetter
	{
	public:
		virtual CPropertyResetter* GetChildPropertyResetter(uint32 idx) const override;
		virtual void LLLL(CPropertyEditorNode* propertyEditorNode) const override;
		virtual void SaveRecurs(CPropertyEditorNode* propertyEditorNode) override;
		virtual bool IsEqualToDefault(CPropertyEditorNode* propertyEditorNode) const override;
		static CObjectPropertyResetter* Cast(CPropertyResetter* base)
		{
			ASSERT(dynamic_cast<CObjectPropertyResetter*>(base) != NULL);
			return static_cast<CObjectPropertyResetter*>(base);
		}
		Niflect::TArrayNif<CSharedPropertyResetter> m_vecChild;
	};
	
	class CArrayPropertyResetter : public CPropertyResetter
	{
	public:
		CArrayPropertyResetter();
		virtual CPropertyResetter* GetChildPropertyResetter(uint32 idx) const override;
		virtual void LLLL(CPropertyEditorNode* propertyEditorNode) const override;
		virtual void SaveRecurs(CPropertyEditorNode* propertyEditorNode) override;
		virtual bool IsEqualToDefault(CPropertyEditorNode* propertyEditorNode) const override;
		static CArrayPropertyResetter* Cast(CPropertyResetter* base)
		{
			ASSERT(dynamic_cast<CArrayPropertyResetter*>(base) != NULL);
			return static_cast<CArrayPropertyResetter*>(base);
		}
		uint32 m_defaultsCount;
		CSharedPropertyResetter m_elementResetter;
	};

	void BuildAccessorResetterRecurs2(Niflect::CAccessor* parentAccessor, CPropertyResetter* parentRessetter);
}