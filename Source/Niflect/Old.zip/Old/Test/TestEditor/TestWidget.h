#pragma once
#include "Niflect/Base/NiflectBase.h"
#include "Niflect/Util/StringUtil.h"
#include <functional>//�ؼ��ص�

namespace TestWidget
{
	class CMyWidget;
	class CMyLayout;

	using CSharedWidget = Niflect::TSharedPtr<CMyWidget>;
	using CSharedLayout = Niflect::TSharedPtr<CMyLayout>;

	//����Widget��ص������ʵ��GUI Tool Kit�еĿؼ�����, ���ڼ򻯲���, ��������Widget��Ϊ����GUI Tool Kit, ��Qt, ��ϷGUI, IMGUI��

	class CMyWidget
	{
	public:
		void InitWidget(const Niflect::CString& caption)
		{
			m_caption = caption;
		}
		void SetLayout(const CSharedLayout& layout)
		{
			m_layout = layout;
		}
		virtual void DebugGetDebugString(Niflect::CString& str) const
		{
		}

	public:
		Niflect::CString m_caption;
		CSharedLayout m_layout;
	};

	class CMyLayout
	{
	public:
		void Init(const Niflect::CString& debugName)
		{
			m_debugName = debugName;
		}
		void InsertWidget(const CSharedWidget& widget, uint32 idx)
		{
			m_vecWidget.insert(m_vecWidget.begin() + idx, widget);
		}
		void DeleteWidgetByIndex(uint32 idx)
		{
			m_vecWidget.erase(m_vecWidget.begin() + idx);
		}
		void DeleteWidget(CMyWidget* widget)
		{
			auto idx = this->FindWidgetIndex(widget);
			if (idx != INDEX_NONE)
				this->DeleteWidgetByIndex(idx);
		}
		uint32 FindWidgetIndex(CMyWidget* widget) const
		{
			for (uint32 idx = 0; idx < m_vecWidget.size(); ++idx)
			{
				if (m_vecWidget[idx].Get() == widget)
					return idx;
			}
			return INDEX_NONE;
		}
		void AddWidget(const CSharedWidget& widget)
		{
			this->InsertWidget(widget, this->GetWidgetsCount());
		}
		void AddChild(const CSharedLayout& layout)
		{
			m_vecChild.push_back(layout);
		}
		void Clear()
		{
			m_vecChild.clear();
			m_vecWidget.clear();
		}
		uint32 GetWidgetsCount() const
		{
			return static_cast<uint32>(m_vecWidget.size());
		}
		Niflect::TArrayNif<CSharedLayout> m_vecChild;
		Niflect::TArrayNif<CSharedWidget> m_vecWidget;
		Niflect::CString m_debugName;
	};

	class CMyLayoutDefault : public CMyLayout
	{
	};

	class CMyWidgetButton : public CMyWidget
	{
	public:
		void Click()
		{
			m_OnClicked();
		}
		//�����ڱ༭����, ��˼�Debugǰ׺, �༭Widget������������, ���Ԥ�벻��ҪCast
		static CMyWidgetButton* DebugCast(CMyWidget* base)
		{
			ASSERT(dynamic_cast<CMyWidgetButton*>(base) != NULL);
			return static_cast<CMyWidgetButton*>(base);
		}
		std::function<void()> m_OnClicked;
	};

	class DebugCMyWidgetButtonResetToDefault : public CMyWidgetButton
	{
	};

	class CMyWidgetRow : public CMyWidget
	{
	public:
		static CMyWidgetRow* DebugCastChecked(CMyWidget* base)
		{
			return dynamic_cast<CMyWidgetRow*>(base);
		}
	};

	class CMyWidgetCollapse : public CMyWidget
	{
	public:
		virtual void DebugGetDebugString(Niflect::CString& str) const override
		{
			Niflect::CString flatten;
			for (uint32 idx = 0; idx < m_debugVecRow.size(); ++idx)
			{
				flatten += m_debugVecRow[idx]->m_caption;
				if (idx != m_debugVecRow.size() - 1)
					flatten += ", ";
			}
			str = NiflectUtil::FormatString("Rows: %s", flatten.c_str());
		}
		static CMyWidgetCollapse* DebugCastChecked(CMyWidget* base)
		{
			return dynamic_cast<CMyWidgetCollapse*>(base);
		}

		Niflect::TArrayNif<CMyWidgetRow*> m_debugVecRow;
	};

	static CSharedLayout CreateLayout(const Niflect::CString& debugName)
	{
		auto layout = Niflect::CInstance::New<CMyLayoutDefault>();
		layout->Init(debugName);
		return Niflect::MakeSharable(layout);
	}

	template <typename TWidget>
	static Niflect::TSharedPtr<TWidget> CreateWidget(const Niflect::CString& caption)
	{
		auto widget = Niflect::CInstance::New<TWidget>();
		widget->InitWidget(caption);
		return Niflect::MakeSharable(widget);
	}
	template <typename TWidget>
	static Niflect::TSharedPtr<TWidget> CreateWidgetDefaultLayout(const Niflect::CString& caption)
	{
		auto widget = Niflect::CInstance::New<TWidget>();
		widget->InitWidget(caption);
		auto layout = CreateLayout("Layout");
		widget->SetLayout(layout);
		return Niflect::MakeSharable(widget);
	}
	template <typename TWidget>
	static TWidget* CreateInsertWidgetDefaultLayout(CMyWidget* widgetParent, const Niflect::CString& caption, uint32 idx)
	{
		auto& layoutParent = widgetParent->m_layout;
		auto widget = CreateWidgetDefaultLayout<TWidget>(caption);
		layoutParent->InsertWidget(widget, idx);
		return widget.Get();
	}
	template <typename TWidget>
	static TWidget* CreateAddWidgetDefaultLayout(CMyWidget* widgetParent, const Niflect::CString& caption)
	{
		return CreateInsertWidgetDefaultLayout<TWidget>(widgetParent, caption, widgetParent->m_layout->GetWidgetsCount());
	}

	class CMyWidgetTextEdit : public CMyWidget
	{
		//typedef void (*OnTextChangedFunc)(const CString& oldText);
	public:
		virtual void DebugGetDebugString(Niflect::CString& str) const override
		{
			str = NiflectUtil::FormatString("Text: %s", m_text.c_str());
		}

	public:
		void EditText(const Niflect::CString& newText)
		{
			auto oldText = m_text;
			m_text = newText;
			m_OnTextChanged(oldText);
		}

	public:
		//�����ڱ༭����, ��˼�Debugǰ׺, �༭Widget������������, ���Ԥ�벻��ҪCast
		static CMyWidgetTextEdit* DebugCast(CMyWidget* base)
		{
			ASSERT(dynamic_cast<CMyWidgetTextEdit*>(base) != NULL);
			return static_cast<CMyWidgetTextEdit*>(base);
		}

	public:
		Niflect::CString m_text;
		std::function<void(const Niflect::CString& oldText)> m_OnTextChanged;
	};
}
