#pragma once
#include "Niflect/Property/Property.h"
#include "Niflect/Test/TestEditor/TestWidget.h"
#include "Niflect/Test/TestEditor/TestPropertyResetter.h"
#include "Niflect/Test/TestEditor/TestPropertyEditor.h"

namespace TestWidgetBinding
{
	using namespace TestWidget;
	
	class CPropertyEditorNode;
	class CPropertyTreeEditor;

	using CSharedPropertyEditorNode = Niflect::TSharedPtr<CPropertyEditorNode>;
	//todo: �����Ƿ��б�Ҫ��CPropertyNode��Ӧ, ���ֳ�CPropertyEditorGroup��CPropertyEditorItem
	class CPropertyEditorNode
	{
	public:
		CPropertyEditorNode()
			: m_owner(NULL)
			, m_parent(NULL)
			, m_propertyNode(NULL)
			, m_widgetRow(NULL)
			, m_widgetCollapse(NULL)
			, m_resetter(NULL)
		{
		}
		void Init(CPropertyTreeEditor* owner, Niflect::CPropertyNode* propertyNode, CPropertyResetter* resetter, CMyWidgetRow* widgetRow)
		{
			m_owner = owner;
			m_propertyNode = propertyNode;
			m_widgetRow = widgetRow;
			m_resetter = resetter;
		}
		void Add(const CSharedPropertyEditorNode& node)
		{
			m_vecChild.push_back(node);
			node->m_parent = this;
		}
		void Clear()
		{
			m_vecChild.clear();
			m_widgetCollapse->m_debugVecRow.clear();
		}
		CPropertyEditorNode* m_parent;
		Niflect::TArrayNif<CSharedPropertyEditorNode> m_vecChild;
		Niflect::CPropertyNode* m_propertyNode;
		CMyWidgetRow* m_widgetRow;
		CMyWidgetCollapse* m_widgetCollapse;
		CPropertyTreeEditor* m_owner;
		CSharedPropertyEditor m_editor;
		CPropertyResetter* m_resetter;
	};

}