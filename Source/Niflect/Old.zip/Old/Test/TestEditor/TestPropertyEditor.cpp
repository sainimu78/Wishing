#include "Niflect/Test/TestEditor/TestPropertyEditor.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"
#include "Niflect/Util/StringUtil.h"
#include "Niflect/Test/TestEditor/TestPropertyEditorNode.h"
#include "Niflect/Test/TestEditor/TestPropertyTreeEditor.h"

namespace TestWidgetBinding
{
	using namespace Niflect;

	void CFieldPropertyEditorFloat::Apply(const CString& text) const
	{
		auto rawValue = NiflectUtil::StringToFloat(text);
		auto& propertyNode = m_propertyEditorNode->m_propertyNode;
		auto accessor = propertyNode->m_accessor;

		CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
		CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
		//CRwJson::AllocatorStack stack;
		//CRwJson::AllocatorPool allocator(poolCapa, &stack);
		CRwJson::AllocatorStack stack;
		auto& allocator = stack;
		CRwJson::Document jd(&allocator, poolCapa, &allocator);
		auto& joRoot = CRwJson::AsRoot(jd);
		CJsonRwDocument doc(jd, joRoot);
		auto rwRoot = doc.GetRootNode();
		ValueReadWrite::Save(rwRoot->ToValue(), rawValue);

		accessor->LoadFromRwNode(propertyNode->m_parentBase, rwRoot);
	}
	
	static void CountChildrenRowsRecurs(CPropertyEditorNode* parent, uint32& rowsCount)
	{
		for (auto& it : parent->m_vecChild)
		{
			if (auto child = it.Get())
			{
				rowsCount++;
				CountChildrenRowsRecurs(child, rowsCount);
			}
		}
	}
		
	void CArrayPropertyEditor::AddElement()
	{
		//todo: ��ȡpropertyGroup��arrayAccessor��Ϊoverload����ȡ���Ѻ�Щ
		auto& propertyNode = m_propertyEditorNode->m_propertyNode;
		if (auto group = CPropertyGroup::CastChecked(propertyNode))
		{
			if (auto arrayAccessor = CArrayAccessor::CastChecked(group->m_accessor))
			{
				//todo: ��ʾ���̲�����, ʵ�ʵ�ʵ�ֻ���Ҫ����Ĭ������, ��resetter����, ��Ҫһ��dirty����ͳһʵ����Щ���Ӳ���
				auto& parentBase = group->m_parentBase;
				auto oldCount = arrayAccessor->GetElementsCount(parentBase);
				auto newCount = oldCount + 1;
				ArrayAccessorBasedGroupHelper_SetElementsCount(group, arrayAccessor, newCount);
				printf("Add element: %u -> %u\n", oldCount, newCount);

				auto& treeEditor = m_propertyEditorNode->m_owner;

				uint32 childrenRowsCount = 0;
				CountChildrenRowsRecurs(m_propertyEditorNode, childrenRowsCount);
				m_propertyEditorNode->Clear();
				
				auto rowIdx = treeEditor->FindRowIndex(m_propertyEditorNode->m_widgetRow);
				while (childrenRowsCount--)
					treeEditor->DeleteRow(rowIdx + 1);

				treeEditor->BuildBranchRecurs2(group, m_propertyEditorNode, m_propertyEditorNode->m_resetter, rowIdx);
			}
			else
			{
				ASSERT(false);
			}
		}
		else
		{
			ASSERT(false);
		}
	}
}