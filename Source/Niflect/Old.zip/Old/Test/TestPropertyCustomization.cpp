#include <stdio.h>
#include "Niflect/Base/NiflectRegisteredType.h"
#include "Niflect/Memory/Stats/NiflectMemoryStats.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"
#include "Niflect/Module/RuntimeModule.h"
#include "Niflect/Property/EditorModule.h"
#include "Niflect/Test/TestType/MyClass.h"
#include "Niflect/Util/DebugUtil.h"
#include "Niflect/Util/StringUtil.h"
#include "Niflect/Property/Property.h"
#include "Niflect/Test/TestModule0.h"

namespace Niflect
{
	class CDynamicClass
	{
	public:

	private:
		CSharedAccessor m_accessorRoot;
		TArrayNif<uint8> m_heap;
	};
}

static void MyExp()
{
	using namespace Niflect;

	auto memTest = DebugGetMemoryStats();
	TestCreateModuleReg0();

	{
		using namespace MyTestClassScope;
		
		CPropetyTree tree0;
		CMyClass0 obj0;
		{
			auto typeToBuild = StaticGetType<CMyClass0>();
			tree0.GenerateStackedTypeLayout(CInheritableType::Cast(typeToBuild));
			tree0.Build(&obj0);
		}
		CPropetyTree tree1;
		CMyClass1 obj1;
		{
			auto typeToBuild = StaticGetType<CMyClass1>();
			tree1.GenerateStackedTypeLayout(CInheritableType::Cast(typeToBuild));
			SetupTestInstance_CMyClass1(obj1);
			tree1.Build(&obj1);
		}

		const auto& root0 = tree0.m_root;
		auto root1 = &tree1.m_root;
		
		auto group_m_sub0 = CPropertyGroup::Cast(CPropertyGroup::Cast(root1->m_vecChild[1].Get())->m_vecChild[2].Get());
		auto item_m_myFloat1 = CPropertyItem::Cast(group_m_sub0->m_vecChild[1].Get());
		const uint32 insertIndexAfter = 0;
		{
			uint32 insertIdx = insertIndexAfter + 1;
			for (auto& it : root0.m_vecChild)
			{
				group_m_sub0->InsertChild(it, insertIdx);
				insertIdx++;
			}
		}
		if (false)
		{
			uint32 insertIdx = insertIndexAfter + 1;
			auto count = root0.GetChildrenCount();
			while(count--)
			{
				group_m_sub0->DeleteChild(insertIdx);
			}
		}

		PrintPropertyRecurs(root1, 0);
		printf("");
	}

	TestDestroyModuleReg0();
		
	printf("");
}

#ifdef TEST_FOR_GCC
#else
#include <Windows.h>
class CStaticTest
{
public:
	CStaticTest()
	{
#ifdef WIN32
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
#endif
		MyExp();
	}
};
//CStaticTest s;
#endif

#ifdef TEST_FOR_GCC
int main()
{
	MyExp();
	return 0;
}
#else
#endif