#pragma once
#include "Niflect/Property/Property.h"
#include "Niflect/Property/NiflectMetaFactory.h"
#include "Niflect/Base/NiflectRegisteredType.h"
//#include "Niflect/Test/TestType/MyBaseAccessor.h"

namespace MyTestClassScope
{
	////todo: ȷ����ȷ��, ͨ����: PropertyTree�Ľṹ��ֻ��ͨ�õ�PropertyItem, ���ڻ�������CAccessorFloatҲ��ͨ��PropertyItem��
	//class CReflectorEditorRegger_CAccessorFloat
	//{
	//public:
	//	static void StaticRegisterMeta(CMetaFactory& factory)
	//	{
	//		auto& idx = TTypeIndexedName<CAccessorFloat>::GetIndex();
	//		auto meta = CClassMemory::New<CMeta>();
	//		factory.RegisterMetaAtIndex(MakeSharable(meta), idx);
	//	}
	//	static void StaticFillMetaInfo(CMetaFactory& factory)
	//	{
	//		auto& idx = TTypeIndexedName<CAccessorFloat>::GetIndex();
	//		auto meta = factory.GetMutableMetaByIndex(idx);
	//		meta->m_InvokeBuildPropertyNodeFunc = &StaticBuildPropertyNode;
	//	}
	//	static CSharedPropertyNode StaticBuildPropertyNode(const CMetaFactory& factory, CPropertyTree* tree, CAccessor* accessor)
	//	{
	//		auto item = CClassMemory::New<CPropertyItem>();
	//		item->InitMeta(tree, "Accessor Float", TTypeIndexedName<CAccessorFloat>::GetType(), accessor);
	//		return MakeSharable(item);
	//	}
	//};
}