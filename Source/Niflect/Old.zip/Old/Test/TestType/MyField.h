#pragma once
#include "Niflect/Accessor/NiflectAccessor.h"
#include "Niflect/Test/NiflectGenerated/MyModule/MyField.gen.h"

namespace MyTestClassScope
{
	//NIF_T()
	class CFieldFloat : public Niflect::CFieldAccessor
	{
	public:
		void SetValue(void* parentBase, float value)
		{
			auto& instance = Niflect::AccessInstance_Deprecated<float>(this, parentBase, NULL);
			instance = value;
		}
		const float& GetValue(void* parentBase) const
		{
			auto& instance = Niflect::AccessInstance_Deprecated<float>(this, parentBase, NULL);
			return instance;
		}
	};
	NIF_T()
	class CFieldBool : public Niflect::CFieldAccessor
	{
	};

	namespace MySub
	{
		NIF_T()
		class CFieldTestMy : public Niflect::CFieldAccessor
		{
		public:
			NIF_T()
			class CSubMy0 : public Niflect::CFieldAccessor
			{
			};
		};

		class CFieldMyFloatDef : public Niflect::CFieldAccessor
		{
		};

		class CFieldTestMyNoGen : public Niflect::CFieldAccessor
		{
		public:
			NIF_T()
			class CSubMy1 : public Niflect::CFieldAccessor
			{
			};
		};

		//todo: �ݲ�֧��, ��NiflectGenע��"��Ҫ��Accessor��������"
		//template <typename T>
		//class CFieldTestMyTemplate : public Niflect::CFieldAccessor
		//{
		//public:
		//	NIF_T()
		//	class CSubMy2 : public Niflect::CFieldAccessor
		//	{
		//	};
		//};
	}

	class CFieldInt : public Niflect::CFieldAccessor
	{
	};
	
	template <typename T>
	class TFieldPointer : public Niflect::CFieldAccessor
	{
	};
}