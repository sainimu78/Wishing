#pragma once
#include "Niflect/Test/NiflectGenerated/MyModule/MyClass.gen.h"

namespace MyTestClassScope
{
	//todo: ��������������ͻ�����Ϊ����������Ƿ�֧��

	NIF_T()
	class CMyClass0
	{
		NIF_FRIEND(CMyClass0)//GENERATED_BODY()//todo: ���޷�ʵ�ֲ�include gen.hʵ�ֲ�ָ��CMyClass, ��Ҫ�������շ����Ƿ����include gen.h
	public:
		CMyClass0()
			: m_myFloat0(111.0f)
			, m_myFloat1(111.1f)
		{
			//static int cnt = 0;
			//printf("CMyClass0, Ctor, %d\n", ++cnt);
		}
		~CMyClass0()
		{
			//static int cnt = 0;
			//printf("CMyClass0, Dtor, %d\n", ++cnt);
		}

	public:
		NIF_F()
		float m_myFloat0;
		NIF_F()
		float m_myFloat1;
	};

	NIF_T()
	class CMyClassBase1
	{
		NIF_FRIEND(CMyClassBase1)//GENERATED_BODY()//todo: ���޷�ʵ�ֲ�include gen.hʵ�ֲ�ָ��CMyClass, ��Ҫ�������շ����Ƿ����include gen.h
	public:
		CMyClassBase1()
			: m_myFloatBase2(111.2f)
			, m_myFloatBase3(111.3f)
		{
			//static int cnt = 0;
			//printf("CMyClassBase1, Ctor, %d\n", ++cnt);
		}
		~CMyClassBase1()
		{
			//static int cnt = 0;
			//printf("CMyClassBase1, Dtor, %d\n", ++cnt);
		}

	public:
		NIF_F()
		float m_myFloatBase2;
		NIF_F()
		Niflect::TArrayNif<float> m_myStdFloatArrayBase0;
		NIF_M()
		bool MyFunc0(float arg0, const CMyClass0& arg1, bool* arg2, CMyClass0* arg3, float** arg4)
		{
			printf("Invoke MyFunc0: %f, %f, %s, %f, %f\n", arg0, arg1.m_myFloat1, *arg2 ? "true" : "false", arg3->m_myFloat1, arg4[1][2]);
			if ((arg0 == 1.0f) &&
				(arg1.m_myFloat1 == 111.1f) &&
				(*arg2 == true) &&
				(arg3->m_myFloat1 == 2.0f) &&
				(arg4[1][2] == 9.0f)
				)
			{
				return true;
			}
			return false;
		}
		NIF_F()
		float m_myFloatBase3;
	};
	
	template <typename T>
	class TMyVector
	{
	public:
		T m_x;
		T m_y;
		T m_z;
	};

	template <typename T>
	class TMyQuaternion
	{
	public:
		T m_x;
		T m_y;
		T m_z;
		T m_w;
	};

	template <typename T>
	class TMyTransform
	{
	public:
		TMyVector<T> m_translation;
		TMyQuaternion<T> m_rotation;
		TMyVector<T> m_scale;
	};

	using CMyTransform = TMyTransform<float>;

	//todo: ���������븸�����ͬ��, �����ɹ��߱���, ��ʾ��֧��
	NIF_T()
	class CMyClass1 : public CMyClassBase1
	{
		NIF_FRIEND(CMyClass1)//GENERATED_BODY()//todo: ���޷�ʵ�ֲ�include gen.hʵ�ֲ�ָ��CMyClass, ��Ҫ�������շ����Ƿ����include gen.h
	public:
		CMyClass1()
			: m_myFloat4(111.4f)
			, m_myFloat5(111.5f)
		{
			//static int cnt = 0;
			//printf("CMyClass1, Ctor, %d\n", ++cnt);
		}
		~CMyClass1()
		{
			//static int cnt = 0;
			//printf("CMyClass1, Dtor, %d\n", ++cnt);
		}

	public:
		NIF_F()
		float m_myFloat4;
		NIF_F()
		Niflect::TArrayNif<float> m_myStdFloatArray1;
		NIF_F()
		CMyClass0 m_sub0;
		NIF_F()
		Niflect::TArrayNif<Niflect::TArrayNif<float> > m_myStdFloatArrayArray2;
		NIF_F()
		float m_myFloat5;
		//REFLECTOR_ACCESS()
		//CMyVector3f m_myVector3f;
		NIF_F()
		CMyTransform m_tm;
	};

	template <typename T>
	class TMyTransformAccessor : public CObjectAccessor
	{
	public:
		void MyCreateAccessorTree()
		{
			{
				auto shared0 = MakeShared<CObjectAccessor>();
				auto node0 = shared0.Get();
				node0->SetOffset(GetMemberVariableOffset(&TMyTransform<T>::m_translation));
				//node0->InitMeta(StaticGetType<CMyTransform>());
				{
					auto shared1 = CreateFieldAccessorAddr<T>(GetMemberVariableOffset(&TMyVector<T>::m_x));
					auto node1 = shared1.Get();
					node1->InitMemberMeta("m_x", node0);
					node0->AddChild(shared1);
				}
				{
					auto shared1 = CreateFieldAccessorAddr<T>(GetMemberVariableOffset(&TMyVector<T>::m_y));
					auto node1 = shared1.Get();
					node1->InitMemberMeta("m_y", node0);
					node0->AddChild(shared1);
				}
				{
					auto shared1 = CreateFieldAccessorAddr<T>(GetMemberVariableOffset(&TMyVector<T>::m_z));
					auto node1 = shared1.Get();
					node1->InitMemberMeta("m_z", node0);
					node0->AddChild(shared1);
				}

				node0->InitMemberMeta("m_translation", this);
				this->AddChild(shared0);
			}
			{
				auto shared0 = MakeShared<CObjectAccessor>();
				auto node0 = shared0.Get();
				node0->SetOffset(GetMemberVariableOffset(&TMyTransform<T>::m_rotation));
				{
					auto shared1 = CreateFieldAccessorAddr<T>(GetMemberVariableOffset(&TMyQuaternion<T>::m_x));
					auto node1 = shared1.Get();
					node1->InitMemberMeta("m_x", node0);
					node0->AddChild(shared1);
				}
				{
					auto shared1 = CreateFieldAccessorAddr<T>(GetMemberVariableOffset(&TMyQuaternion<T>::m_y));
					auto node1 = shared1.Get();
					node1->InitMemberMeta("m_y", node0);
					node0->AddChild(shared1);
				}
				{
					auto shared1 = CreateFieldAccessorAddr<T>(GetMemberVariableOffset(&TMyQuaternion<T>::m_z));
					auto node1 = shared1.Get();
					node1->InitMemberMeta("m_z", node0);
					node0->AddChild(shared1);
				}
				{
					auto shared1 = CreateFieldAccessorAddr<T>(GetMemberVariableOffset(&TMyQuaternion<T>::m_w));
					auto node1 = shared1.Get();
					node1->InitMemberMeta("m_w", node0);
					node0->AddChild(shared1);
				}

				node0->InitMemberMeta("m_rotation", this);
				this->AddChild(shared0);
			}
		}
	};

	using CMyTransformAccessor = TMyTransformAccessor<float>;

	static void SetupTestInstance_CMyClass1(CMyClass1& obj)
	{
		obj.m_myFloat4 = 222.4f;
		obj.m_myStdFloatArray1.push_back(33.0f);
		obj.m_myStdFloatArray1.push_back(33.1f);
		obj.m_myStdFloatArray1.push_back(33.2f);
		obj.m_sub0.m_myFloat0 = 222.0f;
		obj.m_sub0.m_myFloat1 = 222.1f;
		obj.m_myStdFloatArrayArray2.resize(2);
		obj.m_myStdFloatArrayArray2[0].push_back(5.0f);
		obj.m_myStdFloatArrayArray2[0].push_back(5.1f);
		obj.m_myStdFloatArrayArray2[0].push_back(5.2f);
		obj.m_myStdFloatArrayArray2[0].push_back(5.3f);
		obj.m_myStdFloatArrayArray2[0].push_back(5.4f);
		obj.m_myStdFloatArrayArray2[1].push_back(6.0f);
		obj.m_myStdFloatArrayArray2[1].push_back(6.1f);
		obj.m_myStdFloatArrayArray2[1].push_back(6.2f);
		obj.m_myStdFloatArrayArray2[1].push_back(6.3f);
		obj.m_myStdFloatArrayArray2[1].push_back(6.4f);
		obj.m_myStdFloatArrayArray2[1].push_back(6.5f);
		obj.m_myFloatBase2 = 222.2f;
		obj.m_myStdFloatArrayBase0.push_back(44.0f);
		obj.m_myStdFloatArrayBase0.push_back(44.1f);
		obj.m_myStdFloatArrayBase0.push_back(44.2f);
		obj.m_myStdFloatArrayBase0.push_back(44.3f);
		obj.m_myFloatBase3 = 222.3f;
		obj.m_myFloat5 = 222.5f;
		obj.m_tm.m_translation.m_x = 11.0f;
		obj.m_tm.m_translation.m_y = 11.1f;
		obj.m_tm.m_translation.m_z = 11.2f;
		obj.m_tm.m_rotation.m_x = 12.0f;
		obj.m_tm.m_rotation.m_y = 12.1f;
		obj.m_tm.m_rotation.m_z = 12.2f;
		obj.m_tm.m_rotation.m_w = 12.3f;
		obj.m_tm.m_scale.m_x = 13.0f;
		obj.m_tm.m_scale.m_y = 13.1f;
		obj.m_tm.m_scale.m_z = 13.2f;
	}
}