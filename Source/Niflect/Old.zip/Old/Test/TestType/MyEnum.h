#pragma once
#include "Niflect/Base/NiflectMacro.h"

namespace MyTestClassScope
{
	NIF_T()
	enum class EMyEnumOption
	{
		Option0,
		Option1,
	};
}