#pragma once
#include "Niflect/Reflector/ReflectorMacro.h"
#include "Niflect/Serialization/Tree/TreeReadWrite.h"

namespace MyTestClassScope
{
	using namespace TreeReadWrite2;

	class CMyVector3f
	{
	public:
		void MyCustomSave(CRwNode& rw) const
		{
			AddRwFloat(rw, "myX", m_x);
			AddRwFloat(rw, "myY", m_y);
			AddRwFloat(rw, "myZ", m_z);
		}
		void MyCustomLoad(const CRwNode& rw)
		{
			m_x = FindRwFloat(rw, "myX");
			m_y = FindRwFloat(rw, "myY");
			m_z = FindRwFloat(rw, "myZ");
		}

	public:
		float m_x;
		float m_y;
		float m_z;
	};

	//class CInheritableTypeReg_CMyVector3f
	//{
	//public:
	//	static void StaticBuildObjectAccessorTree(CObjectAccessor* parent)
	//	{
	//		auto member_m_x = CreateFieldAccessorMemberAddr(&CMyVector3f::m_x);
	//		member_m_x->SetName("m_x");
	//		parent->AddChild(member_m_x);

	//		auto member_m_y = CreateFieldAccessorMemberAddr(&CMyVector3f::m_y);
	//		member_m_y->SetName("m_y");
	//		parent->AddChild(member_m_y);

	//		auto member_m_z = CreateFieldAccessorMemberAddr(&CMyVector3f::m_z);
	//		member_m_z->SetName("m_z");
	//		parent->AddChild(member_m_z);
	//	}
	//};
}