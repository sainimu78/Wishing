#include <stdio.h>
#include "Niflect/Memory/Stats/NiflectMemoryStats.h"
#include "Niflect/Module/RuntimeModule.h"
#include "Niflect/Property/EditorModule.h"
#include "Niflect/Test/TestType/MyClass.h"
#include "Niflect/Test/TestEditor/TestPropertyTreeEditor.h"
#include "Niflect/Test/TestModule0.h"

static void MyExp()
{
	using namespace Niflect;
	using namespace MyTestClassScope;

	auto memTest = DebugGetMemoryStats();
	auto reg = TestCreateModuleReg0();

	{
		CPropetyTree tree;
		auto typeToBuild = StaticGetType<CMyClass1>();
		tree.GenerateStackedTypeLayout(CStruct::Cast(typeToBuild));
		CMyClass1 obj;
		SetupTestInstance_CMyClass1(obj);
		auto instanceBase = &obj;
		tree.Build(instanceBase);
		
		{
			using namespace TestWidget;
			using namespace TestWidgetBinding;
			auto sharedRootWidget = CreateWidgetDefaultLayout<CMyWidgetRow>("Property Panel Root Row");
			auto rootWidget = sharedRootWidget.Get();

			CPropertyTreeEditor propTreeEditor;
			propTreeEditor.Init(rootWidget);
			uint32 parentRowIndex = INDEX_NONE;
			propTreeEditor.BuildBranchRecurs2(&tree.m_root, &propTreeEditor.m_editorRoot, NULL, parentRowIndex);
			
			//PrintWidgetRecurs(rootWidget, 0);
			//PrintPropertyEditorNodeRecurs(&propTreeEditor.m_editorRoot, 0);

			auto& vecWidgetRow = rootWidget->m_layout->m_vecWidget;
			{
				auto& widgetRow = vecWidgetRow[7]->m_layout->m_vecWidget;
				auto widgetEdit = CMyWidgetTextEdit::DebugCast(widgetRow[0].Get());
				widgetEdit->EditText("12.34");
			}
			ASSERT(obj.m_myFloatBase3 == 12.34f);
			
			{
				auto& widgetRow = vecWidgetRow[28]->m_layout->m_vecWidget;
				auto widgetEdit = CMyWidgetTextEdit::DebugCast(widgetRow[0].Get());
				widgetEdit->EditText("43.21");
			}
			ASSERT(obj.m_myStdFloatArrayArray2[1][3] == 43.21f);

			ASSERT(vecWidgetRow.size() == 32);
			for (uint32 idx = 0; idx < 3; ++idx)
			{
				auto& widgetRow = vecWidgetRow[18]->m_layout->m_vecWidget;
				auto widgetButton = CMyWidgetButton::DebugCast(widgetRow[1].Get());
				widgetButton->Click();
			}
			ASSERT(vecWidgetRow.size() == 35);
			{
				auto& widgetRow = vecWidgetRow[25]->m_layout->m_vecWidget;
				auto widgetEdit = CMyWidgetTextEdit::DebugCast(widgetRow[0].Get());
				widgetEdit->EditText("56.7");
			}
			ASSERT(obj.m_myStdFloatArrayArray2[0][6] == 56.7f);
			
			{
				auto& widgetRow = vecWidgetRow[17]->m_layout->m_vecWidget;
				auto widgetButton = CMyWidgetButton::DebugCast(widgetRow[1].Get());
				widgetButton->Click();
			}
			ASSERT(vecWidgetRow.size() == 36);
			for (uint32 idx = 0; idx < 4; ++idx)
			{
				auto& widgetRow = vecWidgetRow[34]->m_layout->m_vecWidget;
				auto widgetButton = CMyWidgetButton::DebugCast(widgetRow[1].Get());
				widgetButton->Click();
			}
			ASSERT(vecWidgetRow.size() == 40);
			
			{
				auto& widgetRow = vecWidgetRow[37]->m_layout->m_vecWidget;
				auto widgetEdit = CMyWidgetTextEdit::DebugCast(widgetRow[0].Get());
				widgetEdit->EditText("76.5");
			}
			ASSERT(obj.m_myStdFloatArrayArray2[2][2] == 76.5f);

			{
				auto& widgetRow = vecWidgetRow[29]->m_layout->m_vecWidget;
				auto widgetEdit = CMyWidgetTextEdit::DebugCast(widgetRow[0].Get());
				widgetEdit->EditText("345.6");
			}
			ASSERT(obj.m_myStdFloatArrayArray2[1][1] == 345.6f);

			//��Click֮���ӡ������Row����Ǵ���, ��Ϊû�и���m_caption
			PrintPropertyEditorNodeRecurs(&propTreeEditor.m_editorRoot, 0);
			printf("");

		}
	}

	TestDestroyModuleReg0();

	printf("");
}

#ifdef TEST_FOR_GCC
#else
#include <Windows.h>
class CStaticTest
{
public:
	CStaticTest()
	{
#ifdef WIN32
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
#endif
		MyExp();
	}
};
//CStaticTest s;
#endif

#ifdef TEST_FOR_GCC
int main()
{
	MyExp();
	return 0;
}
#else
#endif