#include "Niflect/Binding/NiflectBindingSetting.h"
#include "Niflect/Test/TestDebugArray.h"

namespace MyStd
{
	template <typename T>
	class TMyArray
	{

	};

	namespace MySub
	{
		template <typename T>
		class TMySubArray0
		{
		public:
			class CMySubSub
			{
			
			};
		};
		template <typename T>
		class TMySubArray1
		{
			
		};

		class CMyEmbedded0
		{
		public:
			class CMyEmbedded1
			{
			};
		};
	}
}

class CMyAccessorBase
{

};

class CMyAccessor0
{

};

class CMyAccessor1 : public CMyAccessorBase
{

};

class CMyAccessor2
{

};

class CMyAccessor3
{

};

namespace DebugNamespace
{
	class CMyAccessorDebug
	{
	public:
		float m_myMemberFloat;
	};

	namespace DebugSub
	{
		class CMySubAccessorDebug
		{
		public:
			float m_myMemberFloat;
		};
	}
}

typedef float MyFloatDef;

#if 0
namespace TestTypeBindingSetting
{
	using namespace Niflect;

	//todo: ��ָ��ģ���������������<>ָ��ģ��ʵ����Ҫ�ò�ͬ��cursor���������Ի�ȡ��������, ���������޷�ͨ��clang_Type_getTemplateArgumentAsType��ȡ����Чcursor��type, ��Ҫ����cursor�л�ȡ, �����޷���ȡǶ��ģ��ʵ�������µĲ㼶��ϵ
	NIF_BS() TBindingSetting<float, TAccessorsTuple<bool, int> >;
	NIF_BS() TBindingSetting<bool, TAccessorsTuple<CMyAccessor0, CMyAccessor1, CMyAccessor2, CMyAccessor3> >;
	using namespace MyStd;
	//NIF_BS() TTemplateBindingSetting<TMyArray, TAccessorsTuple<CMyAccessor0, CMyAccessor1> >;
	NIF_BS() TBindingSetting<CMyAccessor1*, TAccessorsTuple<CMyAccessor0, CMyAccessor1> >;
	NIF_BS() TBindingSetting<float*, TAccessorsTuple<CMyAccessor0> >;
	NIF_BS() TBindingSetting<bool**, TAccessorsTuple<CMyAccessor0> >;
	NIF_BS() TBindingSetting<float**, TAccessorsTuple<CMyAccessor0**, CMyAccessor1**> >;
	using namespace DebugNamespace;
	NIF_BS() TBindingSetting<CMyAccessorDebug*, TAccessorsTuple<CMyAccessor0**, CMyAccessor1**> >;
	//NIF_BS() TTemplateBindingSetting<std::vector, TAccessorsTuple<CMyAccessor0, CMyAccessor1> >;
	NIF_BS() TBindingSetting<std::vector<float>, TAccessorsTuple<CMyAccessor0, CMyAccessor1> >;
	NIF_BS() TBindingSetting<std::vector<CMyAccessor2>, TAccessorsTuple<CMyAccessor0, CMyAccessor1> >;
	NIF_BS() TBindingSetting<MyStd::MySub::TMySubArray0<CMyAccessor2>::CMySubSub, TAccessorsTuple<CMyAccessor0, CMyAccessor1, CMyAccessor3> >;
	//NIF_BS() TTemplateBindingSetting<MySub::TMySubArray0, TAccessorsTuple<CMyAccessor0, CMyAccessor1> >;
	NIF_BS() TBindingSetting<CMyAccessor0*, TAccessorsTuple<MyStd::MySub::CMyEmbedded0::CMyEmbedded1, CMyAccessor2*> >;
	//NIF_BS() TTemplateBindingSetting<MyStd::MySub::TMySubArray1, TAccessorsTuple<CMyAccessor0, CMyAccessor1> >;
	NIF_BS() TBindingSetting<CMyAccessorDebug**, TAccessorsTuple<DebugNamespace::CMyAccessorDebug**, CMyAccessor1**> >;
	NIF_BS() TBindingSetting<CMyAccessorDebug, TAccessorsTuple<DebugNamespace::DebugSub::CMySubAccessorDebug**, DebugSub::CMySubAccessorDebug> >;

	//template <typename T>
	//NIF_BS() TBindingSetting<CMyAccessor0, TAccessorsTuple<std::vector<T>, MyStd::TMyArray<T> > >;
}
#endif

#include "Niflect/Test/TestType/MyField.h"

namespace TestTypeBindingSetting
{
	using namespace Niflect;
	using namespace MyTestClassScope;

	NIF_BS() TBindingSetting2<CFieldFloat, float>;
	NIF_BS() TBindingSetting2<CFieldBool, bool>;
	NIF_BS() TBindingSetting2<MyTestClassScope::MySub::CFieldTestMy, int>;
	NIF_BS() TBindingSetting2<MySub::CFieldTestMy::CSubMy0, double>;
	NIF_BS() TBindingSetting2<MySub::CFieldTestMyNoGen::CSubMy1, unsigned>;
	NIF_BS() TBindingSetting2<MyTestClassScope::MySub::CFieldMyFloatDef, MyFloatDef>;
	NIF_BS() TBindingSetting2<CFieldInt, char>;
	template <typename T>
	NIF_BS() TBindingSetting2<CArrayAccessor, TestContainer::TMyArrayDebug<T> >;
	//NIF_BS() TBindingSetting2<MySub::CFieldTestMyTemplate<float>::CSubMy2, TTypeTuple<char> >;//todo: �ݲ�֧��, ��NiflectGenע��"��Ҫ��Accessor��������"
}