#include <stdio.h>
#include "Niflect/Base/NiflectRegisteredType.h"
#include "Niflect/Base/NiflectTable.h"
#include "Niflect/Test/TestType/MyClass.h"
#include "Niflect/Memory/Stats/NiflectMemoryStats.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"
#include "Niflect/Module/RuntimeModule.h"
#include "Niflect/Util/DebugUtil.h"
#include "Niflect/Test/TestModule0.h"
#include "Niflect/Test/TestType/MyClass.h"

static void MyExp()
{
	using namespace Niflect;

	auto memTest = DebugGetMemoryStats();
	{
		TestCreateModuleReg0();

		auto reg = CNiflectRegistration::StaticGet();

		using namespace MyTestClassScope;
		
		auto type = StaticGetType<CMyClass1>();
		{
			auto mem = CMemory::Alloc(type->GetNiflectTypeSize());

			type->Construct(mem);
		
			auto derived = static_cast<CMyClass1*>(mem);
			derived->m_myStdFloatArrayBase0.push_back(1.0f);
			derived->m_myStdFloatArray1.push_back(2.0f);
			derived->m_myStdFloatArray1.push_back(2.1f);

			type->Destruct(mem);

			CMemory::Free(mem);
		}
		{
			auto shared = type->MakeInstanceShared<CMyClass1>();
			shared->m_myStdFloatArrayBase0.push_back(1.0f);
			shared->m_myStdFloatArray1.push_back(2.0f);
			shared->m_myStdFloatArray1.push_back(2.1f);
			printf("");
		}
		{
			auto obj = CInstance::New<CMyClass1>();
			auto shared = type->MakeInstanceSharable(obj);
			shared->m_myStdFloatArrayBase0.push_back(1.0f);
			shared->m_myStdFloatArray1.push_back(2.0f);
			shared->m_myStdFloatArray1.push_back(2.1f);
			printf("");
		}
		{
			CMyClassBase1* obj = CInstance::New<CMyClass1>();
			auto shared = type->MakeInstanceSharable(obj);
			shared->m_myStdFloatArrayBase0.push_back(1.0f);
			auto derived = static_cast<CMyClass1*>(shared.Get());
			derived->m_myStdFloatArray1.push_back(2.0f);
			derived->m_myStdFloatArray1.push_back(2.1f);
			printf("");
		}
		{
			auto mem = CMemory::Alloc(type->GetNiflectTypeSize());
			type->Construct(mem);
			auto obj = static_cast<CMyClassBase1*>(mem);
			auto shared = type->MakeInstanceSharable(obj);
			shared->m_myStdFloatArrayBase0.push_back(1.0f);
			auto derived = static_cast<CMyClass1*>(shared.Get());
			derived->m_myStdFloatArray1.push_back(2.0f);
			derived->m_myStdFloatArray1.push_back(2.1f);
			printf("");
		}

		TestDestroyModuleReg0();
	}
	printf("");
}

#ifdef TEST_FOR_GCC
#else
#include <Windows.h>
class CStaticTest
{
public:
	CStaticTest()
	{
#ifdef WIN32
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
#endif
		MyExp();
	}
};
//CStaticTest s;
#endif

#ifdef TEST_FOR_GCC
int main()
{
	MyExp();
	return 0;
}
#else
#endif