#include <stdio.h>
#include "Niflect/Base/NiflectRegisteredType.h"
#include "Niflect/Base/NiflectTable.h"
#include "Niflect/Test/TestType/MyClass.h"
#include "Niflect/Memory/Stats/NiflectMemoryStats.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"
#include "Niflect/Module/RuntimeModule.h"
#include "Niflect/Test/TestType/MyField.h"
#include "Niflect/Util/DebugUtil.h"
#include "Niflect/Test/TestModule0.h"

namespace TestVariable
{
	using namespace Niflect;
	using namespace MyTestClassScope;
	
	class CMyScript;

	using CMyScriptHeap = TArrayNif<uint8>;

	class CMyVariable
	{
	public:
		CMyVariable()
			: m_type(NULL)
			, m_heap(NULL)
			, m_offsetInHeap(INDEX_NONE)
		{
		}
		void Init(CMyScriptHeap* heap, AddrOffsetType offset)
		{
			m_heap = heap;
			m_offsetInHeap = offset;
		}

	public:
		AddrType GetMutableAddr()
		{
			ASSERT(m_offsetInHeap != INDEX_NONE);
			auto base = &(*m_heap)[m_offsetInHeap];
			return base;
		}
		const AddrType GetAddr() const
		{
			ASSERT(m_offsetInHeap != INDEX_NONE);
			auto base = &(*m_heap)[m_offsetInHeap];
			return base;
		}

	public:
		void Construct()
		{
			m_type->Construct(this->GetMutableAddr());
		}
		void Destruct()
		{
			m_type->Destruct(this->GetMutableAddr());
		}
		void Save(CRwNode& rw) const
		{
			AddRwString(rw, "Type", m_type->GetTypeName());
		}
		void Load(const CNiflectTable* factory, const CRwNode& rw)
		{
			auto name = FindRwString(rw, "Type");
			//todo: ʵ�ʵ�ʵ��, factory��ͨ����д�����ȡ, �Ҳ���ʹ�����Բ���, Ҳ�п���ʵ��Ϊͨ�����ù�ϵ�Զ�����ַ
			for (auto& it : factory->m_vecType)
			{
				if (it->GetTypeName() == name)
				{
					m_type = it.Get();
					break; 
				}
			}
		}

	public:
		const CNiflectType* m_type;

	private:
		CMyScriptHeap* m_heap;
		AddrOffsetType m_offsetInHeap;//�ó�Ա��������Ҫ���л�, ����AddrOffsetType���͵�size��ƽ̨���, һ�㲻���л�, ����������л������Ϊƽ̨�޹�������uint32
	};

	using CSharedVariable = TSharedPtr<CMyVariable>;

	//todo: ����Ϊ������Blueprint����������ʵ��, ʵ��ʵ�ֿɿ��Ǵ�CClass��CStruct�̳�, m_vecMemberVariable�����ӵ�AccessorTree��, ��������ָ��Ϊ������, �༭�׶�ע�ᵽfactory��, �ַ���ϵͳ�������ܲ�ȫ, �޷�������֤, ����
	class CMyScript
	{
	public:
		~CMyScript()
		{
			//todo: ʵ�ʵ�ʵ�ֿɽ�script��ĳ��ͨ�ö����������̳�, ��override��Destroy�ĺ���ʵ��ͳһ����������Variable
			//���Լ���Ƿ�ִ�й�DestructVaraibles
			ASSERT(m_vecMemberVariable.size() == 0);
		}

	private:
		CSharedVariable CreateVariable() const
		{
			auto var = CInstance::New<CMyVariable>();
			return MakeSharable(var);
		}

	public:
		CMyVariable* AddVariable()
		{
			auto var = this->CreateVariable();
			m_vecMemberVariable.push_back(var);
			return var.Get();
		}
		void DestructVaraibles()
		{
			for (auto& it : m_vecMemberVariable)
				it->Destruct();
			m_vecMemberVariable.clear();
			m_classHeap.clear();
		}
		void ConstructVariables()
		{
			uint32 variablesBytes = 0;
			for (auto& it : m_vecMemberVariable)
			{
				it->Init(&m_classHeap, variablesBytes);
				variablesBytes += it->m_type->GetNiflectTypeSize();
			}

			m_classHeap.resize(variablesBytes);

			for (auto& it : m_vecMemberVariable)
			{
				it->Construct();
			}
		}
		void Save(CRwNode& rw) const
		{
			auto rwVariables = AddRwArray(rw, "Variables");
			for (auto& it : m_vecMemberVariable)
			{
				auto rwItem = rwVariables->AddItemNode();
				it->Save(rwItem);
			}

			auto rwValues = AddRwArray(rw, "Values");
			for (auto& it : m_vecMemberVariable)
			{
				auto rwItem = rwValues->AddItemNode();
				auto accessor = it->m_type->GetAccessorRoot();
				accessor->SaveToRwNode(it->GetAddr(), rwItem);
			}
		}
		void Load(const CNiflectTable* factory, const CRwNode& rw)
		{
			const auto rwVariables = FindRwArray(rw, "Variables");
			auto count = GetRwItemsCount(rwVariables);
			m_vecMemberVariable.resize(count);
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto& var = m_vecMemberVariable[idx];
				const auto rwItem = rwVariables->GetItemNode(idx);
				if (var == NULL)
					var = this->CreateVariable();
				else
					ASSERT(false);//��Ҫʵ���滻����, �������Ͳ�ͬ��Destruct��Variable, ����ʱδLoad, �޷���֪����Load��Variable��type, Ҳ�ɿ�����һ����ʱ����Load�����ͺ���ʹ���滻����, ��������Save���Գ�
				var->Load(factory, rwItem);
			}
			
			this->ConstructVariables();
			
			const auto rwValues = FindRwArray(rw, "Values");
			for (uint32 idx = 0; idx < count; ++idx)
			{
				auto rwItem = rwValues->GetItemNode(idx);
				auto& var = m_vecMemberVariable[idx];
				auto accessor = var->m_type->GetAccessorRoot();
				accessor->LoadFromRwNode(var->GetMutableAddr(), rwItem);
			}
		}

	public:
		TArrayNif<CSharedVariable> m_vecMemberVariable;
		CMyScriptHeap m_classHeap;
	};

	static void CopyInstance(CMyVariable* var, void* data)
	{
		//todo: ʵ��������ƶ�д���������д�����, ��ʵ����������, �־�json��Ϊ��֤������ȷ
		CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
		CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
		//CRwJson::AllocatorStack stack;
		//CRwJson::AllocatorPool allocator(poolCapa, &stack);
		CRwJson::AllocatorStack stack;
		auto& allocator = stack;
		CRwJson::Document jd(&allocator, poolCapa, &allocator);
		auto& joRoot = CRwJson::AsRoot(jd);
		CJsonRwDocument doc(jd, joRoot);
		auto accessor = var->m_type->GetAccessorRoot();
		auto rwRoot = doc.GetRootNode();
		{
			accessor->SaveToRwNode(data, rwRoot);
		}
		{
			accessor->LoadFromRwNode(var->GetMutableAddr(), rwRoot);
		}
	}
	static void SetFloat(CMyVariable* var, float value)
	{
		ASSERT(var->m_type->GetTypeName() == StaticGetType<CFieldFloat>()->GetTypeName());
		CopyInstance(var, &value);
	}
}

static void MyExp()
{
	using namespace Niflect;
	using namespace TestVariable;

	auto memTest = DebugGetMemoryStats();
	{
		auto module = TestCreateModuleReg0();
		auto table = module->GetTable(0);

		using namespace MyTestClassScope;

		CMyScript script0;
		auto var0 = script0.AddVariable();
		var0->m_type = StaticGetType<CMyClass0>();
		auto var1 = script0.AddVariable();
		var1->m_type = StaticGetType<CFieldFloat>();
		script0.ConstructVariables();

		SetFloat(var1, 123.45f);
		CMyClass0 obj0;
		obj0.m_myFloat0 = 2.3f;
		CopyInstance(var0, &obj0);

		CString savedData;
		{
			CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
			CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
			//CRwJson::AllocatorStack stack;
			//CRwJson::AllocatorPool allocator(poolCapa, &stack);
			CRwJson::AllocatorStack stack;
			auto& allocator = stack;
			CRwJson::Document jd(&allocator, poolCapa, &allocator);
			auto& joRoot = CRwJson::AsRoot(jd);
			CJsonRwDocument doc(jd, joRoot);
			auto rwRoot = doc.GetRootNode();

			script0.Save(rwRoot);

			CRwJson::StringBuffer buffer(&allocator, poolCapa);
			CRwJson::WriteToBuffer(joRoot, buffer);
			savedData = buffer.GetString();
		}
		{
			CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
			CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
			//CRwJson::AllocatorStack stack;
			//CRwJson::AllocatorPool allocator(poolCapa, &stack);
			CRwJson::AllocatorStack stack;
			auto& allocator = stack;
			CRwJson::Document jd(&allocator, poolCapa, &allocator);
			auto& joRoot = CRwJson::ReadFromBuffer(jd, savedData.c_str());
			CJsonRwDocument doc(jd, joRoot);
			auto rwRoot = doc.GetRootNode();
			
			//todo: ����ֱ���ñ����script Load, LoadǰCleanup
			CMyScript script1;
			script1.Load(table, rwRoot);
			script1.DestructVaraibles();

			CRwJson::StringBuffer buffer(&allocator, poolCapa);
			CRwJson::WriteToBuffer(joRoot, buffer);
			printf("%s\n", buffer.GetString());
		}
		script0.DestructVaraibles();

		TestDestroyModuleReg0();
	}

	printf("");
	////while(true)
	//{
	//	auto base = malloc(classType->m_typeSize);
	//	classType->m_InvokeConstructorFunc(base);
	//	auto instance = static_cast<MyTestClassScope::CMyClass1*>(base);
	//	classType->m_InvokeDestructorFunc(base);
	//	free(base);
	//}
}

#ifdef TEST_FOR_GCC
#else
#include <Windows.h>
class CStaticTest
{
public:
	CStaticTest()
	{
#ifdef WIN32
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
#endif
		MyExp();
	}
};
//CStaticTest s;
#endif

#ifdef TEST_FOR_GCC
int main()
{
	MyExp();
	return 0;
}
#else
#endif