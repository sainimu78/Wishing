#include <stdio.h>
#include "Niflect/Base/NiflectRegisteredType.h"
#include "Niflect/Base/NiflectTable.h"
#include "Niflect/Test/TestType/MyClass.h"
#include "Niflect/Memory/Stats/NiflectMemoryStats.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"
#include "Niflect/Module/RuntimeModule.h"
#include "Niflect/Util/DebugUtil.h"
#include "Niflect/Test/TestModule0.h"
#include "Niflect/Test/TestType/MyField.h"
#include <typeinfo>

namespace Niflect
{
	template <typename TType>
	static CNiflectType* StaticGetOrRegisterType_TArrayNif()
	{
		return StaticGetMiscType_ContainerArray<TType>("TArrayNif");
	}
	template <typename TType>
	static CSharedAccessor StaticCreateAccessorTree_ContainerMap(AddrOffsetType offset)
	{
		ASSERT(false);
		auto memberArray = CreateArrayAccessorAddr<TType>(offset);
		auto type = StaticGetType<TType>();
		memberArray->InitMeta(type);
		return memberArray;
	}
	template <typename TType>
	static CNiflectType* StaticGetType_ContainerMap(const CString& typeName)
	{
		TryRegisterMiscType<TType>(typeName, &StaticCreateAccessorTree_ContainerMap<TType>);
		return StaticGetType<TType>();
	}
	template <typename TType>
	static CNiflectType* StaticGetType_TMap()
	{
		return StaticGetType_ContainerMap<TType>("TMap");
	}
}

static void MyExp()
{
	using namespace Niflect;

	auto memTest = DebugGetMemoryStats();
	{
		TestCreateModuleReg0();

		auto reg = CNiflectRegistration::StaticGet();

		using namespace MyTestClassScope;

		{
			auto type = StaticGetOrRegisterType_TArrayNif<TArrayNif<TArrayNif<float> > >();
			auto a = type->CreateAccessorTree(CAddrOffset::None);
			printf("");
		}
		{
			//auto type = StaticGetType_TMap<TMap<CString, float> >();
			//auto a = type->m_InvokeCreateAccessorFunc(0);
			//printf("");
		}


		TestDestroyModuleReg0();
	}
	printf("");
}

#ifdef TEST_FOR_GCC
#else
#include <Windows.h>
class CStaticTest
{
public:
	CStaticTest()
	{
#ifdef WIN32
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
#endif
		MyExp();
	}
};
//CStaticTest s;
#endif

#ifdef TEST_FOR_GCC
int main()
{
	MyExp();
	return 0;
}
#else
#endif