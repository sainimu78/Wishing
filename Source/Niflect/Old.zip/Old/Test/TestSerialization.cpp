#include <stdio.h>
#include "Niflect/Base/NiflectRegisteredType.h"
#include "Niflect/Base/NiflectTable.h"
#include "Niflect/Test/TestType/MyClass.h"
#include "Niflect/Memory/Stats/NiflectMemoryStats.h"
#include "Niflect/Serialization/Tree/JsonTreeReadWrite2.h"
#include "Niflect/Module/RuntimeModule.h"
#include "Niflect/Util/DebugUtil.h"
#include "Niflect/Test/TestModule0.h"

static void MyExp()
{
	using namespace Niflect;

	auto memTest = DebugGetMemoryStats();
	{
		auto module = TestCreateModuleReg0();

		using namespace MyTestClassScope;

		auto classType = CInheritableType::Cast(StaticGetType<CMyClass1>());
		auto parentClass = classType;
		auto validParentClass = parentClass;
		while(parentClass != NULL)
		{
			validParentClass = parentClass;
			parentClass = validParentClass->GetParent();
		}
	
		CMyClass1 obj;
		SetupTestInstance_CMyClass1(obj);
	
		{
			CAccessor* accessorParent = validParentClass->GetAccessorRoot();
			CAccessor* accessorDerived = classType->GetAccessorRoot();
			void* base = &obj;
			CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
			CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
			//CRwJson::AllocatorStack stack;
			//CRwJson::AllocatorPool allocator(poolCapa, &stack);
			CRwJson::AllocatorStack stack;
			auto& allocator = stack;
			CRwJson::Document jd(&allocator, poolCapa, &allocator);
			auto& joRoot = CRwJson::AsRoot(jd);
			CJsonRwDocument doc(jd, joRoot);
			auto rwRoot = doc.GetRootNode();
			//begin, ����������ƴ�Ӽ�Ϊnative��layout
			accessorParent->SaveToRwNode(base, rwRoot);
			accessorDerived->SaveToRwNode(base, rwRoot);
			//end

			{
				auto accessor0 = accessorDerived;
				auto accessor1 = CObjectAccessor::Cast(accessorDerived)->GetChild(2);
				auto accessor2 = CObjectAccessor::Cast(accessor1)->GetChild(1);
				TArrayNif<CAccessor*> vecAccessorPath;
				{
					auto owner = accessor2;
					while (true)
					{
						owner = owner->GetOwner();
						if (owner == NULL)
							break;
						vecAccessorPath.insert(vecAccessorPath.begin(), owner);
					}
				}
				void* parentAccessorBase = base;
				for (auto& it : vecAccessorPath)
					parentAccessorBase = it->GetBaseAddr(parentAccessorBase);
				ASSERT(parentAccessorBase == &obj.m_sub0);
				{
					CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
					CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
					//CRwJson::AllocatorStack stack;
					//CRwJson::AllocatorPool allocator(poolCapa, &stack);
					CRwJson::AllocatorStack stack;
					auto& allocator = stack;
					CRwJson::Document jd(&allocator, poolCapa, &allocator);
					auto& joRoot = CRwJson::AsRoot(jd);
					CJsonRwDocument doc(jd, joRoot);
					auto rwRoot = doc.GetRootNode();
					accessor2->SaveToRwNode(parentAccessorBase, rwRoot);
					CRwJson::StringBuffer buffer(&allocator, poolCapa);
					CRwJson::WriteToBuffer(joRoot, buffer);
					ASSERT(strcmp(buffer.GetString(), "222.10000610351563") == 0);
				}
				printf("");
			}
			{
				auto accessor0 = accessorDerived;
				auto accessor1 = CObjectAccessor::Cast(accessorDerived)->GetChild(1);
				auto accessor2 = CArrayAccessor::Cast(accessor1)->GetItemAccessor();
				const bool isArrayContainerAccessor = CArrayAccessor::CastChecked(accessor2->GetOwner()) != NULL;
				ASSERT(isArrayContainerAccessor);
				TArrayNif<CAccessor*> vecAccessorPath;
				{
					auto owner = accessor2;
					while (true)
					{
						owner = owner->GetOwner();
						if (owner == NULL)
							break;
						vecAccessorPath.insert(vecAccessorPath.begin(), owner);
					}
				}
				void* parentAccessorBase = base;
				for (auto& it : vecAccessorPath)
					parentAccessorBase = it->GetBaseAddr(parentAccessorBase);
				ASSERT(parentAccessorBase == &obj.m_myStdFloatArray1);
				{
					CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
					CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
					//CRwJson::AllocatorStack stack;
					//CRwJson::AllocatorPool allocator(poolCapa, &stack);
					CRwJson::AllocatorStack stack;
					auto& allocator = stack;
					CRwJson::Document jd(&allocator, poolCapa, &allocator);
					auto& joRoot = CRwJson::AsRoot(jd);
					CJsonRwDocument doc(jd, joRoot);
					auto rwRoot = doc.GetRootNode();
					if (isArrayContainerAccessor)
					{
						auto parentAccessor = CArrayAccessor::Cast(accessor2->GetOwner());
						parentAccessor->SaveItemToRwNode(parentAccessorBase, 1, rwRoot);//����1��ʾ������ArrayElement��ӦProperty�����������
					}
					CRwJson::StringBuffer buffer(&allocator, poolCapa);
					CRwJson::WriteToBuffer(joRoot, buffer);
					auto a = buffer.GetString();
					ASSERT(strcmp(buffer.GetString(), "33.099998474121094") == 0);//����rapidjson(2022����)�����һλ7��Ϊ4, ����������rapidjson��ת���ִ����б仯
				}
				printf("");
			}
			{
				auto accessor0 = accessorDerived;
				auto accessor1 = CObjectAccessor::Cast(accessorDerived)->GetChild(3);
				auto accessor2 = CArrayAccessor::Cast(accessor1)->GetItemAccessor();
				auto accessor = CArrayAccessor::Cast(accessor2)->GetItemAccessor();
				const bool isArrayContainerAccessor = CArrayAccessor::CastChecked(accessor->GetOwner()) != NULL;
				ASSERT(isArrayContainerAccessor);
				TArrayNif<CAccessor*> vecAccessorPath;
				{
					auto owner = accessor;
					while (true)
					{
						owner = owner->GetOwner();
						if (owner == NULL)
							break;
						vecAccessorPath.insert(vecAccessorPath.begin(), owner);
					}
				}
				void* parentAccessorBase = CObjectAccessor::Cast(vecAccessorPath[0])->GetBaseAddr(base);
				ASSERT(parentAccessorBase == &obj);
				parentAccessorBase = CArrayAccessor::Cast(vecAccessorPath[1])->GetBaseAddr(parentAccessorBase);
				ASSERT(parentAccessorBase == &obj.m_myStdFloatArrayArray2);
				parentAccessorBase = CArrayAccessor::Cast(vecAccessorPath[1])->GetItemBaseAddr(parentAccessorBase, 1);
				ASSERT(parentAccessorBase == &obj.m_myStdFloatArrayArray2[1]);
				{
					CRwJson::SizeType poolCapa = 0;//Pool�Ŀ��ڴ�
					CRwJson::SizeType stackCapa = 0;//Json�ڵ���Object��Ԥ���ڴ�
					//CRwJson::AllocatorStack stack;
					//CRwJson::AllocatorPool allocator(poolCapa, &stack);
					CRwJson::AllocatorStack stack;
					auto& allocator = stack;
					CRwJson::Document jd(&allocator, poolCapa, &allocator);
					auto& joRoot = CRwJson::AsRoot(jd);
					CJsonRwDocument doc(jd, joRoot);
					auto rwRoot = doc.GetRootNode();
					if (isArrayContainerAccessor)
					{
						auto parentAccessor = CArrayAccessor::Cast(accessor->GetOwner());
						parentAccessor->SaveItemToRwNode(parentAccessorBase, 3, rwRoot);//����1��ʾ������ArrayElement��ӦProperty�����������
					}
					CRwJson::StringBuffer buffer(&allocator, poolCapa);
					CRwJson::WriteToBuffer(joRoot, buffer);
					auto a = buffer.GetString();
					ASSERT(strcmp(buffer.GetString(), "6.300000190734863") == 0);
				}
				printf("");
			}

			CRwJson::StringBuffer buffer(&allocator, poolCapa);
			CRwJson::WriteToBuffer(joRoot, buffer);
			printf("%s\n", buffer.GetString());
		}

		TestDestroyModuleReg0();
	}

	printf("");
	////while(true)
	//{
	//	auto base = malloc(classType->m_typeSize);
	//	classType->m_InvokeConstructorFunc(base);
	//	auto instance = static_cast<MyTestClassScope::CMyClass1*>(base);
	//	classType->m_InvokeDestructorFunc(base);
	//	free(base);
	//}
}

#ifdef TEST_FOR_GCC
#else
#include <Windows.h>
class CStaticTest
{
public:
	CStaticTest()
	{
#ifdef WIN32
		AllocConsole();
		freopen("CONOUT$", "w", stdout);
#endif
		MyExp();
	}
};
//CStaticTest s;
#endif

#ifdef TEST_FOR_GCC
int main()
{
	MyExp();
	return 0;
}
#else
#endif