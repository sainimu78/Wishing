#pragma once

#define NIFLECTGENINTERNAL_COMBINE_INNER(A,B,C) A##B##C
#define NIFLECTGENINTERNAL_COMBINE(A,B,C) NIFLECTGENINTERNAL_COMBINE_INNER(A,B,C)

#define NIF_BS() using NIFLECTGENINTERNAL_COMBINE(__NiflectGen_BindingSetting,_,__LINE__) = 

namespace Niflect
{
	template <typename ...TAccessors>
	class TAccessorsTuple
	{
	};

	template <typename TType, typename TTuple>
	class TBindingSetting
	{
	};

	template <template <typename ...> class TTemplate, typename TTuple>
	class TTemplateBindingSetting
	{
	};

	template <typename TTypeToBind>
	class TBindingType
	{
	};

	template <typename TAccessor, typename TBindingType>
	class TBindingSetting2
	{
	};
}