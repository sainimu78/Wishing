#pragma once

namespace Niflect
{
#define NIFLECTGENINTERNAL_COMBINE_INNER(A,B,C) A##B##C;
#define NIFLECTGENINTERNAL_COMBINE(A,B,C) NIFLECTGENINTERNAL_COMBINE_INNER(A,B,C)
#define BIND_END NIFLECTGENINTERNAL_COMBINE(__NIFLECTINTERNALVARNAME,_,__LINE__)

#define BIND_BEGIN typedef 

	template <typename ...TAccessors>
	class TAccessorsTuple
	{
	};

	template <typename TType, typename TTuple>
	class TBindingSetting
	{
	};

	template <template <typename ...> class ContainerT, typename TTuple>
	class TTemplateTypeBinding
	{
	};
}