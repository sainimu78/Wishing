#pragma once
#include "Niflect/Base/NiflectTable.h"
#include "Niflect/Accessor/NiflectAccessorAddr.h"

namespace Niflect
{
	class CNiflectRegistration;

	using CSharedNiflectRegistration = TSharedPtr<CNiflectRegistration>;

	class CNiflectRegistration
	{
	public:
		CNiflectRegistration()
			: m_miscTableIndex(INDEX_NONE)
		{
		}

	public:
		void InitTables()
		{
			this->DoInitTables();
			this->AddMiscTable();
		}
		void RegisterTypes() const
		{
			this->DoRegisterTypes();
		}
		void InitTypes() const
		{
			this->DoInitTypes();
		}
		void InitMethods() const
		{
			this->DoInitMethods();
		}
		void InitTypesAccessorTree() const
		{
			this->DoInitTypesAccessorTree();
		}

	protected:
		virtual void DoInitTables() = 0;
		virtual void DoRegisterTypes() const = 0;
		virtual void DoInitTypes() const = 0;
		virtual void DoInitMethods() const = 0;
		virtual void DoInitTypesAccessorTree() const = 0;

	public:
		void ClearTables()//todo: ʵ���ϻ���Ҫͨ�����ù�ϵ��ȫɾ��
		{
			m_vecTable.clear();
		}
		uint32 GetTablesCount() const
		{
			return static_cast<uint32>(m_vecTable.size());
		}
		CNiflectTable* GetTable(uint32 idx) const
		{
			return m_vecTable[idx].Get();
		}
		CNiflectTable* GetMiscTable()
		{
			return m_vecTable[m_miscTableIndex].Get();
		}

	protected:
		CNiflectTable* AddNewTable()
		{
			auto table = this->CreateTable();
			m_vecTable.push_back(table);
			return table.Get();
		}

	private:
		CSharedNiflectTable CreateTable() const
		{
			return MakeSharable(CInstance::New<CNiflectTable>());
		}
		void AddMiscTable()
		{
			ASSERT(m_miscTableIndex == INDEX_NONE);
			m_miscTableIndex = this->GetTablesCount();
			this->AddNewTable();
		}

	public:
		static CNiflectRegistration* StaticGet()
		{
			return s_reg.Get();
		}
		template <typename TDerivedReg>
		static void StaticCreate()
		{
			s_reg = MakeSharable(CInstance::New<TDerivedReg>());
		}
		static void StaticDestroy()
		{
			s_reg = NULL;
		}

	private:
		TArrayNif<CSharedNiflectTable> m_vecTable;
		uint32 m_miscTableIndex;

	private:
		static CSharedNiflectRegistration s_reg;
	};
	
	template <typename TType>
	static void TryRegisterMiscType(const CString& typeName, const InvokeCreateAccessorTreeFunc& Func)
	{
		auto reg = CNiflectRegistration::StaticGet();
		auto table = reg->GetMiscTable();
		if (!TInternalRegisteredType<TType>::IsValid())
		{
			CNiflectTypeInvokations typeFuncs;
			typeFuncs.m_InvokeConstructorFunc = &GenericInstanceInvokeConstructor<TType>;
			typeFuncs.m_InvokeDestructorFunc = &GenericInstanceInvokeDestructor<TType>;
			typeFuncs.m_InvokeCreateAccessorTreeFunc = Func;

			auto type = CInstance::New<CNiflectType>();
			auto idx = table->RegisterType(MakeSharable(type));
			type->InitStaticType<TType>();
			type->InitTypeMeta(sizeof(TType), typeName, idx, typeFuncs);
			ASSERT(TInternalRegisteredType<TType>::IsValid());
			//type->InitInheritableTypeMeta(NULL);
		}
	}
	template <typename TType>
	static CSharedAccessor StaticCreateAccessorTree_ContainerArray(AddrOffsetType offset)
	{
		auto memberArray = CreateArrayAccessorAddr<TType>(offset);
		auto type = StaticGetType<TType>();
		memberArray->InitMeta(type);
		return memberArray;
	}
	template <typename TType>
	static CNiflectType* StaticGetMiscType_ContainerArray(const CString& typeName)
	{
		TryRegisterMiscType<TType>(typeName, &StaticCreateAccessorTree_ContainerArray<TType>);
		return StaticGetType<TType>();
	}
	//class CTestNiflectModuleInterface
	//{
	//public:
	//	void Create() const
	//	{
	//		m_CreateModuleFunc();
	//	}
	//	void Destroy() const
	//	{
	//		m_DestroyModuleFunc();
	//	}
	//	CNiflectModule* GetModule() const
	//	{
	//		return m_GetModuleFunc();
	//	}
	//	
	//public:
	//	typedef void (*CreateModuleFunc)();
	//	typedef void (*DestroyModuleFunc)();
	//	typedef CNiflectModule* (*GetModuleFunc)();

	//public:
	//	CreateModuleFunc m_CreateModuleFunc;
	//	DestroyModuleFunc m_DestroyModuleFunc;
	//	GetModuleFunc m_GetModuleFunc;
	//};
}

NIFLECT_C_API Niflect::CNiflectRegistration* GetNiflectModuleRegistration();