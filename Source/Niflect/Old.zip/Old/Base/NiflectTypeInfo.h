#pragma once
#include "Niflect/NiflectCommon.h"
#include "Niflect/Base/NiflectBase.h"

namespace Niflect
{
	class CNiflectType;

	typedef uint32 CTypeIndex;

	class CTypeInfo
	{
	public:
		CTypeInfo()
			: m_index(INDEX_NONE)
		{
		}
		bool IsValid() const
		{
			return m_index != INDEX_NONE;
		}
		void Init(const CString& name, const CTypeIndex& idx)
		{
			m_name = name;
			m_index = idx;
		}

	public:
		const CString& GetName() const
		{
			return m_name;
		}
		const CTypeIndex& GetIndex() const
		{
			return m_index;
		}

	private:
		CString m_name;
		CTypeIndex m_index;
	};
}