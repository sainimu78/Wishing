#pragma once

namespace Niflect
{
	class CNiflectType;

	template <typename T>
	class TInternalRegisteredType
	{
		template <typename T2>
		friend CNiflectType* StaticGetType();
		friend class CNiflectType;

	public:
		static bool IsValid()
		{
			return s_type != nullptr;
		}

	private:
		static CNiflectType* s_type;
	};

	template <typename T>
	CNiflectType* TInternalRegisteredType<T>::s_type = nullptr;

	template <typename T>
	static CNiflectType* StaticGetType()
	{
		return TInternalRegisteredType<T>::s_type;
	}
}