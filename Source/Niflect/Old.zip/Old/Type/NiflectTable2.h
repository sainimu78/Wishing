#pragma once
#include "Niflect/Type/NiflectType2.h"

namespace Niflect
{
	//ΪModule������CType������, ����Ҫ���̳�
	class CNiflectTable2
	{
		friend class CNiflectModule;
	public:
		void Init(const CString& name)
		{
			m_name = name;
		}
		template <typename TInfo, typename TType>
		void RegisterTypeDefaultTypeHash(const CString& typeName, const InvokeCreateFieldLayoutFunc& Func)
		{
			this->RegisterType<TInfo, TType>(typeName, Func, typeid(TType).hash_code());
		}
		template <typename TInfo, typename TType>
		void RegisterType(const CString& typeName, const InvokeCreateFieldLayoutFunc& Func, size_t typeHash)
		{
			CTypeInvokations typeFuncs;
			typeFuncs.m_InvokeConstructorFunc = &GenericInstanceInvokeConstructor<TType>;
			typeFuncs.m_InvokeDestructorFunc = &GenericInstanceInvokeDestructor<TType>;
			typeFuncs.m_InvokeCreateFieldLayoutFunc = Func;

			auto shared = MakeShared<TInfo>();
			auto type = shared.Get();
			auto idx = this->AddType(shared);
			ASSERT(!TInternalRegisteredType2<TType>::IsValid());
			TInternalRegisteredType2<TType>::s_type = type;
			//type->InitStaticType<TType>();
			type->InitTypeMeta(sizeof(TType), typeHash, typeName, idx, typeFuncs);
			ASSERT(TInternalRegisteredType2<TType>::IsValid());
		}
		uint32 GetTypesCount() const
		{
			return static_cast<uint32>(m_vecType.size());//todo: ������α���cast
		}
		CNiflectType2* GetTypeByIndex(uint32 idx) const
		{
			return m_vecType[idx].Get();
		}
		
	private:
		uint32 AddType(const CSharedType2& type)//����VS����, ��ʱ��My��׺
		{
			uint32 idx = this->GetTypesCount();
			m_vecType.push_back(type);
			return idx;
		}

	public:
		TArrayNif<CSharedType2> m_vecType;
		CString m_name;
	};

	using CSharedTable2 = TSharedPtr<CNiflectTable2>;
}