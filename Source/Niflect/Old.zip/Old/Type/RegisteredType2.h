#pragma once
#include "Niflect/NiflectCommon.h"

namespace Niflect
{
	class CNiflectType2;

	template <typename T>
	class TInternalRegisteredType2
	{
		template <typename T2>
		friend CNiflectType2* StaticGetType2();
		//friend class CNiflectType2;
		friend class CNiflectTable2;

	public:
		static bool IsValid()
		{
			return s_type != NULL;
		}

	private:
		static CNiflectType2* s_type;
	};

	template <typename T>
	CNiflectType2* TInternalRegisteredType2<T>::s_type = NULL;

	template <typename T>
	static CNiflectType2* StaticGetType2()
	{
		return TInternalRegisteredType2<T>::s_type;
	}
}