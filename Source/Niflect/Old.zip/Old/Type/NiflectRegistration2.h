#pragma once
#include "Niflect/Type/NiflectTable2.h"
#include "Niflect/Field/ArrayField.h"
#include "Niflect/Field/MapField.h"

namespace Niflect
{
	class CNiflectRegistration2;

	using CSharedRegistration2 = TSharedPtr<CNiflectRegistration2>;

	class CNiflectRegistration2
	{
	public:
		CNiflectRegistration2()
			: m_miscTableIndex(INDEX_NONE)
		{
		}

	public:
		void InitTables()
		{
			this->DoInitTables();
			this->AddMiscTable();
		}
		void RegisterTypes()
		{
			this->DoRegisterTypes();
		}
		void InitTypes() const
		{
			this->DoInitTypes();
		}
		void InitMethods() const
		{
			this->DoInitMethods();
		}
		void InitTypesAccessorTree()
		{
			this->DoInitTypesAccessorTree();
		}

	protected:
		virtual void DoInitTables() = 0;
		virtual void DoRegisterTypes() = 0;
		virtual void DoInitTypes() const = 0;
		virtual void DoInitMethods() const = 0;
		virtual void DoInitTypesAccessorTree() = 0;

	public:
		void ClearTables()//todo: ʵ���ϻ���Ҫͨ�����ù�ϵ��ȫɾ��
		{
			m_vecTable.clear();
		}
		uint32 GetTablesCount() const
		{
			return static_cast<uint32>(m_vecTable.size());
		}
		CNiflectTable2& GetMutableTable(uint32 idx)
		{
			return m_vecTable[idx];
		}
		CNiflectTable2& GetMutableMiscTable()
		{
			return m_vecTable[m_miscTableIndex];
		}

	protected:
		CNiflectTable2* AddNewTable()
		{
			m_vecTable.push_back(CNiflectTable2());
			return &m_vecTable.back();
		}

	private:
		void AddMiscTable()
		{
			ASSERT(m_miscTableIndex == INDEX_NONE);
			m_miscTableIndex = this->GetTablesCount();
			this->AddNewTable();
		}

	public:
		static CNiflectRegistration2* StaticGet()
		{
			return s_reg.Get();
		}
		template <typename TDerivedReg>
		static void StaticCreate()
		{
			s_reg = MakeShared<TDerivedReg>();
		}
		static void StaticDestroy()
		{
			s_reg = NULL;
		}

	private:
		TArrayNif<CNiflectTable2> m_vecTable;
		uint32 m_miscTableIndex;

	private:
		static CSharedRegistration2 s_reg;
	};

	//template <typename TType>
	//static void TryRegisterMiscType2(const CString& typeName, const InvokeCreateFieldTreeFunc& Func)
	//{
	//	auto reg = CNiflectRegistration2::StaticGet();
	//	auto& table = reg->GetMutableMiscTable();
	//	if (!TInternalRegisteredType2<TType>::IsValid())
	//		table.RegisterType<CNiflectType2, TType>(typeName, Func);
	//}
	//template <typename TType>
	//static CSharedField StaticCreateAccessorTree_ContainerArray2()
	//{
	//	auto shared0 = CreateArrayField<TType>();
	//	auto field0 = shared0.Get();
	//	field0->InitType(StaticGetType2<TType>());
	//	return shared0;
	//}
	//template <typename TType>
	//static CNiflectType2* StaticGetMiscType_ContainerArray2(const CString& typeName)
	//{
	//	TryRegisterMiscType2<TType>(typeName, &StaticCreateAccessorTree_ContainerArray2<TType>);
	//	return StaticGetType2<TType>();
	//}
	//template <typename TType>
	//static CSharedField StaticCreateAccessorTree_ContainerMap2()
	//{
	//	auto shared0 = CreateMapField<TType>();
	//	auto field0 = shared0.Get();
	//	field0->InitType(StaticGetType2<TType>());
	//	return shared0;
	//}
	//template <typename TType>
	//static CNiflectType2* StaticGetMiscType_ContainerMap2(const CString& typeName)
	//{
	//	TryRegisterMiscType2<TType>(typeName, &StaticCreateAccessorTree_ContainerMap2<TType>);
	//	return StaticGetType2<TType>();
	//}
	
	template <typename TField, typename TType>
	static CSharedField __InternalUseForFunctionPointer()
	{
		return CreateField<TField, TType>();
	}
	template <typename TField, typename TType>
	static CNiflectType2* StaticRegisterOrGetTemplateType(const CString& typeName, size_t typeHash)
	{
		if (!TInternalRegisteredType2<TType>::IsValid())
		{
			auto reg = CNiflectRegistration2::StaticGet();
			auto& table = reg->GetMutableMiscTable();
			ASSERT(!typeName.empty());
			table.RegisterType<CNiflectType2, TType>(typeName, &__InternalUseForFunctionPointer<TField, TType>, typeHash);
		}
		return StaticGetType2<TType>();
	}
	template <typename TField, typename TType>
	static CNiflectType2* StaticRegisterOrGetTemplateTypeDefaultTypeHash(const CString& typeName)
	{
		return StaticRegisterOrGetTemplateType<TField, TType>(typeName, typeid(TType).hash_code());
	}
}

NIFLECT_C_API Niflect::CNiflectRegistration2* GetNiflectModuleRegistration2();