#include "Niflect/Memory/Default/DefaultMemory.h"
#include "Niflect/Memory/Generic/GenericMemory.h"

namespace Niflect
{
	static CMemoryStats* g_memoryTest = NULL;
	static void MakeSureInitTest()
	{
		//begin, �ƻ������ٽ���֧�ֲ�������, ���ٽ�����֤�̰߳�ȫ, ���ٴμ���Ƿ�δ����
		if (g_memoryTest == NULL)
		{
			static CMemoryStats s_holder;
			g_memoryTest = &s_holder;
		}
		//end
	}
	
	void* CMemory::Alloc(size_t size)
	{
		MakeSureInitTest();
		return CGenericMemory::Alloc(size, g_memoryTest);
	}
	void* CMemory::Realloc(void* ptr, size_t size)
	{
		MakeSureInitTest();
		return CGenericMemory::Realloc(ptr, size, g_memoryTest);
	}
	void CMemory::Free(void* ptr)
	{
		CGenericMemory::Free(ptr, g_memoryTest);
	}
	
	CMemoryStats* DebugGetMemoryStats()
	{
		MakeSureInitTest();
		return g_memoryTest;
	}
	
	static void TestReserved()
	{
		auto memoryTest = g_memoryTest;
		auto p0 = CMemory::Alloc(4);
		ASSERT((memoryTest = g_memoryTest)->m_allocatedBytesRuntimeTotal == 4);
		auto p1 = CMemory::Alloc(6);
		ASSERT((memoryTest = g_memoryTest)->m_allocatedBytesRuntimeTotal == 10);
		p0 = CMemory::Realloc(p0, 6);
		ASSERT((memoryTest = g_memoryTest)->m_allocatedBytesRuntimeTotal == 12);
		p1 = CMemory::Realloc(p1, 4);
		ASSERT(((memoryTest = g_memoryTest)->m_allocatedBytesRuntimeTotal == 12) && ((memoryTest = g_memoryTest)->m_freedBytesRuntimeTotal == 2));
		auto p2 = CMemory::Alloc(3);
		ASSERT((memoryTest = g_memoryTest)->m_allocatedBytesRuntimeTotal == 15);
		CMemory::Free(p0);
		ASSERT((memoryTest = g_memoryTest)->m_freedBytesRuntimeTotal == 8);
		CMemory::Free(p1);
		ASSERT((memoryTest = g_memoryTest)->m_freedBytesRuntimeTotal == 12);
		CMemory::Free(p2);
		auto expectedBytesCount = 3*sizeof(size_t) + 6 + 4 + 3 + 2;//sizeof(size_t)��ʾÿ�������ڴ���Ϣͷ�ֽ���; 6, 4, 3�ֱ�Ϊp0, p1, p2�ͷ�֮ǰ���ֽ���; 2Ϊp1��6 ReallocΪ4��, �߼��ϱ��ͷŵ��ֽ���
		ASSERT(((memoryTest = g_memoryTest)->m_freedBytesRuntimeTotal == 15) && ((memoryTest = g_memoryTest)->m_freeCount == 3) && ((memoryTest = g_memoryTest)->m_freedBytesTotal == expectedBytesCount));
	}
}