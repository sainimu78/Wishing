#pragma once
#include "Niflect/NiflectCommon.h"

namespace Niflect
{
	class CMemory
	{
	public:
		NIFLECT_API static void* Alloc(size_t size);
		NIFLECT_API static void* Realloc(void* ptr, size_t size);
		NIFLECT_API static void Free(void* ptr);
	};

	class CMemoryStats;
	NIFLECT_API CMemoryStats* DebugGetMemoryStats();
}